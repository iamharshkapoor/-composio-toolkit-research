# Research Data Contract

The assignment requires 100 evidence-backed integration records. This directory will hold the canonical manifest, research output, validation results, and verification log generated during execution.

No synthetic user reviews or unlabelled fabricated research data is permitted. Each final claim should point to official evidence or be marked `unknown` with an uncertainty note.

