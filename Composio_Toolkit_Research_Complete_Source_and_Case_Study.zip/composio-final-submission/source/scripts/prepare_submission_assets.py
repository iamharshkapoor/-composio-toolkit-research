"""Create compact WebP copies of the visual assets for the upload-only static package."""

from pathlib import Path
from PIL import Image

SOURCE = Path("/home/ubuntu/webdev-static-assets")
TARGET = Path("/home/ubuntu/composio-final-submission/case-study/manus-storage")

ASSETS = {
    "evidence-ledger-hero.png": ("evidence-ledger-hero_5bb865ef.webp", 1440),
    "evidence-ledger-provenance.png": ("evidence-ledger-provenance_0923668d.webp", 1050),
    "evidence-ledger-agent.png": ("evidence-ledger-agent_4b561054.webp", 1050),
    "evidence-ledger-pattern.png": ("evidence-ledger-pattern_bf7dae88.webp", 1050),
    "evidence-ledger-logo.png": ("evidence-ledger-logo_006f3236.webp", 256),
}

for source_name, (target_name, max_width) in ASSETS.items():
    with Image.open(SOURCE / source_name) as image:
        image = image.convert("RGBA")
        if image.width > max_width:
            height = round(image.height * max_width / image.width)
            image = image.resize((max_width, height), Image.Resampling.LANCZOS)
        image.save(TARGET / target_name, "WEBP", quality=64, method=6)

for stale_png in TARGET.glob("*.png"):
    stale_png.unlink()
