import fs from 'node:fs';

/** Evidence Ledger holdout correction: applies verified values while preserving the blind-test artifact. */
const root = '/home/ubuntu/composio-toolkit-research';
const finalPath = `${root}/data/research_results_final.json`;
const finalData = JSON.parse(fs.readFileSync(finalPath, 'utf8'));
const raw = JSON.parse(fs.readFileSync(`${root}/data/post_repair_holdout_raw.json`, 'utf8'));
const comparison = JSON.parse(fs.readFileSync(`${root}/data/post_repair_holdout.json`, 'utf8'));
const byId = new Map(comparison.records.map((item) => [item.appId, item]));
const isHttp = (value) => /^https?:\/\//.test(String(value ?? ''));
const parseEvidence = (value) => Object.fromEntries(String(value ?? '').split('|').map((part) => part.trim().split('=').map((x) => x.trim())).filter((parts) => parts.length >= 2).map(([key, ...rest]) => [key.toLowerCase(), rest.join('=')]));
const callability = (value) => ({ build_now: 'direct_now', build_with_review: 'feasible_with_build', outreach_required: 'blocked_by_access', deprioritize: 'not_recommended' })[value] || 'unknown';
const allowedAccess = new Set(['self_serve_free','self_serve_trial','self_serve_paid','admin_approval','app_review','partner_gated','contact_sales','unavailable','unknown']);
const allowedMcp = new Set(['native_official_mcp','native_third_party_mcp','composio_mcp_exposure','mcp_possible_via_api','mcp_not_verified']);
const allowedVerdict = new Set(['build_now','build_with_review','outreach_required','deprioritize','unknown']);
const changes = [];
for (const { output, error } of raw.results) {
  if (!output || error) continue;
  const record = finalData.records.find((item) => item.id === Number(output.app_id));
  if (!record) continue;
  const blind = byId.get(record.id);
  const before = { authMethods: record.authMethods, selfServeStatus: record.selfServeStatus, mcpStatus: record.mcpStatus, buildabilityVerdict: record.buildabilityVerdict };
  const auth = String(output.auth_methods || '').split(',').map((item) => item.trim()).filter(Boolean);
  if (auth.length) record.authMethods = auth;
  if (allowedAccess.has(output.self_serve_status)) record.selfServeStatus = output.self_serve_status;
  if (allowedMcp.has(output.mcp_status)) record.mcpStatus = output.mcp_status;
  if (allowedVerdict.has(output.buildability_verdict)) { record.buildabilityVerdict = output.buildability_verdict; record.agentCallability = callability(output.buildability_verdict); }
  const evidence = parseEvidence(output.evidence_urls);
  record.evidence = ['auth','access','api','mcp'].map((field) => ({ field, url: evidence[field] || record.evidence.find((item) => item.field === field)?.url || 'unknown', sourceType: isHttp(evidence[field]) ? 'official_docs' : 'unverified', retrievedAt: '2026-08-17', status: isHttp(evidence[field]) ? 'linked' : 'unknown' }));
  record.postRepairHoldout = { blindComparison: blind?.matches, verifierNote: output.verification_note, verifierConfidence: output.confidence, correctedAt: '2026-08-17', note: 'This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json.' };
  changes.push({ appId: record.id, appName: record.appName, before, after: { authMethods: record.authMethods, selfServeStatus: record.selfServeStatus, mcpStatus: record.mcpStatus, buildabilityVerdict: record.buildabilityVerdict } });
}
const countBy = (key) => Object.fromEntries(Object.entries(finalData.records.reduce((acc, record) => { acc[record[key]] = (acc[record[key]] || 0) + 1; return acc; }, {})).sort((a,b) => b[1] - a[1]));
const linked = finalData.records.flatMap((record) => record.evidence).filter((item) => item.status === 'linked').length;
finalData.summary = { ...finalData.summary, generatedAt: new Date().toISOString(), verdictCounts: countBy('buildabilityVerdict'), selfServeCounts: countBy('selfServeStatus'), mcpCounts: countBy('mcpStatus'), confidenceCounts: countBy('confidence'), apiBreadthCounts: countBy('apiSurfaceBreadth'), evidenceCoverage: { linkedSlots: linked, totalSlots: finalData.records.length * 4, percentage: Number(((linked / 400) * 100).toFixed(1)) }, postRepairHoldout: { rawBlindComparison: comparison.summary, correctionsApplied: changes.length, limitation: 'The 10-record holdout did not return the requested API breadth field, so it is retained as an error-discovery correction loop, not a generalisable post-repair accuracy estimate.' } };
fs.writeFileSync(finalPath, JSON.stringify(finalData, null, 2));
fs.writeFileSync(`${root}/data/post_repair_holdout_corrections.json`, JSON.stringify({ generatedAt: new Date().toISOString(), changes }, null, 2));
fs.writeFileSync(`${root}/client/src/data/research.ts`, `// Evidence Ledger: canonical research output with audited samples and reconciled evidence.\nexport const research = ${JSON.stringify(finalData, null, 2)} as const;\n`);
console.log(JSON.stringify({ correctionsApplied: changes.length }, null, 2));
