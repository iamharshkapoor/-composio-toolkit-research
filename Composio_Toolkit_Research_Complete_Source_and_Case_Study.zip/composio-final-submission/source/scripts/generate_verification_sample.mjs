import fs from 'node:fs';

/**
 * Selects a stratified verification sample. It intentionally includes low-confidence,
 * gated, and MCP-claim records rather than cherry-picking easy wins.
 */
const { records } = JSON.parse(fs.readFileSync('/home/ubuntu/composio-toolkit-research/data/research_results_final.json', 'utf8'));
const picked = new Map();
function add(record, rationale) {
  if (!record || picked.size >= 25) return;
  if (!picked.has(record.id)) picked.set(record.id, { record, rationale });
}
const categories = [...new Set(records.map((record) => record.category))];
for (const category of categories) {
  const candidates = records.filter((record) => record.category === category)
    .sort((a, b) => Number(b.confidence !== 'high') - Number(a.confidence !== 'high') || b.qualityFlags.length - a.qualityFlags.length);
  add(candidates[0], 'Category coverage; prioritise ambiguity or quality flags.');
  add(candidates[1], 'Second category record to reduce category selection bias.');
}
for (const record of records.filter((record) => record.mcpStatus !== 'mcp_not_verified')) add(record, 'MCP claim or MCP feasibility requires independent review.');
for (const record of records.filter((record) => ['partner_gated', 'contact_sales', 'app_review', 'admin_approval'].includes(record.selfServeStatus))) add(record, 'Access gate classification requires independent review.');
for (const record of records.filter((record) => record.confidence !== 'high')) add(record, 'Low or medium confidence requires independent review.');
const sample = [...picked.values()].slice(0, 25).map(({ record, rationale }) => ({
  appId: record.id,
  appName: record.appName,
  category: record.category,
  selectionRationale: rationale,
  pass0: {
    authMethods: record.authMethods.join(', '),
    selfServeStatus: record.selfServeStatus,
    apiSurfaceBreadth: record.apiSurfaceBreadth,
    mcpStatus: record.mcpStatus,
    buildabilityVerdict: record.buildabilityVerdict,
  },
  evidence: record.evidence,
  verificationStatus: 'pending_independent_browser_review',
}));
fs.writeFileSync('/home/ubuntu/composio-toolkit-research/data/verification_sample.json', JSON.stringify(sample, null, 2));
fs.writeFileSync('/home/ubuntu/composio-toolkit-research/data/verification_log.csv', [
  'app_id,app_name,category,selection_rationale,field_name,pass0_value,verified_value,match,source_url,source_excerpt,error_type,correction_reason,review_method,reviewed_at',
  ...sample.map((item) => `${item.appId},"${item.appName}","${item.category}","${item.selectionRationale}",,,,,,,,pending_independent_browser_review,`),
].join('\n'));
console.log(JSON.stringify({ sampleSize: sample.length, sample }, null, 2));
