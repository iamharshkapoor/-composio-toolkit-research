import fs from 'node:fs';

/** Evidence Ledger second-pass repair: refreshes only records outside the audited sample. */
const root = '/home/ubuntu/composio-toolkit-research';
const finalPath = `${root}/data/research_results_final.json`;
const repairPath = `${root}/data/second_pass_repair_raw.json`;
const date = '2026-08-17';
const finalData = JSON.parse(fs.readFileSync(finalPath, 'utf8'));
const repairRaw = JSON.parse(fs.readFileSync(repairPath, 'utf8'));
const allowed = {
  selfServe: new Set(['self_serve_free','self_serve_trial','self_serve_paid','admin_approval','app_review','partner_gated','contact_sales','unavailable','unknown']),
  mcp: new Set(['native_official_mcp','native_third_party_mcp','composio_mcp_exposure','mcp_possible_via_api','mcp_not_verified']),
  verdict: new Set(['build_now','build_with_review','outreach_required','deprioritize','unknown']),
  breadth: new Set(['narrow','moderate','broad','platform_wide','unknown']),
};
const clean = (value) => String(value ?? '').trim();
const enumOrUnknown = (value, set) => { const normalized = clean(value).toLowerCase().replaceAll(' ', '_').replaceAll('-', '_'); return set.has(normalized) ? normalized : 'unknown'; };
const isHttp = (value) => /^https?:\/\//.test(value);
function parseEvidence(value) {
  const output = { auth: 'unknown', access: 'unknown', api: 'unknown', mcp: 'unknown' };
  clean(value).split('|').forEach((chunk) => { const [key, ...rest] = chunk.trim().split('='); const name = clean(key).toLowerCase(); if (name in output) output[name] = clean(rest.join('=')); });
  return output;
}
function sourceType(url) { if (!isHttp(url)) return 'unverified'; if (url.includes('github.com')) return 'official_github_or_repository'; if (/docs\.|developer\.|developers\.|api\.|open\.|learn\./.test(url)) return 'official_docs'; return 'official_product_or_help'; }
function api(value) {
  const input = clean(value);
  const explicit = input.match(/breadth\s*=\s*([a-z_\-]+)/i)?.[1];
  const inferred = input.match(/\b(platform[_\s-]?wide|full|broad|moderate|narrow)\b/i)?.[1];
  const alias = { full: 'platform_wide', platform_wide: 'platform_wide', platformwide: 'platform_wide', broad: 'broad', moderate: 'moderate', narrow: 'narrow' };
  const normalized = clean(explicit || inferred).toLowerCase().replaceAll(' ', '_').replaceAll('-', '_');
  return { breadth: alias[normalized] || enumOrUnknown(normalized, allowed.breadth), summary: input.replace(/breadth\s*=\s*[a-z_\-]+\s*;?\s*/i, '').trim() || 'No API-surface summary returned.', protocols: ['REST','GraphQL','Webhooks','SDK','CLI'].filter((term) => new RegExp(term, 'i').test(input)) };
}
function callability(verdict) { return ({ build_now: 'direct_now', build_with_review: 'feasible_with_build', outreach_required: 'blocked_by_access', deprioritize: 'not_recommended' })[verdict] || 'unknown'; }
function flags(record) {
  const output = [];
  if (!record.whatItDoes) output.push('description_missing');
  if (!record.authMethods.length) output.push('auth_missing');
  if (record.selfServeStatus === 'unknown') output.push('access_unknown');
  if (record.apiSurfaceBreadth === 'unknown') output.push('api_breadth_unknown');
  if (record.mcpStatus === 'native_official_mcp' && !record.evidence.some((item) => item.field === 'mcp' && item.status === 'linked')) output.push('native_mcp_without_url');
  if (record.buildabilityVerdict === 'build_now' && ['partner_gated','contact_sales','unavailable'].includes(record.selfServeStatus)) output.push('buildability_access_conflict');
  if (record.evidence.filter((item) => item.status === 'linked').length < 2) output.push('insufficient_linked_evidence');
  return output;
}
const repairLog = [];
for (const { output, error } of repairRaw.results) {
  if (!output || error) continue;
  const record = finalData.records.find((item) => item.id === Number(output.app_id));
  if (!record || record.verification?.sampled) continue;
  const before = { authMethods: record.authMethods, selfServeStatus: record.selfServeStatus, apiSurfaceBreadth: record.apiSurfaceBreadth, mcpStatus: record.mcpStatus, buildabilityVerdict: record.buildabilityVerdict };
  const parsed = parseEvidence(output.evidence_urls);
  const surface = api(output.api_surface);
  const after = {
    authMethods: clean(output.auth_methods).split(',').map((item) => item.trim()).filter(Boolean),
    selfServeStatus: enumOrUnknown(output.self_serve_status, allowed.selfServe),
    apiSurfaceBreadth: surface.breadth,
    mcpStatus: enumOrUnknown(output.mcp_status, allowed.mcp),
    buildabilityVerdict: enumOrUnknown(output.buildability_verdict, allowed.verdict),
  };
  record.whatItDoes = clean(output.what_it_does) || record.whatItDoes;
  record.authMethods = after.authMethods;
  record.selfServeStatus = after.selfServeStatus;
  record.selfServeSummary = clean(output.self_serve_summary);
  record.apiProtocols = surface.protocols.length ? surface.protocols : ['Unknown'];
  record.apiSurfaceBreadth = after.apiSurfaceBreadth;
  record.apiSurfaceSummary = surface.summary;
  record.mcpStatus = after.mcpStatus;
  record.buildabilityVerdict = after.buildabilityVerdict;
  record.agentCallability = callability(after.buildabilityVerdict);
  record.primaryBlocker = clean(output.primary_blocker || 'Unknown');
  record.recommendedNextStep = clean(output.recommended_next_step);
  record.confidence = ['high','medium','low'].includes(clean(output.confidence).toLowerCase()) ? clean(output.confidence).toLowerCase() : 'low';
  record.uncertainties = clean(output.uncertainties || 'None identified');
  record.evidenceExcerpt = clean(output.evidence_excerpt);
  record.evidence = Object.entries(parsed).map(([field, url]) => ({ field, url, sourceType: sourceType(url), retrievedAt: date, status: isHttp(url) ? 'linked' : 'unknown' }));
  record.researchPass = 1;
  record.secondPass = { completedAt: date, previous: before, replaced: after };
  record.qualityFlags = flags(record);
  repairLog.push({ appId: record.id, appName: record.appName, changed: Object.keys(after).filter((key) => JSON.stringify(before[key]) !== JSON.stringify(after[key])) });
}
const countBy = (key) => Object.fromEntries(Object.entries(finalData.records.reduce((acc, record) => { const value = record[key]; acc[value] = (acc[value] || 0) + 1; return acc; }, {})).sort((a,b) => b[1] - a[1]));
const linked = finalData.records.flatMap((record) => record.evidence).filter((item) => item.status === 'linked').length;
finalData.summary = { ...finalData.summary, generatedAt: new Date().toISOString(), verdictCounts: countBy('buildabilityVerdict'), selfServeCounts: countBy('selfServeStatus'), mcpCounts: countBy('mcpStatus'), confidenceCounts: countBy('confidence'), apiBreadthCounts: countBy('apiSurfaceBreadth'), evidenceCoverage: { linkedSlots: linked, totalSlots: finalData.records.length * 4, percentage: Number(((linked / (finalData.records.length * 4)) * 100).toFixed(1)) }, secondPass: { repairedRecords: repairLog.length, recordsWithClassificationChanges: repairLog.filter((item) => item.changed.length).length } };
fs.writeFileSync(finalPath, JSON.stringify(finalData, null, 2));
fs.writeFileSync(`${root}/data/second_pass_repair_log.json`, JSON.stringify({ generatedAt: new Date().toISOString(), repairedRecords: repairLog.length, repairLog }, null, 2));
fs.writeFileSync(`${root}/client/src/data/research.ts`, `// Evidence Ledger: canonical research output with audited sample and second-pass repair.\nexport const research = ${JSON.stringify(finalData, null, 2)} as const;\n`);
console.log(JSON.stringify(finalData.summary.secondPass, null, 2));
