import fs from 'node:fs';

/**
 * Evidence Ledger verification reconciler.
 * Applies independently checked values only to sampled records and preserves the
 * original first-pass values, source links, match decisions, and correction reasons.
 */
const root = '/home/ubuntu/composio-toolkit-research';
const finalPath = `${root}/data/research_results_final.json`;
const verificationPath = `${root}/data/verification_results_raw.json`;
const date = '2026-08-17';
const finalData = JSON.parse(fs.readFileSync(finalPath, 'utf8'));
const verificationRaw = JSON.parse(fs.readFileSync(verificationPath, 'utf8'));

function clean(value) { return String(value ?? '').trim(); }
function parseEvidence(value) {
  const output = { auth: 'unknown', access: 'unknown', api: 'unknown', mcp: 'unknown' };
  clean(value).split('|').forEach((chunk) => {
    const [key, ...rest] = chunk.trim().split('=');
    const normalized = clean(key).toLowerCase();
    const url = clean(rest.join('='));
    if (normalized in output && url) output[normalized] = url;
  });
  return output;
}
function isHttp(value) { return /^https?:\/\//.test(value); }
function sourceType(url) {
  if (!isHttp(url)) return 'unverified';
  if (url.includes('github.com')) return 'official_github_or_repository';
  if (/docs\.|developer\.|developers\.|api\.|open\.|learn\./.test(url)) return 'official_docs';
  return 'official_product_or_help';
}
function matchValue(value) { return value === true; }
function updateAgentCallability(verdict) {
  if (verdict === 'build_now') return 'direct_now';
  if (verdict === 'build_with_review') return 'feasible_with_build';
  if (verdict === 'outreach_required') return 'blocked_by_access';
  if (verdict === 'deprioritize') return 'not_recommended';
  return 'unknown';
}

const checks = [];
const corrections = [];
const rows = [];
for (const { output, error } of verificationRaw.results) {
  if (!output || error) continue;
  const record = finalData.records.find((item) => item.id === Number(output.app_id));
  if (!record) continue;
  const before = {
    authMethods: record.authMethods.join(', '),
    selfServeStatus: record.selfServeStatus,
    apiSurfaceBreadth: record.apiSurfaceBreadth,
    mcpStatus: record.mcpStatus,
    buildabilityVerdict: record.buildabilityVerdict,
  };
  const checksForRecord = {
    auth: matchValue(output.auth_match),
    selfServe: matchValue(output.self_serve_match),
    apiBreadth: matchValue(output.api_breadth_match),
    mcp: matchValue(output.mcp_match),
    verdict: matchValue(output.verdict_match),
  };
  const verified = {
    authMethods: clean(output.verified_auth),
    selfServeStatus: clean(output.verified_self_serve),
    apiSurfaceBreadth: clean(output.verified_api_breadth),
    mcpStatus: clean(output.verified_mcp),
    buildabilityVerdict: clean(output.verified_verdict),
  };
  const verificationEvidence = parseEvidence(output.verification_urls);
  const anyCorrection = Object.values(checksForRecord).some((value) => !value);
  record.verification = {
    sampled: true,
    checkedAt: date,
    reviewMethod: 'independent_parallel_research_plus_official_source_review',
    reviewConfidence: clean(output.review_confidence),
    pass0: before,
    verified,
    matches: checksForRecord,
    correctionSummary: clean(output.correction_summary),
    evidence: Object.entries(verificationEvidence).map(([field, url]) => ({ field, url, sourceType: sourceType(url), status: isHttp(url) ? 'linked' : 'unknown' })),
  };
  record.humanReviewStatus = anyCorrection ? 'sampled_corrected' : 'sampled_pass';
  record.researchPass = 2;
  if (anyCorrection) {
    record.authMethods = verified.authMethods.split(',').map((item) => item.trim()).filter(Boolean);
    record.selfServeStatus = verified.selfServeStatus;
    record.apiSurfaceBreadth = verified.apiSurfaceBreadth;
    record.mcpStatus = verified.mcpStatus;
    record.buildabilityVerdict = verified.buildabilityVerdict;
    record.agentCallability = updateAgentCallability(verified.buildabilityVerdict);
    record.evidence = record.evidence.map((item) => {
      const url = verificationEvidence[item.field];
      return isHttp(url) ? { ...item, url, sourceType: sourceType(url), status: 'linked', retrievedAt: date } : item;
    });
    corrections.push({
      appId: record.id,
      appName: record.appName,
      correctionSummary: clean(output.correction_summary),
      correctedFields: Object.entries(checksForRecord).filter(([, match]) => !match).map(([field]) => field),
    });
  }
  for (const [field, match] of Object.entries(checksForRecord)) {
    const fields = {
      auth: ['authMethods', 'authMethods'],
      selfServe: ['selfServeStatus', 'selfServeStatus'],
      apiBreadth: ['apiSurfaceBreadth', 'apiSurfaceBreadth'],
      mcp: ['mcpStatus', 'mcpStatus'],
      verdict: ['buildabilityVerdict', 'buildabilityVerdict'],
    };
    const [beforeField, verifiedField] = fields[field];
    rows.push({
      appId: record.id,
      appName: record.appName,
      category: record.category,
      fieldName: field,
      pass0Value: before[beforeField],
      verifiedValue: verified[verifiedField],
      match,
      sourceUrl: verificationEvidence[field === 'selfServe' ? 'access' : field === 'apiBreadth' ? 'api' : field],
      correctionSummary: clean(output.correction_summary),
      reviewMethod: 'independent_parallel_research_plus_official_source_review',
      reviewedAt: date,
    });
  }
  checks.push({ appId: record.id, appName: record.appName, ...checksForRecord, exactRecordMatch: Object.values(checksForRecord).every(Boolean) });
}

const fields = ['auth', 'selfServe', 'apiBreadth', 'mcp', 'verdict'];
const accuracyByField = Object.fromEntries(fields.map((field) => {
  const fieldRows = rows.filter((row) => row.fieldName === field);
  const matches = fieldRows.filter((row) => row.match).length;
  return [field, { matches, checked: fieldRows.length, percentage: Number(((matches / fieldRows.length) * 100).toFixed(1)) }];
}));
const exactMatches = checks.filter((item) => item.exactRecordMatch).length;
const verificationMetrics = {
  sampleSize: checks.length,
  fieldsChecked: rows.length,
  recordLevelExactMatch: { matches: exactMatches, checked: checks.length, percentage: Number(((exactMatches / checks.length) * 100).toFixed(1)) },
  fieldAccuracy: accuracyByField,
  correctionCount: corrections.length,
  correctionRate: Number(((corrections.length / checks.length) * 100).toFixed(1)),
  remainingUnknownsInSample: finalData.records.filter((record) => record.verification?.sampled && [record.selfServeStatus, record.apiSurfaceBreadth, record.mcpStatus, record.buildabilityVerdict].includes('unknown')).length,
};

const countBy = (key) => Object.fromEntries(Object.entries(finalData.records.reduce((acc, record) => {
  const value = record[key];
  acc[value] = (acc[value] || 0) + 1;
  return acc;
}, {})).sort((a, b) => b[1] - a[1]));
const totalEvidenceSlots = finalData.records.length * 4;
const linkedEvidence = finalData.records.flatMap((record) => record.evidence).filter((item) => item.status === 'linked').length;
finalData.summary = {
  ...finalData.summary,
  generatedAt: new Date().toISOString(),
  verdictCounts: countBy('buildabilityVerdict'),
  selfServeCounts: countBy('selfServeStatus'),
  mcpCounts: countBy('mcpStatus'),
  confidenceCounts: countBy('confidence'),
  apiBreadthCounts: countBy('apiSurfaceBreadth'),
  evidenceCoverage: { linkedSlots: linkedEvidence, totalSlots: totalEvidenceSlots, percentage: Number(((linkedEvidence / totalEvidenceSlots) * 100).toFixed(1)) },
  verificationMetrics,
};
finalData.report.verification = { metrics: verificationMetrics, corrections };

fs.writeFileSync(finalPath, JSON.stringify(finalData, null, 2));
fs.writeFileSync(`${root}/data/verification_log.json`, JSON.stringify({ generatedAt: new Date().toISOString(), rows, checks, corrections, metrics: verificationMetrics }, null, 2));
const esc = (value) => `"${String(value ?? '').replaceAll('"', '""')}"`;
const header = ['app_id','app_name','category','field_name','pass0_value','verified_value','match','source_url','correction_summary','review_method','reviewed_at'];
const csv = [header.join(',')].concat(rows.map((row) => [row.appId, row.appName, row.category, row.fieldName, row.pass0Value, row.verifiedValue, row.match, row.sourceUrl, row.correctionSummary, row.reviewMethod, row.reviewedAt].map(esc).join(','))).join('\n');
fs.writeFileSync(`${root}/data/verification_log.csv`, csv);
fs.writeFileSync(`${root}/client/src/data/research.ts`, `// Evidence Ledger: canonical research output with sample verification applied.\nexport const research = ${JSON.stringify(finalData, null, 2)} as const;\n`);
fs.writeFileSync(`${root}/reports/verification_report.md`, `# Verification Report\n\n- **Sample:** ${verificationMetrics.sampleSize} strategically selected apps\n- **Fields checked:** ${verificationMetrics.fieldsChecked}\n- **Record-level exact match:** ${verificationMetrics.recordLevelExactMatch.matches}/${verificationMetrics.recordLevelExactMatch.checked} (${verificationMetrics.recordLevelExactMatch.percentage}%)\n- **Corrections applied:** ${verificationMetrics.correctionCount}/${verificationMetrics.sampleSize} (${verificationMetrics.correctionRate}%)\n\n## Field-level accuracy\n\n${Object.entries(accuracyByField).map(([field, metric]) => `- **${field}:** ${metric.matches}/${metric.checked} (${metric.percentage}%)`).join('\n')}\n\n## Corrections\n\n${corrections.length ? corrections.map((item) => `- **${item.appName} (${item.appId})** — corrected ${item.correctedFields.join(', ')}. ${item.correctionSummary}`).join('\n') : 'No sampled record corrections were required.'}\n\n## Limitation\n\nThis is a stratified evidence audit, not a probability sample. Its purpose is to expose high-risk errors in access, MCP, and buildability classifications, not to produce a population estimate with a confidence interval.\n`);
console.log(JSON.stringify({ verificationMetrics, corrections }, null, 2));
