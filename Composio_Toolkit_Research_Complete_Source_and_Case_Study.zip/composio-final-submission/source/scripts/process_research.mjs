import fs from 'node:fs';
import path from 'node:path';

/**
 * Evidence Ledger data processor.
 * Turns parallel research responses into a canonical, auditable dataset. It does
 * not manufacture missing evidence: unknown or absent source fields are flagged.
 */
const root = '/home/ubuntu/composio-toolkit-research';
const dataDir = path.join(root, 'data');
const rawPath = path.join(dataDir, 'research_results_pass0.json');
const date = '2026-08-17';

fs.mkdirSync(path.join(root, 'client/src/data'), { recursive: true });

const raw = JSON.parse(fs.readFileSync(rawPath, 'utf8'));
const allowedSelfServe = new Set([
  'self_serve_free', 'self_serve_trial', 'self_serve_paid', 'admin_approval',
  'app_review', 'partner_gated', 'contact_sales', 'unavailable', 'unknown',
]);
const allowedMcp = new Set([
  'native_official_mcp', 'native_third_party_mcp', 'composio_mcp_exposure',
  'mcp_possible_via_api', 'mcp_not_verified',
]);
const allowedVerdicts = new Set([
  'build_now', 'build_with_review', 'outreach_required', 'deprioritize', 'unknown',
]);
const allowedBreadth = new Set(['narrow', 'moderate', 'broad', 'platform_wide', 'unknown']);

function clean(value) {
  return String(value ?? '').trim();
}

function enumOrUnknown(value, allowed) {
  const normalized = clean(value).toLowerCase().replaceAll(' ', '_').replaceAll('-', '_');
  return allowed.has(normalized) ? normalized : 'unknown';
}

function parseEvidence(value) {
  const fields = { auth: 'unknown', access: 'unknown', api: 'unknown', mcp: 'unknown' };
  clean(value).split('|').forEach((chunk) => {
    const [rawKey, ...rest] = chunk.trim().split('=');
    const key = clean(rawKey).toLowerCase();
    const url = clean(rest.join('='));
    if (key in fields && url) fields[key] = url;
  });
  return fields;
}

function isHttpUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
}

function inferSourceType(url) {
  if (!isHttpUrl(url)) return 'unverified';
  if (url.includes('github.com')) return 'official_github_or_repository';
  if (/docs\.|developer\.|developers\.|api\.|open\.|learn\./.test(url)) return 'official_docs';
  return 'official_product_or_help';
}

function parseApiSurface(value) {
  const input = clean(value);
  const matched = input.match(/breadth\s*=\s*([a-z_\-]+)/i);
  const breadth = enumOrUnknown(matched?.[1] || 'unknown', allowedBreadth);
  const summary = input.replace(/breadth\s*=\s*[a-z_\-]+\s*;?\s*/i, '').trim() || 'No API-surface summary returned.';
  const protocols = ['REST', 'GraphQL', 'Webhooks', 'SDK', 'CLI']
    .filter((term) => new RegExp(term, 'i').test(input));
  return { breadth, summary, protocols: protocols.length ? protocols : ['Unknown'] };
}

function buildAgentCallability(verdict) {
  if (verdict === 'build_now') return 'direct_now';
  if (verdict === 'build_with_review') return 'feasible_with_build';
  if (verdict === 'outreach_required') return 'blocked_by_access';
  if (verdict === 'deprioritize') return 'not_recommended';
  return 'unknown';
}

const records = raw.results.map(({ input, output, error }) => {
  const source = output ?? {};
  const subject = clean(input).split('|').map((part) => part.trim());
  const parsedEvidence = parseEvidence(source.evidence_urls);
  const api = parseApiSurface(source.api_surface);
  const record = {
    id: Number(source.app_id || subject[0]),
    appName: clean(source.app_name || subject[2]),
    category: clean(source.category || subject[1]),
    startingHint: clean(subject[3]),
    whatItDoes: clean(source.what_it_does),
    authMethods: clean(source.auth_methods).split(',').map((item) => item.trim()).filter(Boolean),
    selfServeStatus: enumOrUnknown(source.self_serve_status, allowedSelfServe),
    selfServeSummary: clean(source.self_serve_summary),
    apiProtocols: api.protocols,
    apiSurfaceBreadth: api.breadth,
    apiSurfaceSummary: api.summary,
    mcpStatus: enumOrUnknown(source.mcp_status, allowedMcp),
    agentCallability: buildAgentCallability(enumOrUnknown(source.buildability_verdict, allowedVerdicts)),
    buildabilityVerdict: enumOrUnknown(source.buildability_verdict, allowedVerdicts),
    primaryBlocker: clean(source.primary_blocker || 'Unknown'),
    recommendedNextStep: clean(source.recommended_next_step),
    confidence: ['high', 'medium', 'low'].includes(clean(source.confidence).toLowerCase()) ? clean(source.confidence).toLowerCase() : 'low',
    uncertainties: clean(source.uncertainties || 'None identified'),
    researchedAt: date,
    researchPass: 0,
    evidenceExcerpt: clean(source.evidence_excerpt),
    evidence: Object.entries(parsedEvidence).map(([field, url]) => ({
      field,
      url,
      sourceType: inferSourceType(url),
      retrievedAt: date,
      status: isHttpUrl(url) ? 'linked' : 'unknown',
    })),
    humanReviewStatus: 'not_reviewed',
    researchError: clean(error),
  };
  const flags = [];
  if (!record.id || !record.appName || !record.category) flags.push('identity_missing');
  if (!record.whatItDoes) flags.push('description_missing');
  if (record.authMethods.length === 0) flags.push('auth_missing');
  if (record.selfServeStatus === 'unknown') flags.push('access_unknown');
  if (record.apiSurfaceBreadth === 'unknown') flags.push('api_breadth_unknown');
  if (record.mcpStatus === 'native_official_mcp' && !isHttpUrl(parsedEvidence.mcp)) flags.push('native_mcp_without_url');
  if (record.buildabilityVerdict === 'build_now' && ['partner_gated', 'contact_sales', 'unavailable'].includes(record.selfServeStatus)) flags.push('buildability_access_conflict');
  if (record.evidence.filter((item) => item.status === 'linked').length < 2) flags.push('insufficient_linked_evidence');
  if (record.researchError) flags.push('subtask_error');
  record.qualityFlags = flags;
  return record;
}).sort((a, b) => a.id - b.id);

const ids = records.map((record) => record.id);
const duplicateIds = ids.filter((id, index) => ids.indexOf(id) !== index);
const missingIds = Array.from({ length: 100 }, (_, index) => index + 1).filter((id) => !ids.includes(id));
const countBy = (key) => Object.fromEntries(Object.entries(records.reduce((acc, record) => {
  const value = record[key];
  acc[value] = (acc[value] || 0) + 1;
  return acc;
}, {})).sort((a, b) => b[1] - a[1]));
const countQualityFlags = records.reduce((acc, record) => {
  record.qualityFlags.forEach((flag) => { acc[flag] = (acc[flag] || 0) + 1; });
  return acc;
}, {});
const linkedEvidence = records.flatMap((record) => record.evidence).filter((item) => item.status === 'linked').length;
const totalEvidenceSlots = records.length * 4;

const summary = {
  generatedAt: new Date().toISOString(),
  researchAsOf: date,
  records: records.length,
  categories: [...new Set(records.map((record) => record.category))].length,
  verdictCounts: countBy('buildabilityVerdict'),
  selfServeCounts: countBy('selfServeStatus'),
  mcpCounts: countBy('mcpStatus'),
  confidenceCounts: countBy('confidence'),
  apiBreadthCounts: countBy('apiSurfaceBreadth'),
  evidenceCoverage: {
    linkedSlots: linkedEvidence,
    totalSlots: totalEvidenceSlots,
    percentage: Number(((linkedEvidence / totalEvidenceSlots) * 100).toFixed(1)),
  },
  qualityFlags: countQualityFlags,
  missingIds,
  duplicateIds,
};

const report = {
  generatedAt: new Date().toISOString(),
  controls: {
    expectedRecords: 100,
    actualRecords: records.length,
    missingIds,
    duplicateIds,
    identityComplete: records.filter((record) => !record.qualityFlags.includes('identity_missing')).length,
    linkedEvidenceCoverage: summary.evidenceCoverage,
    recordsWithFlags: records.filter((record) => record.qualityFlags.length > 0).map((record) => ({ id: record.id, appName: record.appName, flags: record.qualityFlags })),
  },
};

const csvColumns = ['id', 'appName', 'category', 'whatItDoes', 'authMethods', 'selfServeStatus', 'selfServeSummary', 'apiProtocols', 'apiSurfaceBreadth', 'apiSurfaceSummary', 'mcpStatus', 'buildabilityVerdict', 'primaryBlocker', 'recommendedNextStep', 'confidence', 'uncertainties', 'evidenceAuth', 'evidenceAccess', 'evidenceApi', 'evidenceMcp', 'qualityFlags'];
const esc = (value) => `"${String(value ?? '').replaceAll('"', '""')}"`;
const csv = [csvColumns.join(',')].concat(records.map((record) => {
  const evidence = Object.fromEntries(record.evidence.map((item) => [item.field, item.url]));
  return [
    record.id, record.appName, record.category, record.whatItDoes, record.authMethods.join('; '), record.selfServeStatus,
    record.selfServeSummary, record.apiProtocols.join('; '), record.apiSurfaceBreadth, record.apiSurfaceSummary, record.mcpStatus,
    record.buildabilityVerdict, record.primaryBlocker, record.recommendedNextStep, record.confidence, record.uncertainties,
    evidence.auth, evidence.access, evidence.api, evidence.mcp, record.qualityFlags.join('; '),
  ].map(esc).join(',');
})).join('\n');

const manifest = records.map(({ id, appName, category, startingHint }) => ({ id, appName, category, startingHint }));
fs.writeFileSync(path.join(dataDir, 'research_results_final.json'), JSON.stringify({ records, summary, report }, null, 2));
fs.writeFileSync(path.join(dataDir, 'research_results_final.csv'), csv);
fs.writeFileSync(path.join(dataDir, 'apps_manifest.json'), JSON.stringify(manifest, null, 2));
fs.writeFileSync(path.join(dataDir, 'quality_report.json'), JSON.stringify(report, null, 2));
fs.writeFileSync(path.join(dataDir, 'research_summary.json'), JSON.stringify(summary, null, 2));
fs.writeFileSync(path.join(root, 'client/src/data/research.ts'), `// Evidence Ledger: generated from the canonical research dataset.\nexport const research = ${JSON.stringify({ records, summary, report }, null, 2)} as const;\n`);

console.log(JSON.stringify({ records: records.length, summary, report: report.controls }, null, 2));
