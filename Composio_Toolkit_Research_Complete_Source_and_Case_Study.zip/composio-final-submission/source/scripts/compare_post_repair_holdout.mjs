import fs from 'node:fs';

/** Evidence Ledger holdout comparator: strict, transparent post-repair agreement calculation. */
const root = '/home/ubuntu/composio-toolkit-research';
const finalData = JSON.parse(fs.readFileSync(`${root}/data/research_results_final.json`, 'utf8'));
const holdout = JSON.parse(fs.readFileSync(`${root}/data/post_repair_holdout_raw.json`, 'utf8'));
const normalize = (value) => String(value ?? '').toLowerCase().replace(/oauth\s*2(\.0)?/g, 'oauth2').replace(/[()]/g, '').replace(/\s+/g, ' ').trim();
const authSet = (value) => {
  const lower = normalize(value);
  const set = new Set();
  if (/oauth|authorization code|pkce/.test(lower)) set.add('oauth2');
  if (/api[ -]?key|api token|app id\/?app secret|client credentials|secret key/.test(lower)) set.add('api_credential');
  if (/pat|personal access/.test(lower)) set.add('pat');
  if (/jwt/.test(lower)) set.add('jwt');
  if (/hmac/.test(lower)) set.add('hmac');
  if (/basic auth/.test(lower) && !/api[ -]?key|api token/.test(lower)) set.add('basic');
  if (!set.size && lower) set.add(lower);
  return set;
};
const sameAuth = (a, b) => { const left = authSet(a); const right = authSet(b); return [...left].every((item) => right.has(item)) || [...right].every((item) => left.has(item)); };
const fields = ['auth', 'selfServe', 'apiBreadth', 'mcp', 'verdict'];
const metric = Object.fromEntries(fields.map((field) => [field, { matches: 0, checked: 0, percentage: 0 }]));
const log = [];
for (const { output, error } of holdout.results) {
  if (!output || error) continue;
  const record = finalData.records.find((item) => item.id === Number(output.app_id));
  if (!record) continue;
  const comparison = {
    auth: sameAuth(record.authMethods.join(', '), output.auth_methods),
    selfServe: normalize(record.selfServeStatus) === normalize(output.self_serve_status),
    apiBreadth: output.api_breadth ? normalize(record.apiSurfaceBreadth) === normalize(output.api_breadth) : null,
    mcp: normalize(record.mcpStatus) === normalize(output.mcp_status),
    verdict: normalize(record.buildabilityVerdict) === normalize(output.buildability_verdict),
  };
  fields.forEach((field) => { if (comparison[field] !== null) { metric[field].checked += 1; if (comparison[field]) metric[field].matches += 1; } });
  const scoredFields = fields.filter((field) => comparison[field] !== null);
  log.push({ appId: record.id, appName: record.appName, category: record.category, matches: comparison, scoredFields, exactRecordMatch: scoredFields.every((field) => comparison[field]), verifierNote: output.verification_note, verifierConfidence: output.confidence, verifierEvidence: output.evidence_urls });
}
fields.forEach((field) => { metric[field].percentage = metric[field].checked ? Number(((metric[field].matches / metric[field].checked) * 100).toFixed(1)) : null; });
const exact = log.filter((item) => item.exactRecordMatch).length;
const summary = { sampleSize: log.length, fieldsChecked: log.length * fields.length, recordLevelExactMatch: { matches: exact, checked: log.length, percentage: Number(((exact / log.length) * 100).toFixed(1)) }, fieldAccuracy: metric, mismatchCount: log.filter((item) => !item.exactRecordMatch).length, design: 'One app per category; independently researched after the second-pass repair; classifications were not disclosed to the verifier before research.' };
const artifact = { generatedAt: new Date().toISOString(), summary, records: log };
fs.writeFileSync(`${root}/data/post_repair_holdout.json`, JSON.stringify(artifact, null, 2));
fs.writeFileSync(`${root}/reports/post_repair_holdout_summary.json`, JSON.stringify(summary, null, 2));
console.log(JSON.stringify(summary, null, 2));
