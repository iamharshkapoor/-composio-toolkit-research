import fs from 'node:fs';

/** Evidence Ledger validation gate: fails loudly when mandatory submission controls are broken. */
const file = '/home/ubuntu/composio-toolkit-research/data/research_results_final.json';
const { records, summary, report } = JSON.parse(fs.readFileSync(file, 'utf8'));
const failures = [];

if (records.length !== 100) failures.push(`Expected 100 records, found ${records.length}.`);
if (summary.categories !== 10) failures.push(`Expected 10 categories, found ${summary.categories}.`);
if (summary.missingIds.length) failures.push(`Missing IDs: ${summary.missingIds.join(', ')}`);
if (summary.duplicateIds.length) failures.push(`Duplicate IDs: ${summary.duplicateIds.join(', ')}`);
for (const record of records) {
  for (const field of ['appName', 'category', 'whatItDoes', 'selfServeStatus', 'apiSurfaceBreadth', 'mcpStatus', 'buildabilityVerdict', 'confidence']) {
    if (!record[field]) failures.push(`${record.id} ${record.appName}: missing ${field}`);
  }
  if (record.mcpStatus === 'native_official_mcp') {
    const mcp = record.evidence.find((item) => item.field === 'mcp');
    if (!mcp || mcp.status !== 'linked') failures.push(`${record.id} ${record.appName}: native MCP lacks linked evidence.`);
  }
}
const output = { passed: failures.length === 0, checkedAt: new Date().toISOString(), failures, summary, report };
fs.writeFileSync('/home/ubuntu/composio-toolkit-research/data/validation_result.json', JSON.stringify(output, null, 2));
console.log(JSON.stringify(output, null, 2));
process.exit(failures.length ? 1 : 0);
