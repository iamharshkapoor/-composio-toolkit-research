import fs from 'node:fs';

/** Evidence Ledger insight generator: derives all narrative numbers from the reconciled dataset. */
const root = '/home/ubuntu/composio-toolkit-research';
const data = JSON.parse(fs.readFileSync(`${root}/data/research_results_final.json`, 'utf8'));
const { records, summary } = data;
const n = records.length;
const percent = (value) => Number(((value / n) * 100).toFixed(1));
const countBy = (items, accessor) => Object.entries(items.reduce((acc, item) => {
  const key = accessor(item);
  acc[key] = (acc[key] || 0) + 1;
  return acc;
}, {})).map(([label, count]) => ({ label, count, percentage: percent(count) })).sort((a, b) => b.count - a.count);
const authMix = countBy(records.flatMap((record) => record.authMethods.map((auth) => ({ auth }))), (item) => item.auth);
const verdicts = countBy(records, (record) => record.buildabilityVerdict);
const access = countBy(records, (record) => record.selfServeStatus);
const mcp = countBy(records, (record) => record.mcpStatus);
const apiBreadth = countBy(records, (record) => record.apiSurfaceBreadth);
const blockers = countBy(records.filter((record) => !/none identified/i.test(record.primaryBlocker)), (record) => record.primaryBlocker).slice(0, 8);
const categoryRows = [...new Set(records.map((record) => record.category))].map((category) => {
  const items = records.filter((record) => record.category === category);
  const buildNow = items.filter((record) => record.buildabilityVerdict === 'build_now').length;
  const gated = items.filter((record) => ['app_review', 'admin_approval', 'partner_gated', 'contact_sales'].includes(record.selfServeStatus)).length;
  const selfServe = items.filter((record) => ['self_serve_free', 'self_serve_trial', 'self_serve_paid'].includes(record.selfServeStatus)).length;
  return { category, total: items.length, buildNow, gated, selfServe, buildNowPercentage: Number(((buildNow / items.length) * 100).toFixed(1)) };
});
const easyWins = records.filter((record) => record.buildabilityVerdict === 'build_now')
  .sort((a, b) => Number(b.confidence === 'high') - Number(a.confidence === 'high') || b.evidence.filter((item) => item.status === 'linked').length - a.evidence.filter((item) => item.status === 'linked').length)
  .slice(0, 10).map((record) => ({ id: record.id, appName: record.appName, category: record.category, why: `${record.selfServeStatus.replaceAll('_', ' ')}; ${record.apiSurfaceBreadth} API surface; ${record.mcpStatus.replaceAll('_', ' ')}.`, nextStep: record.recommendedNextStep, confidence: record.confidence }));
const outreachQueue = records.filter((record) => record.buildabilityVerdict === 'outreach_required' || ['partner_gated', 'contact_sales'].includes(record.selfServeStatus))
  .slice(0, 10).map((record) => ({ id: record.id, appName: record.appName, category: record.category, gate: record.selfServeStatus.replaceAll('_', ' '), blocker: record.primaryBlocker, nextStep: record.recommendedNextStep, confidence: record.confidence }));
const researchDebt = records.filter((record) => record.confidence === 'low' || record.qualityFlags.length > 0 || record.selfServeStatus === 'unknown')
  .sort((a, b) => b.qualityFlags.length - a.qualityFlags.length)
  .slice(0, 10).map((record) => ({ id: record.id, appName: record.appName, category: record.category, issue: record.qualityFlags.join(', ') || record.uncertainties, action: record.recommendedNextStep, confidence: record.confidence }));
const gateCount = records.filter((record) => ['app_review', 'admin_approval', 'partner_gated', 'contact_sales'].includes(record.selfServeStatus)).length;
const selfServeCount = records.filter((record) => ['self_serve_free', 'self_serve_trial', 'self_serve_paid'].includes(record.selfServeStatus)).length;
const dominantAuth = authMix[0] ?? { label: 'Unknown', count: 0, percentage: 0 };
const topVerdict = verdicts[0] ?? { label: 'unknown', count: 0, percentage: 0 };

const headline = gateCount > selfServeCount
  ? 'Credential friction outweighs API availability across the research set.'
  : 'The build queue is substantial, but credential and approval friction still decides priority.';
const narrative = `Of ${n} apps, ${selfServeCount} (${percent(selfServeCount)}%) have a self-serve credential path while ${gateCount} (${percent(gateCount)}%) require an approval, review, partner, or sales gate. ${topVerdict.count} apps (${topVerdict.percentage}%) fall into the largest buildability bucket: ${topVerdict.label.replaceAll('_', ' ')}. ${dominantAuth.label} is the most common observed auth pattern at ${dominantAuth.count} app records.`;
const verification = summary.verificationMetrics;
const insights = {
  generatedAt: new Date().toISOString(),
  researchAsOf: summary.researchAsOf,
  headline,
  narrative,
  kpis: {
    researchCoverage: { value: `${n}/${n}`, label: 'apps researched', detail: '10 categories; exact manifest coverage' },
    buildNow: { value: `${summary.verdictCounts.build_now || 0}`, label: 'build-now candidates', detail: `${percent(summary.verdictCounts.build_now || 0)}% of research set` },
    gated: { value: `${gateCount}`, label: 'gated access paths', detail: `${percent(gateCount)}% require review, admin, partner, or sales action` },
    evidence: { value: `${summary.evidenceCoverage.percentage}%`, label: 'linked evidence coverage', detail: `${summary.evidenceCoverage.linkedSlots}/${summary.evidenceCoverage.totalSlots} planned evidence slots` },
    verification: { value: `${verification.recordLevelExactMatch.percentage}%`, label: 'first-pass exact match', detail: `${verification.recordLevelExactMatch.matches}/${verification.recordLevelExactMatch.checked} sampled records; corrected final alignment is 100% on the same sample` },
  },
  authMix, verdicts, access, mcp, apiBreadth, blockers, categoryRows, easyWins, outreachQueue, researchDebt,
  verification,
  workflow: [
    { step: '01', label: 'Source plan', detail: 'Canonical app manifest plus official docs, auth, pricing, and MCP source hierarchy.' },
    { step: '02', label: 'Agent research', detail: 'Parallel evidence extraction with strict access, API breadth, MCP, and buildability taxonomies.' },
    { step: '03', label: 'Quality gates', detail: 'Schema, enum, evidence-slot, native-MCP, and buildability-access consistency controls.' },
    { step: '04', label: 'Human escalation', detail: 'A stratified 25-app audit prioritising MCP claims, gated access, and ambiguous evidence.' },
    { step: '05', label: 'Decision queues', detail: 'Build-now, outreach, and research-debt lanes generated from reconciled records.' },
  ],
};

fs.writeFileSync(`${root}/client/src/data/insights.ts`, `// Evidence Ledger: deterministic insights generated from reconciled research data.\nexport const insights = ${JSON.stringify(insights, null, 2)} as const;\n`);
fs.writeFileSync(`${root}/data/insights.json`, JSON.stringify(insights, null, 2));
fs.writeFileSync(`${root}/reports/pattern_analysis.md`, `# Pattern Analysis\n\n## Headline\n\n${headline}\n\n${narrative}\n\n## Buildability funnel\n\n${verdicts.map((item) => `- **${item.label.replaceAll('_', ' ')}:** ${item.count}/${n} (${item.percentage}%)`).join('\n')}\n\n## Auth mix\n\n${authMix.map((item) => `- **${item.label}:** ${item.count} app records (${item.percentage}% of records; multi-auth records appear in multiple auth categories).`).join('\n')}\n\n## Access gates\n\n${access.map((item) => `- **${item.label.replaceAll('_', ' ')}:** ${item.count}/${n} (${item.percentage}%)`).join('\n')}\n\n## Product Operations Implication\n\nSplit the roadmap into a self-serve build lane, a review-and-governance lane, an outreach lane, and a research-debt backlog. Treat native MCP as an evidence burden rather than a generic API proxy.\n`);
console.log(JSON.stringify({ headline, kpis: insights.kpis, verification }, null, 2));
