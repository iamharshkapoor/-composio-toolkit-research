// Evidence Ledger: canonical research output with audited samples and reconciled evidence.
export const research = {
  "records": [
    {
      "id": 1,
      "appName": "Salesforce",
      "category": "CRM and Sales",
      "startingHint": "salesforce.com",
      "whatItDoes": "Cloud CRM platform for managing customer data, sales processes, service, marketing, analytics, and business automation.",
      "authMethods": [
        "OAuth 2.0",
        "bearer access token"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "A Salesforce org administrator must configure and authorize the integration; Spring ’26 restricts new Connected App creation, favoring External Client Apps.",
      "apiProtocols": [
        "REST",
        "GraphQL"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST, SOAP, Bulk, GraphQL, Metadata, Connect, Pub/Sub, and other APIs support records, queries, automation, metadata, and events.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Org-admin authorization and changed Salesforce app-creation model",
      "recommendedNextStep": "Implement OAuth 2.0 with External Client App support, then validate required scopes and org-level MCP/API permissions in a test org.",
      "confidence": "high",
      "uncertainties": "Salesforce’s exact edition, licensing, and feature availability for Hosted MCP Servers vary by org and product configuration.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Salesforce documents OAuth 2.0 for external or connected clients and access tokens for REST API use. Its API library spans multiple platform APIs. Official Hosted MCP Servers provide OAuth 2.0 with PKCE and governed record operations, while Connected App creation is restricted from Spring ’26.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/intro_oauth_and_connected_apps.htm",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://help.salesforce.com/s/articleView?language=en_US&id=xcloud.connected_app_overview.htm&type=5",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.salesforce.com/docs/platform/hosted-mcp-servers/references/reference/servers-reference.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.salesforce.com/docs/platform/hosted-mcp-servers/guide/hosted-mcp-servers-overview.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT",
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "verified": {
          "authMethods": "OAuth 2.0, bearer access token",
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": false,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Salesforce officially documents OAuth 2.0 and bearer access tokens, but not PAT as a standard API auth method. Admin enablement and governance are required for hosted MCP servers; official MCP and platform-wide capabilities are confirmed.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/intro_oauth_and_connected_apps.htm",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://help.salesforce.com/s/articleView?language=en_US&id=xcloud.connected_app_overview.htm&type=5",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developer.salesforce.com/docs/platform/hosted-mcp-servers/references/reference/servers-reference.html",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://developer.salesforce.com/docs/platform/hosted-mcp-servers/guide/hosted-mcp-servers-overview.html",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 2,
      "appName": "HubSpot",
      "category": "CRM and Sales",
      "startingHint": "hubspot.com",
      "whatItDoes": "CRM and customer platform for managing contacts, companies, deals, marketing, sales, service, content, and automation.",
      "authMethods": [
        "OAuth 2.0",
        "bearer/PAT",
        "API key",
        "CLI/local"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "Create a developer app and use OAuth for multi-account distribution; private apps and MCP connections require a HubSpot super admin or equivalent account-admin authorization.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Versioned REST APIs span CRM, marketing, sales, service, CMS, conversations, files, automation, webhooks, account administration, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Target-account administrator authorization",
      "recommendedNextStep": "Build the OAuth connector against HubSpot’s current date-versioned REST API and optionally expose the official remote MCP server for agent workflows.",
      "confidence": "high",
      "uncertainties": "Some API capabilities vary by HubSpot product and subscription tier; exact Composio action coverage still requires endpoint-level mapping.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "HubSpot documents OAuth for multi-account apps and static access tokens for a single account, with bearer authorization. Its API reference covers date-versioned APIs across the platform, while official MCP documentation provides a remote MCP server with OAuth 2.0 and CRM read/write tools; private-app and MCP setup require account-admin involvement.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.hubspot.com/docs/apps/developer-platform/build-apps/authentication/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.hubspot.com/docs/apps/legacy-apps/private-apps/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.hubspot.com/docs/api-reference/latest/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.hubspot.com/docs/apps/developer-platform/build-apps/integrate-with-the-remote-hubspot-mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT, API key, CLI/local",
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0 bearer token, static/private app access token, service key, developer API key (limited), CLI personal access key",
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Confirmed. HubSpot officially supports OAuth bearer tokens, static/private access tokens, service keys, limited developer API keys, and CLI personal access keys. Remote MCP is official GA, but initial account connection requires an admin.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://developers.hubspot.com/docs/apps/developer-platform/build-apps/authentication/overview",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://developers.hubspot.com/docs/apps/developer-platform/build-apps/integrate-with-the-remote-hubspot-mcp-server",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developers.hubspot.com/docs/api-reference/latest/overview",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://developers.hubspot.com/changelog/remote-hubspot-mcp-server-is-now-generally-available",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 3,
      "appName": "Pipedrive",
      "category": "CRM and Sales",
      "startingHint": "pipedrive.com",
      "whatItDoes": "Sales CRM for managing leads, contacts, deals, activities, pipelines, and revenue workflows.",
      "authMethods": [
        "OAuth 2.0",
        "API key",
        "bearer/PAT"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Create a developer sandbox through Pipedrive’s signup form or use a 14-day no-card trial; public Marketplace distribution adds a review step, while private apps can use direct installation.",
      "apiProtocols": [
        "REST",
        "Webhooks",
        "CLI"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "RESTful JSON API v1/v2 covers most core CRM functionality, with webhooks, app extensions, scopes, and official Node.js/PHP clients.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Build against OAuth 2.0 first, retain API-token support for private integrations, and validate MCP actions against Pipedrive permissions and token limits.",
      "confidence": "high",
      "uncertainties": "Public Marketplace apps require approval, but the exact review gate does not apply to private/internal integrations; API v1-to-v2 migration timing should be monitored.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Pipedrive documents OAuth 2.0 for apps and x-api-token API-token authentication; its API reference says the REST API and extension points cover most core product functionality. Pipedrive’s official MCP server uses OAuth, supports CRM queries/actions, is maintained by Pipedrive, and is available on all plans.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://pipedrive.readme.io/docs/core-api-concepts-authentication",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://pipedrive.readme.io/docs/developer-sandbox-account",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.pipedrive.com/docs/api/v1",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.pipedrive.com/en/features/mcp-server",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, API key, bearer/PAT",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0, API token",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Official docs confirm OAuth 2.0 and user/company API tokens, a no-card 14-day trial, broad core-product API coverage, and Pipedrive-built MCP on all plans. Prior classifications are defensible.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://pipedrive.readme.io/docs/core-api-concepts-authentication",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://www.pipedrive.com/en/pricing",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developers.pipedrive.com/docs/api/v1",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://www.pipedrive.com/en/features/mcp-server",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 4,
      "appName": "Attio",
      "category": "CRM and Sales",
      "startingHint": "attio.com",
      "whatItDoes": "Attio is a flexible CRM for managing people, companies, deals, pipelines, tasks, notes, and relationship data.",
      "authMethods": [
        "OAuth 2.0",
        "API key",
        "bearer/PAT",
        "Basic"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a scoped workspace access token from Developer settings on any plan, or use OAuth 2.0 for multi-workspace apps; token creation requires an Attio admin.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Public JSON REST API over HTTPS supports scoped read/write access across CRM objects, records, lists, comments, notes, tasks, webhooks, and related workspace resources.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Workspace admin required for API-key provisioning",
      "recommendedNextStep": "Implement OAuth 2.0 first, with scoped single-workspace API-key support as a fallback and explicit admin guidance.",
      "confidence": "high",
      "uncertainties": "Attio’s public materials do not state whether any separate review is required before publishing a third-party OAuth app; confirm during implementation if public distribution is planned.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Attio documents OAuth 2.0 and workspace API keys, sends tokens as Bearer credentials, and also supports HTTP Basic authentication. Its REST API exchanges JSON over HTTPS and covers read/write integrations, webhooks, filtering, and pagination. API keys are available on all plans but require an admin; Attio also operates a hosted MCP server using OAuth.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.attio.com/rest-api/guides/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://attio.com/help/reference/apps/generating-an-api-key",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.attio.com/rest-api/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.attio.com/mcp/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, API key, bearer/PAT, Basic",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0, API key, bearer/PAT, Basic",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "All prior fields are defensible: Attio documents OAuth 2.0, API keys, Bearer and Basic auth; free plan includes API/MCP access, and Attio hosts an official MCP server with broad workspace tools.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://docs.attio.com/rest-api/guides/authentication",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://attio.com/pricing",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://docs.attio.com/rest-api/guides/authentication",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://docs.attio.com/mcp/overview",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 5,
      "appName": "Twenty",
      "category": "CRM and Sales",
      "startingHint": "twenty.com, open-source CRM",
      "whatItDoes": "Open-source CRM for managing companies, people, opportunities, custom objects, workflows, and AI-assisted extensions.",
      "authMethods": [
        "OAuth 2.0",
        "API key"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Create a Twenty Cloud workspace in under a minute with a no-card 30-day trial, or self-host the open-source core and create credentials in workspace settings.",
      "apiProtocols": [
        "REST",
        "GraphQL",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST and GraphQL expose schema-generated core CRUD, metadata/schema management, relations, batching, webhooks, and workspace-specific custom objects.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Implement the REST or GraphQL connector with OAuth 2.0 and API-key paths, then validate workspace-specific schemas and MCP parity.",
      "confidence": "high",
      "uncertainties": "Cloud plan API rate limits and exact feature entitlements may vary by current pricing configuration; workspace-specific schemas require runtime discovery.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Twenty’s official docs document API-key bearer authentication and OAuth 2.0 authorization-code PKCE plus client credentials. The API is generated per workspace with REST and GraphQL core and metadata APIs. Official MCP docs provide /mcp endpoints using OAuth or API keys; pricing states cloud trial, self-hosting, and MCP availability.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.twenty.com/developers/extend/oauth",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://twenty.com/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.twenty.com/developers/extend/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.twenty.com/developers/extend/mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, API key",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0,API key",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Official docs confirm API keys and OAuth 2.0, a no-card cloud trial, schema-generated REST/GraphQL core and metadata APIs, and a native MCP server. Prior classifications are defensible.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://docs.twenty.com/developers/extend/oauth",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://twenty.com/pricing",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://docs.twenty.com/developers/extend/api",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://docs.twenty.com/developers/extend/mcp",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 6,
      "appName": "Podio",
      "category": "CRM and Sales",
      "startingHint": "podio.com",
      "whatItDoes": "Podio is a customizable work-management and CRM platform for organizing apps, items, workflows, teams, tasks, and collaboration.",
      "authMethods": [
        "OAuth 2.0",
        "bearer access token",
        "app authentication token"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a Podio account and API client/API key from account settings; API usage is self-serve, with paid API add-ons available for higher call volumes.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Complete REST API covering apps, items, contacts, tasks, files, comments, webhooks, search, spaces, users, workflows, and collaboration objects.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Implement OAuth authorization-code and app-auth flows, then validate scopes, rate limits, and tenant permissions against a test Podio workspace.",
      "confidence": "medium",
      "uncertainties": "The public documentation does not clearly state whether baseline API access is included in every current plan, and no official Podio or Composio Podio MCP endpoint was verified.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Podio states that its API uses OAuth2, requires an account and registered API client, and supports authorization-code, refresh-token, password, and app grants. Its developer site describes a complete programmable interface with webhooks and rate limits; official pricing lists API add-ons from $23/month for higher call volumes.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.podio.com/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.podio.com/index/faq",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.podio.com/index/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.progress.com/podio/documentation/using-podio/podio-mcp-server",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT",
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0, bearer access token, app authentication token",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": false,
          "selfServe": false,
          "apiBreadth": true,
          "mcp": false,
          "verdict": true
        },
        "correctionSummary": "Podio officially supports OAuth2 bearer tokens and app authentication, but not a documented PAT. API access is free and self-serve for free accounts. Podio now documents an official MCP server, so prior MCP and access labels need correction.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://developers.podio.com/authentication",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://developers.podio.com/index/faq",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developers.podio.com/index/api",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://www.progress.com/podio/documentation/using-podio/podio-mcp-server",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 7,
      "appName": "Zoho CRM",
      "category": "CRM and Sales",
      "startingHint": "zoho.com/crm",
      "whatItDoes": "CRM platform for managing leads, contacts, accounts, deals, sales activities, automation, analytics, and customer data.",
      "authMethods": [
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a Zoho account on the free CRM plan, register an OAuth client in Zoho API Console, and obtain user-authorized tokens without documented partner approval.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST APIs cover CRM modules, records, metadata, search/COQL, composite, bulk read/write, automation, analytics, and administration.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "OAuth data-center and scope configuration",
      "recommendedNextStep": "Build the OAuth connector with regional Zoho Accounts/API domains, configurable scopes, refresh-token handling, and CRM API-credit throttling.",
      "confidence": "high",
      "uncertainties": "Exact API availability and limits depend on the customer’s CRM edition, enabled modules, scopes, and regional data center.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Zoho’s CRM documentation states that the API uses OAuth 2.0 and requires users to authorize applications with access tokens. Its pricing page offers a free CRM plan and paid trials. The official Zoho MCP service list includes CRM, and MCP documentation says it uses existing Zoho APIs and OAuth-governed user permissions.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://www.zoho.com/crm/developer/docs/api/v8/oauth-overview.html",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.zoho.com/crm/zohocrm-pricing.html",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://www.zoho.com/crm/developer/docs/api/v8/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.zoho.com/mcp/services/zoho-services.html",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "All prior fields are defensible: Zoho documents OAuth 2.0, a forever-free CRM edition, broad CRM APIs, and first-party pre-built MCP servers with OAuth setup.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://www.zoho.com/crm/developer/docs/api/v8/oauth-overview.html",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://www.zoho.com/crm/zohocrm-pricing.html",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://www.zoho.com/crm/developer/docs/api/v8/",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://www.zoho.com/crm/developer/docs/mcp/overview.html",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 8,
      "appName": "Close",
      "category": "CRM and Sales",
      "startingHint": "close.com",
      "whatItDoes": "Close is a CRM and sales engagement platform for managing leads, contacts, opportunities, activities, and outreach.",
      "authMethods": [
        "API keys",
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Create API keys in Settings > Developer > API Keys; OAuth apps use documented authorization, while a separate free dev organization requires emailing Close support.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST API covers CRM objects, activities, custom fields, webhooks, event logs, reporting, sequences, and outreach, with an experimental OpenAPI spec.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Close account and organization access required",
      "recommendedNextStep": "Create a Close trial or eligible organization, generate an API key or register an OAuth app, and test the official MCP server with read-only scope first.",
      "confidence": "high",
      "uncertainties": "Close's public documentation does not clearly state which commercial subscription plans permit API-key creation; separate dev organizations are explicitly request-based.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Close officially documents API keys generated under Settings > Developer > API Keys and OAuth 2.0 for user-facing integrations. Its official MCP endpoint is https://mcp.close.com/mcp, supports OAuth 2.0 DCR and API-key headers, and offers read, safe-write, and destructive scopes.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.close.com/api/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://close.com/pricing",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.close.com/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.close.com/mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key via HTTP Basic Auth",
            "OAuth 2.0 Bearer token"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "API key via HTTP Basic Auth",
            "OAuth 2.0 Bearer token"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": false,
          "mcp": true,
          "verdict": true
        },
        "verifierNote": "Close documents API-key creation in account settings, OAuth apps for multi-customer integrations, a 14-day no-card trial, and a vendor-operated MCP server at mcp.close.com.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 9,
      "appName": "Copper",
      "category": "CRM and Sales",
      "startingHint": "copper.com",
      "whatItDoes": "Copper is a Google Workspace-focused CRM for managing leads, people, companies, opportunities, projects, tasks, activities, and related sales data.",
      "authMethods": [
        "API key",
        "OAuth 2.0 Authorization Code"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "A Copper user can generate an API key in System settings > API Keys; OAuth credentials require registering the application with Copper via partners@copper.com.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST API covers core CRM entities, search, bulk operations, custom fields, file uploads, related items, and webhooks.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "OAuth app registration for multi-tenant integrations",
      "recommendedNextStep": "Use an admin-provided API key for a single Copper workspace, or contact Copper Partners to register the OAuth application before multi-tenant launch.",
      "confidence": "high",
      "uncertainties": "Copper's public documentation does not clearly state which paid or trial plans permit API-key use, so plan-level API availability should be confirmed before deployment.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Copper officially documents API-key authentication generated from System settings > API Keys and OAuth 2.0 for partner integrations. OAuth prerequisites include application registration and client credentials from Copper. The API documents broad CRM resources and webhooks; no official native Copper MCP was verified.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.copper.com/introduction/authentication.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developer.copper.com/introduction/oauth/flow.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.copper.com/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.copper.com/integrations/timelinesai-whatsapp-integration",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key",
            "OAuth 2.0 Authorization Code"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "API key",
            "OAuth 2.0 Authorization Code"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 10,
      "appName": "DealCloud",
      "category": "CRM and Sales",
      "startingHint": "api.docs.dealcloud.com",
      "whatItDoes": "DealCloud is a CRM and deal-management platform for managing relationships, pipelines, diligence, and structured investment data.",
      "authMethods": [
        "OAuth 2.0 Client Credentials",
        "API key",
        "Bearer token"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "Requires a DealCloud tenant, API-enabled user-group permissions, and an administrator or CSM; credentials are generated from the user profile after API access is enabled.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "REST APIs cover authentication, user management, schema, data CRUD, backups, publications, and relationship-intelligence imports.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "DealCloud with Celeste license and MCP/admin permissions required",
      "recommendedNextStep": "Confirm the customer has DealCloud with Celeste, obtain admin-enabled MCP Access, and validate the tenant endpoint and permission-scoped connection.",
      "confidence": "high",
      "uncertainties": "The documentation does not state whether Celeste or MCP access can be purchased self-serve; commercial licensing terms remain customer-specific.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs state that API access requires user-group API permissions and an API key, while REST calls use OAuth2 Client Credentials and bearer tokens. The official MCP requires a DealCloud with Celeste license, admin Manage MCP Servers permission, and end-user MCP Access.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://api.docs.dealcloud.com/docs/token",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://api.docs.dealcloud.com/docs/apikeys",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://api.docs.dealcloud.com/docs",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://api.docs.dealcloud.com/mcp/getting-started",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 Client Credentials",
            "API key",
            "Bearer token"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 Client Credentials",
            "API key",
            "Bearer token"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 11,
      "appName": "Zendesk",
      "category": "Support and Helpdesk",
      "startingHint": "zendesk.com",
      "whatItDoes": "Customer service platform for managing support tickets, help centers, messaging, voice, and related service workflows.",
      "authMethods": [
        "OAuth 2.0",
        "API token",
        "Basic"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Developers can create a free 14-day Zendesk trial for testing; production access requires a Zendesk subscription, while marketplace-sponsored accounts require a partner request.",
      "apiProtocols": [
        "REST",
        "SDK"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST APIs span ticketing, Help Center, AI Agents, messaging, voice, CRM, custom data, omnichannel, apps, SDKs, and integration services.",
      "mcpStatus": "native_third_party_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Proceed with the Zendesk toolkit using global OAuth for multi-customer distribution, and validate endpoint plan availability and role-based scopes during implementation.",
      "confidence": "high",
      "uncertainties": "Zendesk API feature availability varies by subscription plan and endpoint; API-token/basic-auth support is documented as deprecated rather than removed.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Zendesk documents OAuth access tokens as the supported authentication path, with API tokens/basic authentication marked deprecated. Its developer docs offer a free 14-day trial, and the API reference covers numerous product capabilities. Composio publicly documents a Zendesk MCP toolkit with OAuth2, managed auth, and 452 tools.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.zendesk.com/api-reference/introduction/security-and-auth/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developer.zendesk.com/documentation/api-basics/getting-started/getting-a-trial-or-sponsored-account-for-development/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.zendesk.com/api-reference/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.zendesk.com/marketplace/apps/support/1191848/mcp-server/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, API key, Basic",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "composio_mcp_exposure",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0,API token,Basic",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_third_party_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": false,
          "verdict": true
        },
        "correctionSummary": "Zendesk officially supports OAuth and deprecated API tokens via Basic auth. Its API spans ticketing, Help Center, messaging, voice, CRM, custom data, omnichannel, apps, and integrations. MCP is third-party via the Zendesk Marketplace, not Composio exposure.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://developer.zendesk.com/api-reference/introduction/security-and-auth/",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://developer.zendesk.com/documentation/api-basics/getting-started/getting-a-trial-or-sponsored-account-for-development/",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developer.zendesk.com/api-reference/",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://www.zendesk.com/marketplace/apps/support/1191848/mcp-server/",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 12,
      "appName": "Intercom",
      "category": "Support and Helpdesk",
      "startingHint": "intercom.com",
      "whatItDoes": "Customer communications and support platform for conversations, contacts, help content, tickets, and workspace administration.",
      "authMethods": [
        "OAuth 2.0",
        "bearer/PAT"
      ],
      "selfServeStatus": "app_review",
      "selfServeSummary": "Create a free development workspace and app for private-workspace access; public integrations using customer data require Intercom OAuth and team review before installation.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "HTTPS JSON REST APIs cover conversations, contacts, companies, tickets, help-center content, admins, events, webhooks, and related workspace data.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Intercom review required for public customer-data integrations",
      "recommendedNextStep": "Build against the REST API with OAuth, then submit the public app and end-to-end OAuth flow for Intercom review.",
      "confidence": "high",
      "uncertainties": "The official documentation does not establish that every REST endpoint is available under every Intercom plan or OAuth scope.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Intercom documents Access Tokens for private apps and OAuth for public apps accessing other workspaces, with Bearer authorization. Its REST API supports JSON over HTTPS across multiple platform domains, and its official MCP server exposes authenticated remote MCP endpoints and 13 tools. Public apps require Intercom review; private apps do not.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.intercom.com/docs/build-an-integration/learn-more/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.intercom.com/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.intercom.com/docs/build-an-integration/learn-more/rest-apis",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.intercom.com/docs/guides/mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT",
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "verified": {
          "authMethods": "OAuth 2.0,bearer access token",
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Official docs confirm OAuth for public apps, bearer access tokens for private apps/MCP, broad REST APIs, and Intercom-hosted remote MCP. Public apps require review, so prior classifications are defensible.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://developers.intercom.com/docs/build-an-integration/learn-more/authentication",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://developers.intercom.com/docs/publish-to-the-app-store/review-publish-your-app",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developers.intercom.com/docs/build-an-integration/learn-more/rest-apis",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://developers.intercom.com/docs/guides/mcp",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 13,
      "appName": "Freshdesk",
      "category": "Support and Helpdesk",
      "startingHint": "freshdesk.com",
      "whatItDoes": "Customer support helpdesk for managing tickets, contacts, agents, knowledge base content, conversations, and service workflows.",
      "authMethods": [
        "API key via HTTP Basic Auth"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "A self-serve 14-day Enterprise trial is available; API keys are exposed to verified agents from Profile Settings, with permissions governed by the agent role.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "REST API v2 covers tickets, contacts, agents, companies, conversations, account, admin configuration, solutions, reporting, automations, and related helpdesk resources.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Freshdesk MCP is an EAP feature restricted to selected Enterprise customers",
      "recommendedNextStep": "Use the REST API with a verified agent API key for immediate prototyping, and request Freshdesk MCP EAP access from the technical account manager or support team before production MCP deployment.",
      "confidence": "high",
      "uncertainties": "The documentation is transitioning from EAP to planned September 2026 plan limits, so general-availability eligibility and final commercial terms may change.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Freshdesk's official documentation describes API-key authentication and the API reference lists broad REST resources. Freshworks states the MCP server is official but currently Beta/EAP for selected Enterprise customers, requiring access through a technical account manager or support.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.freshdesk.com/api/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://support.freshdesk.com/support/solutions/articles/215517-how-to-find-your-api-key",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.freshdesk.com/api/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://crmsupport.freshworks.com/support/solutions/articles/50000012670-model-context-protocol-mcp-integration-in-freshdesk-eap-",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key (HTTP Basic)"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "API key (HTTP Basic)"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": false,
          "mcp": true,
          "verdict": true
        },
        "verifierNote": "Freshdesk API credentials are self-serve for logged-in agents, including trial accounts, but official MCP remains beta/EAP for selected Enterprise customers and requires access approval.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 14,
      "appName": "Front",
      "category": "Support and Helpdesk",
      "startingHint": "front.com",
      "whatItDoes": "Customer communication platform for managing shared inboxes, conversations, messages, contacts, and support workflows.",
      "authMethods": [
        "Bearer API tokens",
        "OAuth 2.0",
        "OAuth 2.1 + PKCE for MCP"
      ],
      "selfServeStatus": "unknown",
      "selfServeSummary": "API tokens can be generated in Front settings for an own instance or single customer, while public integrations require OAuth; plan eligibility is not stated in the cited docs.",
      "apiProtocols": [
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Core API covers conversations, contacts, inboxes, users, messages, channels, tags, webhooks, and related workspace resources.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "MCP is open beta and requires a confidential OAuth client with client ID and secret",
      "recommendedNextStep": "Create a Front developer app, enable the MCP Server feature with least-privilege scopes, and validate the target client supports confidential OAuth without Dynamic Client Registration.",
      "confidence": "high",
      "uncertainties": "The official documentation does not state which Front subscription tiers include API tokens, OAuth apps, or MCP access.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Front documents Bearer tokens obtained either from API tokens in settings or OAuth, and requires OAuth for public integrations unless an exception is granted. Its official MCP endpoint is mcp.frontapp.com/mcp, in open beta, using OAuth 2.1 + PKCE compatibility and a confidential client; DCR is unsupported.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://dev.frontapp.com/docs/authentication",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://dev.frontapp.com/docs/create-and-manage-apps",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://dev.frontapp.com/docs/core-api-overview",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://dev.frontapp.com/docs/mcp-server",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "access_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer API tokens",
            "OAuth 2.0",
            "OAuth 2.1 + PKCE for MCP"
          ],
          "selfServeStatus": "unknown",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Bearer API tokens",
            "OAuth 2.0",
            "OAuth 2.1 + PKCE for MCP"
          ],
          "selfServeStatus": "unknown",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 15,
      "appName": "Pylon",
      "category": "Support and Helpdesk",
      "startingHint": "usepylon.com",
      "whatItDoes": "B2B customer support platform for managing customer issues, accounts, contacts, and support workflows across channels.",
      "authMethods": [
        "Bearer token",
        "OAuth 2.0 (MCP)"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "API tokens are generated in the Pylon dashboard by Admin users; MCP requires dashboard enablement and an MCP Access role for Members or Admins.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "breadth= ფართ; JSON API with documented endpoints for accounts, activities, contacts, issues, messages, knowledge base, users, teams, tags, and other support objects.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Pylon admin-controlled token and MCP-access permissions",
      "recommendedNextStep": "Have a Pylon Admin enable API tokens or MCP Access, then validate the required endpoints and role-scoped permissions in a test organization.",
      "confidence": "high",
      "uncertainties": "Pylon's public sources do not clearly state which subscription tiers include API tokens or MCP.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Pylon officially documents Bearer API-token authentication and says only Admin users can create tokens. Its official MCP server uses OAuth 2.0 at mcp.usepylon.com, requires dashboard configuration, and is available to users granted the MCP Access role.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.usepylon.com/pylon-docs/developer/api/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.usepylon.com/pylon-docs/developer/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.usepylon.com/pylon-docs/developer/api/api-reference",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.usepylon.com/pylon-docs/integrations/pylon-mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer token",
            "OAuth 2.0 (MCP)"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Bearer token",
            "OAuth 2.0 (MCP)"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 16,
      "appName": "LiveAgent",
      "category": "Support and Helpdesk",
      "startingHint": "liveagent.com",
      "whatItDoes": "Omnichannel customer-support software for ticketing, live chat, social channels, knowledge bases, and voice support.",
      "authMethods": [
        "API key",
        "Bearer token",
        "OAuth 2.1 Authorization Code + PKCE"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "A 30-day trial is available without a credit card, but API keys are created by an account admin; MCP tokens are generated in the agent profile.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "API v3 documents agents, tickets, contacts, companies, conversations, knowledge base, reports, tags, channels, and related operations.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Account-admin credential generation and role permissions",
      "recommendedNextStep": "Create a trial account, have an admin generate a scoped API key or MCP token, and validate required ticket operations against the tenant.",
      "confidence": "high",
      "uncertainties": "API v3 documentation is tenant-hosted inside the LiveAgent account, so exact endpoint availability and plan-specific limits should be confirmed in the target tenant.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "LiveAgent officially documents API v3 with admin-created API keys sent in the apikey header. Its pricing page offers a 30-day trial without a credit card, while its official MCP article documents a built-in MCP server at the tenant /api/mcp endpoint using Bearer tokens or OAuth 2.1 PKCE.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://support.liveagent.com/741982-API-key",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.liveagent.com/pricing/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://support.liveagent.com/911737-API-v3",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://support.liveagent.com/647358-MCP-Integration-for-Agents",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key",
            "Bearer token",
            "OAuth 2.1 Authorization Code + PKCE"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "API key",
            "Bearer token",
            "OAuth 2.1 Authorization Code + PKCE"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 17,
      "appName": "Plain",
      "category": "Support and Helpdesk",
      "startingHint": "plain.com",
      "whatItDoes": "B2B customer support platform for managing conversations, customers, help centers, workflows, and AI-assisted support.",
      "authMethods": [
        "Bearer API key",
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Create a Plain workspace through the 7-day trial without a credit card; API keys are created by workspace users under Settings > Machine Users, with scoped permissions.",
      "apiProtocols": [
        "GraphQL",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "GraphQL API covering customers, companies, tenants, threads, messaging, labels, tasks, notes, help centers, webhooks, events, attachments, and agent workflows.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Workspace account and appropriate user permissions required",
      "recommendedNextStep": "Start a Plain trial, create a machine user and least-privilege API key, or connect the official MCP server via OAuth for agent workflows.",
      "confidence": "high",
      "uncertainties": "The pricing page does not explicitly map every API capability to a specific plan, although API is listed as a platform extensibility feature and the trial provides a practical self-serve path.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Plain documents GraphQL access at core-api.uk.plain.com/graphql/v1 using Authorization: Bearer with a Plain API key, created through a machine user with fine-grained permissions. Its pricing page offers a 7-day no-card trial, and Plain documents its own MCP server at mcp.plain.com/mcp using OAuth.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://www.plain.com/docs/graphql/authentication",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.plain.com/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://www.plain.com/docs/graphql/introduction",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://help.plain.com/article/mcp-server",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer API key",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer API key",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 18,
      "appName": "Help Scout",
      "category": "Support and Helpdesk",
      "startingHint": "helpscout.com",
      "whatItDoes": "Customer support platform for managing shared inboxes, conversations, customer records, knowledge bases, workflows, and support reporting.",
      "authMethods": [
        "OAuth 2.0 bearer tokens",
        "Docs API key via HTTP Basic Authentication"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "Inbox API access is included on Standard, Plus, and Pro paid plans; create an OAuth app in My Apps, and use an active invited Help Scout user for authorization.",
      "apiProtocols": [
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Inbox API v2 covers conversations, customers, inboxes, organizations, users, teams, workflows, webhooks, and reports; separate Docs API v1 supports knowledge-base administration.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Paid Help Scout plan with API access required",
      "recommendedNextStep": "Create a Help Scout OAuth app, authorize an active user, and connect the official MCP endpoint https://mcp.helpscout.net/mcp for read-only operations.",
      "confidence": "high",
      "uncertainties": "MCP connections may require approval or developer mode in the chosen AI client, and Docs MCP tools additionally require a Docs API key with the required permission.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Help Scout documents OAuth 2.0 Authorization Code and Client Credentials flows for the Inbox API, requiring an OAuth app and active invited user. Its Docs API uses user-linked API keys with Basic auth. Official docs state API access is on Standard, Plus, and Pro, and document the official MCP server at mcp.helpscout.net/mcp.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.helpscout.com/mailbox-api/overview/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.helpscout.com/article/1140-mailbox-api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.helpscout.com/mailbox-api/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.helpscout.com/article/1779-connect-your-ai-agent-with-help-scout-to-search-conversations-and-pull-reports",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 bearer tokens",
            "Docs API key via HTTP Basic Authentication"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 bearer tokens",
            "Docs API key via HTTP Basic Authentication"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 19,
      "appName": "Gorgias",
      "category": "Support and Helpdesk",
      "startingHint": "gorgias.com",
      "whatItDoes": "Helpdesk platform for ecommerce teams to manage customer support tickets, channels, automation, analytics, and AI-assisted service.",
      "authMethods": [
        "HTTP Basic Authentication (email and API key)",
        "OAuth 2.0"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "API access is available on all Helpdesk plans, but the account owner or an admin must create/access credentials; public apps additionally require Gorgias review.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Official REST API with documented resource-oriented endpoints, JSON requests/responses, guides, object definitions, and rate-limit documentation.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Official MCP is in open beta and some write capabilities are gated or still rolling out.",
      "recommendedNextStep": "Build against the documented REST API or first-party MCP, obtain credentials from a Gorgias admin, and validate beta MCP write operations before production use.",
      "confidence": "high",
      "uncertainties": "The MCP documentation confirms beta availability and role-dependent actions, but does not provide a complete public matrix of every gated write operation.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Gorgias officially documents HTTP Basic authentication using a base API URL, account email, and API key, with credentials available on all Helpdesk plans to owners/admins. Private apps need no approval; public apps use OAuth2 and team review. Gorgias also documents a first-party MCP endpoint, currently in beta.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.gorgias.com/en-US/rest-api-208286",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.gorgias.com/en-US/build-a-custom-app-81853",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.gorgias.com/reference/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.gorgias.com/en-US/connect-your-ai-assistant-to-the-gorgias-mcp-6310546",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "HTTP Basic Authentication (email and API key)",
            "OAuth 2.0"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "HTTP Basic Authentication (email and API key)",
            "OAuth 2.0"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 20,
      "appName": "Gladly",
      "category": "Support and Helpdesk",
      "startingHint": "gladly.com",
      "whatItDoes": "Customer service platform for managing customer conversations, profiles, agents, tasks, knowledge content, reporting, and integrations.",
      "authMethods": [
        "HTTP Basic Authentication (agent email + API token)"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "An administrator must grant the user the API User permission; that user can then create API tokens in the Gladly UI. Gladly account access is required.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "Official REST API covers agents, customers, conversations, communications, tasks, teams, topics, webhooks, reports, exports, answers, and organization data.",
      "mcpStatus": "mcp_possible_via_api",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Gladly administrator approval and tenant credentials",
      "recommendedNextStep": "Obtain a Gladly tenant administrator's API User permission and sandbox or production API token, then validate the required endpoints and rate limits.",
      "confidence": "high",
      "uncertainties": "Gladly's commercial plan or tenant-level entitlement requirements for API access are not specified in the reviewed public documentation.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Gladly's official REST documentation states that API access requires the API User permission and token-based Basic Authentication using an agent email and API token. Its API reference is broad and includes REST, Lookup API, webhooks, and sandbox testing; no official Gladly MCP server was found.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.gladly.com/rest/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://help.gladly.com/implementation/docs/get-your-api-tokens",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.gladly.com/rest/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "HTTP Basic Authentication (agent email + API token)"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "HTTP Basic Authentication (agent email + API token)"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 21,
      "appName": "Slack",
      "category": "Communications and Messaging",
      "startingHint": "slack.com",
      "whatItDoes": "A channel-based team collaboration platform for messaging, file sharing, app integrations, and real-time workplace communication.",
      "authMethods": [
        "OAuth 2.0",
        "bearer token"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a Slack app and install it in one workspace for free; public multi-workspace distribution uses OAuth, while commercial Marketplace distribution requires review.",
      "apiProtocols": [
        "Webhooks",
        "CLI"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "HTTPS HTTP RPC-style Web API with 200+ methods plus Events API, interactions, webhooks, Slack CLI, and scoped workspace capabilities.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Workspace-admin approval may be required for some installations",
      "recommendedNextStep": "Build against Slack OAuth v2 and scoped bearer tokens, then validate required permissions in an admin-restricted workspace.",
      "confidence": "high",
      "uncertainties": "Individual workspace policies, requested scopes, Enterprise features, and rate-limit treatment can change the installation path and available operations.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Slack documents OAuth 2.0 app installation, scoped bot/user tokens, and code exchange; Web API calls use bearer tokens and expose 200+ methods. Slack also documents an official MCP server for searching, reading and sending messages, canvases, and member information. Unlisted distribution is available for pilots; Marketplace publication is manually reviewed.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.slack.dev/authentication/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.slack.dev/app-management/distribution",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.slack.dev/apis/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://slack.com/help/articles/48855576908307-Guide-to-Model-Context-Protocol-in-Slack",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT, Basic",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0,bearer token",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": false,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Slack officially documents OAuth 2.0 and token-based API access; no official Basic/PAT method was verified. App creation, single-workspace install, and unlisted distribution are self-serve; Marketplace listing requires review.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://docs.slack.dev/authentication/",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://docs.slack.dev/app-management/distribution",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://docs.slack.dev/apis/",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://slack.com/help/articles/48855576908307-Guide-to-Model-Context-Protocol-in-Slack",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 22,
      "appName": "Twilio",
      "category": "Communications and Messaging",
      "startingHint": "twilio.com",
      "whatItDoes": "Cloud communications platform for sending messages, making calls, managing phone numbers, email, verification, and related customer-engagement services.",
      "authMethods": [
        "OAuth 2.0",
        "API key",
        "Basic Auth",
        "Auth token"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Developers can sign up without a credit card, verify email and phone, receive Console credentials, and use real API requests during a 30-day trial before upgrading for full functionality.",
      "apiProtocols": [
        "REST",
        "SDK"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "HTTPS REST APIs and SDKs cover messaging, voice, phone numbers, accounts, usage, email, verification, conversations, video, and other Twilio products.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Implement the integration with API-key Basic Auth first, and optionally add OAuth 2.0 plus the official MCP endpoint behind a beta-review flag.",
      "confidence": "high",
      "uncertainties": "The official MCP implementation is Public Beta and its available operation coverage may change before general availability.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Twilio documents HTTP Basic Auth using an API key and secret, with Account SID/Auth Token for local testing; OAuth apps support Client Credentials and Authorization Code grants. Its trial is self-serve, free for 30 days without a credit card, and exposes real API requests. Official Twilio repositories document MCP endpoints and API-spec search/retrieval, currently as Public Beta.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://www.twilio.com/docs/iam/api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.twilio.com/docs/usage/trials",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://www.twilio.com/docs/ai/mcp",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.twilio.com/docs/ai/mcp",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, API key, Basic, bearer/PAT",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0,API key,Basic Auth,Auth token",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": false,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": false
        },
        "correctionSummary": "Twilio officially supports OAuth 2.0 and API-key/Account SID Basic Auth; bearer/PAT is not evidenced for core APIs. Official MCP is public beta and read-only, so build with review rather than build_now.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://www.twilio.com/docs/iam/api",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://www.twilio.com/docs/usage/trials",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://www.twilio.com/docs/ai/mcp",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://www.twilio.com/docs/ai/mcp",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 23,
      "appName": "Zoho Cliq",
      "category": "Communications and Messaging",
      "startingHint": "zoho.com/cliq",
      "whatItDoes": "Business messaging and collaboration platform with chats, channels, meetings, bots, workflows, and organizational administration.",
      "authMethods": [
        "OAuth 2.0 authorization code",
        "OAuth 2.0 refresh token"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "A free Cliq plan is available; developers register an app in Zoho API Console to obtain client credentials, then obtain user-consented scoped OAuth tokens.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Official REST API v3 covers chats, messages, channels, bots, platform components, users, teams, departments, storage, and administrative resources.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "OAuth consent and organization-level permissions",
      "recommendedNextStep": "Register a Zoho OAuth client, request only required ZohoCliq scopes, complete consent with a Cliq user, and validate the official Zoho Cliq MCP tool coverage.",
      "confidence": "high",
      "uncertainties": "Specific MCP availability, tool permissions, and some organization-admin operations may depend on the customer's Zoho data center, Cliq plan, and administrator policy.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Zoho documents OAuth 2.0 for Cliq, including API Console client registration, user consent, scoped access and refresh tokens. The pricing page offers a Free plan with API support. Zoho separately documents an official Zoho Cliq MCP server and its supported tools.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://www.zoho.com/cliq/help/restapi/v3/oauth/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.zoho.com/cliq/pricing.html",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://www.zoho.com/cliq/help/restapi/v3/introduction/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.zoho.com/cliq/help/platform/zoho-cliq-mcp.html",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 authorization code",
            "OAuth 2.0 refresh token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 authorization code",
            "OAuth 2.0 refresh token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 24,
      "appName": "Lark",
      "category": "Communications and Messaging",
      "startingHint": "open.larksuite.com",
      "whatItDoes": "Workplace collaboration suite providing messaging, meetings, docs, calendars, workflows, and enterprise productivity APIs.",
      "authMethods": [
        "App ID/App Secret",
        "OAuth 2.0 user authorization"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "Create a custom app and obtain App ID/App Secret in the developer console, but tenant-admin approval is required before the app is published and usable.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "Official OpenAPI covers messaging, users and groups, contacts, documents, spreadsheets, drives, calendars, meetings, tasks, approvals, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Tenant administrator approval and configured app permissions",
      "recommendedNextStep": "Create a custom app in the Lark developer console, configure only required scopes and availability, then submit it for tenant-admin review and test the official OpenAPI MCP.",
      "confidence": "high",
      "uncertainties": "Exact permission scopes, availability, and whether review can be waived depend on the target tenant and app configuration.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Lark officially documents tenant, user, and app access tokens, with App ID/App Secret obtained from the developer console; OAuth user tokens require authorization and app-use permission. Custom-app publication is subject to tenant-admin review, and Lark documents an OpenAPI MCP tool/server.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://open.larksuite.com/document/ukTMukTMukTM/uMTNz4yM1MjLzUzM",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://open.larksuite.com/document/uQjL04CN/ucDOz4yN4MjL3gzM",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://open.larksuite.com/document/uQjL04CN/ucDOz4yN4MjL3gzM",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://open.larksuite.com/document/uAjLw4CM/ukTMukTMukTM/mcp_integration/mcp_introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "App ID/App Secret",
            "OAuth 2.0 authorization code",
            "tenant_access_token",
            "user_access_token"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "App ID/App Secret",
            "OAuth 2.0 authorization code",
            "tenant_access_token",
            "user_access_token"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": false,
          "mcp": true,
          "verdict": true
        },
        "verifierNote": "Lark documents App ID/App Secret tokens and OAuth user tokens; tenant permissions require admin authorization, while its official MCP tooling exists but remote MCP configuration is documented as internal beta.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 25,
      "appName": "Pumble",
      "category": "Communications and Messaging",
      "startingHint": "pumble.com",
      "whatItDoes": "Team communication platform for channels, direct messages, threads, file sharing, calls, and workflow integrations.",
      "authMethods": [
        "API key",
        "user token",
        "bot token",
        "app key"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "API keys are generated after installing Pumble’s API addon, available to owners, admins, and members on all plans; MCP credentials come from a self-created app.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "Official API covers users, scheduled messages, messages, reactions, channels, DMs, search, and channel membership operations.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Workspace permissions and required scopes",
      "recommendedNextStep": "Install the API addon or create a Pumble app, generate the required credentials, grant only the needed scopes, and run endpoint/MCP permission tests.",
      "confidence": "high",
      "uncertainties": "The API addon reference documents an ApiKey header, while the broader app platform uses OAuth-derived user and bot tokens; exact rate limits and scope behavior may vary by endpoint.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Pumble’s official help says the API addon is available on all plans and generates API keys in the workspace. Its official MCP guide documents https://mcp.pumble.com/mcp and requires an app key plus user or bot token; available tools depend on selected scopes.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://pumble-api-keys.addons.marketplace.cake.com/api-docs/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://pumble.com/help/integrations/automation-workflow-integrations/api-keys-integration/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://dev-docs.marketplace.cake.com/pumble/learn/introduction.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://pumble.com/help/integrations/automation-workflow-integrations/how-to-use-the-pumble-mcp-server/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key",
            "user token",
            "bot token",
            "app key"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "API key",
            "user token",
            "bot token",
            "app key"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 26,
      "appName": "Discord",
      "category": "Communications and Messaging",
      "startingHint": "discord.com",
      "whatItDoes": "A communications platform with REST, Gateway, and OAuth2 APIs for bots, apps, servers, messaging, and real-time events.",
      "authMethods": [
        "Bot token",
        "OAuth2 bearer token"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create an application in the Discord Developer Portal and obtain a bot token or OAuth2 client credentials without a paid plan; server installation and some intents require permissions or review.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "versioned REST API plus Gateway WebSocket events, OAuth2 authorization, interactions, webhooks, voice, and application features.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Discord verification or privileged-intent review for scale-sensitive functionality",
      "recommendedNextStep": "Create a Discord application, implement least-privilege bot/OAuth2 access, and confirm whether the design requires privileged intents or verification before launch.",
      "confidence": "high",
      "uncertainties": "Discord’s official documentation does not establish a native MCP server or official MCP integration; third-party MCP implementations were excluded.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Discord officially documents two API authentication paths: a bot token from the app’s Bot settings and an OAuth2 bearer token. Applications can self-serve initially, while verification is required to scale past 100 servers and privileged intents require review above 10,000 users under current guidance. No official Discord MCP server was verified.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.discord.com/developers/reference",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://support-dev.discord.com/hc/en-us/articles/23926564536471-How-Do-I-Get-My-App-Verified",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.discord.com/developers/reference",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bot token",
            "OAuth2 bearer token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Bot token",
            "OAuth2 bearer token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 27,
      "appName": "Telegram",
      "category": "Communications and Messaging",
      "startingHint": "core.telegram.org",
      "whatItDoes": "Messaging platform with Bot API, MTProto API, TDLib, and Gateway API for bots, clients, verification, and messaging workflows.",
      "authMethods": [
        "bot token",
        "api_id/api_hash plus user authorization"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a bot and receive its token through the official @BotFather flow; obtain api_id/api_hash from my.telegram.org after signing up with a Telegram account, with no stated app-review gate.",
      "apiProtocols": [
        "CLI"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "Official Bot API exposes extensive HTTPS methods for messaging, chats, media, updates, users, payments, business bots, mini apps, and administration; Telegram API/TDLib supports custom clients.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Telegram platform policy, rate limits, and bot permissions",
      "recommendedNextStep": "Create a dedicated bot in @BotFather, securely store the token, and validate required chat permissions and webhook or polling behavior against the Bot API.",
      "confidence": "high",
      "uncertainties": "Telegram's official sites do not identify an official MCP server; third-party MCP implementations may exist but are not classified as native official MCP.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Telegram documents bot authentication with a unique token generated when the bot is created and requests formatted as https://api.telegram.org/bot<token>/METHOD_NAME. It separately documents self-serve api_id/api_hash issuance through my.telegram.org/apps for MTProto user authorization. No official Telegram MCP server evidence was found.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://core.telegram.org/bots/api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://core.telegram.org/bots/tutorial",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://core.telegram.org/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "bot token",
            "api_id/api_hash plus user authorization"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "bot token",
            "api_id/api_hash plus user authorization"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 28,
      "appName": "WhatsApp Business",
      "category": "Communications and Messaging",
      "startingHint": "developers.facebook.com/docs/whatsapp",
      "whatItDoes": "Enables businesses to send and receive WhatsApp messages, manage business assets, use webhooks, and support calls and groups through Meta APIs.",
      "authMethods": [
        "OAuth access token",
        "Bearer access token"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Developers can create a Meta app and test WABA/phone resources with a temporary token; production use requires a system-user token, assigned assets, and documented permissions, with App Review for client businesses.",
      "apiProtocols": [
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Cloud API messaging, media, templates, calls and groups, Business Management APIs, analytics, webhooks, and Marketing Messages API",
      "mcpStatus": "composio_mcp_exposure",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Advanced access/App Review for serving other businesses",
      "recommendedNextStep": "Build against the Cloud API test account, then submit separate App Review requests for whatsapp_business_messaging and whatsapp_business_management before onboarding external businesses.",
      "confidence": "high",
      "uncertainties": "Meta's MCP overview page does not list a dedicated WhatsApp native server; the MCP classification relies on Composio's official exact-toolkit documentation.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Meta documents OAuth access tokens, Bearer authorization, test resources, temporary tokens, and permanent system-user tokens with business_management, whatsapp_business_messaging, and whatsapp_business_management permissions. Direct developers can use Standard Access, while apps for other businesses require Advanced access and App Review. Composio documents an exact WhatsApp toolkit.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.facebook.com/documentation/business-messaging/whatsapp/about-the-platform",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.facebook.com/documentation/business-messaging/whatsapp/get-started",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.facebook.com/documentation/business-messaging/whatsapp/about-the-platform",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.composio.dev/toolkits/whatsapp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth access token",
            "Bearer access token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "composio_mcp_exposure",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth access token",
            "Bearer access token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "composio_mcp_exposure",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 29,
      "appName": "Aircall",
      "category": "Communications and Messaging",
      "startingHint": "aircall.io",
      "whatItDoes": "Cloud communications platform for business calling, messaging, call management, and conversation intelligence.",
      "authMethods": [
        "OAuth 2.0",
        "Basic Auth"
      ],
      "selfServeStatus": "unknown",
      "selfServeSummary": "An Aircall account is required; customers can generate API ID/token credentials in Dashboard > Integrations > API keys, while OAuth credentials require Technology Partner approval.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST API and webhooks cover calls, contacts, users, teams, numbers, messages, tags, integrations, analytics, conversation intelligence, and AI voice agents.",
      "mcpStatus": "mcp_possible_via_api",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Aircall account and Admin authorization; OAuth requires Technology Partner approval",
      "recommendedNextStep": "Use Basic Auth with customer-generated API ID/token for a single account, or apply to the Technology Partner program for multi-customer OAuth distribution.",
      "confidence": "high",
      "uncertainties": "Aircall’s cited documentation does not establish whether API access requires a specific paid plan, so self-serve tier classification remains unknown.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Aircall officially documents OAuth for Technology Partners and Basic Auth for customers building for their own account. API keys are generated in the Aircall Dashboard, while OAuth credentials are issued after partner approval; Aircall documents building MCP-compliant integrations for its AI Virtual Agent, not a general Aircall-hosted MCP server.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.aircall.io/api-references",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developer.aircall.io/docs/basic-authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.aircall.io/api-references",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.aircall.io/docs/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "access_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0",
            "Basic Auth"
          ],
          "selfServeStatus": "unknown",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0",
            "Basic Auth"
          ],
          "selfServeStatus": "unknown",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 30,
      "appName": "Vonage",
      "category": "Communications and Messaging",
      "startingHint": "developer.vonage.com",
      "whatItDoes": "Communications APIs for SMS, messaging channels, voice, video, verification, numbers, and account management.",
      "authMethods": [
        "API key and secret",
        "Basic authentication",
        "JWT"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "A developer account can be created without a credit card and credentials appear in the dashboard; trial accounts restrict destinations and features until full account enablement.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "Official references cover messaging, SMS, voice, video/conversation, verification, numbers, applications, account, pricing, reports, security, and network APIs.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Trial-account destination and feature restrictions",
      "recommendedNextStep": "Create a Vonage developer account, generate dashboard credentials, validate the required API and MCP tools within trial limits, then enable the full account before production use.",
      "confidence": "high",
      "uncertainties": "Exact production enablement requirements can vary by product, destination, geography, and account risk review.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Vonage documents API key/secret and JWT authentication, dashboard credential access, and a no-credit-card free signup. Its API reference spans communications and account services, while Vonage's official MCP Server documentation exposes Vonage capabilities through MCP; trial accounts remain limited.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.vonage.com/en/getting-started/concepts/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developer.vonage.com/en/dashboard/getting-started",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.vonage.com/en/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.vonage.com/en/mcp-server/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key and secret",
            "Basic authentication",
            "JWT"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "API key and secret",
            "Basic authentication",
            "JWT"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 31,
      "appName": "Google Ads",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "developers.google.com/google-ads",
      "whatItDoes": "Google Ads lets businesses create, manage, target, and measure advertising campaigns across Google’s properties.",
      "authMethods": [
        "OAuth 2.0",
        "service account",
        "other"
      ],
      "selfServeStatus": "app_review",
      "selfServeSummary": "Create a Google Ads manager account and apply in API Center for a developer token; test access may be immediate, while production capability and higher access levels require Google review.",
      "apiProtocols": [
        "REST",
        "CLI"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST/gRPC client libraries cover campaign and ad management, GAQL reporting, conversions, audiences, planning, billing, account access, and multiple campaign types.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Developer-token access level and permissible-use review for production workloads",
      "recommendedNextStep": "Implement OAuth and developer-token handling against test accounts, then submit the intended Composio use case for the required Google Ads access level.",
      "confidence": "high",
      "uncertainties": "Google’s access-level outcome can vary because Explorer access may be granted automatically, while Basic or Standard access depends on the submitted use case and review.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Google documents OAuth 2.0 plus a required developer token; tokens begin with test access and may receive Explorer access, while Basic and Standard access require applications and review. Google’s official MCP server is read-only and supports OAuth 2.0 or service-account authentication.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.google.com/google-ads/api/docs/oauth/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.google.com/google-ads/api/docs/api-policy/access-levels",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.google.com/google-ads/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.google.com/google-ads/api/docs/developer-toolkit/mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, service account, other",
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "verified": {
          "authMethods": "OAuth 2.0, service account, developer token",
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Confirmed. OAuth 2.0 and service accounts are supported, while a developer token is required; token access may require review for production or higher levels. Google publishes an official read-only Ads MCP server.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://developers.google.com/google-ads/api/docs/oauth/overview",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://developers.google.com/google-ads/api/docs/api-policy/access-levels",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developers.google.com/google-ads/api/docs/concepts/api-structure",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://developers.google.com/google-ads/api/docs/developer-toolkit/mcp-server",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 32,
      "appName": "Meta Ads",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "developers.facebook.com/docs/marketing-apis",
      "whatItDoes": "Programmatically creates, manages, optimizes, and reports on advertising campaigns across Meta technologies.",
      "authMethods": [
        "OAuth 2.0",
        "user access token",
        "system user access token",
        "bearer access token"
      ],
      "selfServeStatus": "app_review",
      "selfServeSummary": "Create a Meta app and add the Marketing API for limited access; production use for other businesses requires advanced permissions and App Review.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Graph API endpoints cover campaign, ad set, creative, audience, catalog, insights, business, and related Meta advertising workflows.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Advanced permissions and production access require Meta App Review",
      "recommendedNextStep": "Build against a test ad account, then submit the required ads permissions and Marketing API access tier for App Review.",
      "confidence": "high",
      "uncertainties": "Exact tool availability on Meta's Ads MCP server is being rolled out gradually and may vary by ad account.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Meta states every Marketing API call requires an access token and documents user and system-user tokens. The API spans campaign creation and management, optimization, audiences, insights, catalogs, and Business Manager. Limited access is automatic after adding the product, while broader production use and permissions require App Review. Meta also documents a hosted Ads MCP server at mcp.facebook.com/ads.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.facebook.com/documentation/ads-commerce/marketing-api/get-started/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.facebook.com/documentation/ads-commerce/marketing-api/get-started/authorization",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.facebook.com/documentation/ads-commerce/marketing-api/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.facebook.com/documentation/ads-commerce/ads-ai-connectors/ads-mcp-server/ads-mcp-server-overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT",
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "verified": {
          "authMethods": "OAuth 2.0,user access token,system user access token,bearer access token",
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": false,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Meta officially documents OAuth and user/system access tokens sent as bearer tokens; it does not document PAT as a distinct auth method. Production cross-business access and higher tier require App Review.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://developers.facebook.com/documentation/ads-commerce/marketing-api/get-started/authentication",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://developers.facebook.com/documentation/ads-commerce/marketing-api/get-started/authorization",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developers.facebook.com/documentation/ads-commerce/marketing-api/overview",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://developers.facebook.com/documentation/ads-commerce/ads-ai-connectors/ads-mcp-server/ads-mcp-server-overview",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 33,
      "appName": "LinkedIn Ads",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "learn.microsoft.com/linkedin/marketing",
      "whatItDoes": "Manages LinkedIn advertising accounts, campaigns, creatives, targeting, and performance reporting through APIs.",
      "authMethods": [
        "OAuth 2.0"
      ],
      "selfServeStatus": "app_review",
      "selfServeSummary": "Create an app and apply for the Advertising API in the Developer Portal, but LinkedIn approval and appropriate permissions are required before Ads API calls work.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Advertising API covers ad accounts, account users, campaign groups, campaigns, creatives, targeting, and analytics/reporting.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Advertising API application approval and permission vetting",
      "recommendedNextStep": "Submit the app's supported advertising use case for Advertising API development access, then validate required scopes and pursue Standard access if multi-account management is needed.",
      "confidence": "high",
      "uncertainties": "No official LinkedIn-hosted MCP server or exact-app official MCP evidence was identified; an MCP wrapper would need to be built over the approved API.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "LinkedIn documents OAuth 2.0 and states Marketing APIs require member authorization. Advertising API access is a vetted product: developers apply through the Developer Portal, and calls work only after the app receives the required permissions. Development access supports testing; Standard access remains subject to review.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://learn.microsoft.com/en-us/linkedin/shared/authentication/getting-access",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://learn.microsoft.com/en-us/linkedin/shared/authentication/getting-access",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.linkedin.com/product-catalog/marketing/advertising-api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 3-legged Member Authorization"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 3-legged Member Authorization"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": false,
          "apiBreadth": true,
          "mcp": false,
          "verdict": true
        },
        "verifierNote": "LinkedIn documents OAuth 2.0, but Advertising API access requires LinkedIn approval; no official LinkedIn or exact-app MCP documentation was found.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 34,
      "appName": "GoHighLevel",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "highlevel.stoplight.io",
      "whatItDoes": "All-in-one CRM and marketing platform for contacts, conversations, calendars, pipelines, payments, email, and social publishing.",
      "authMethods": [
        "OAuth 2.0",
        "Private Integration Token"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "Create a scoped Private Integration Token in a HighLevel sub-account; basic API access is included on Starter and Unlimited plans, while OAuth and advanced agency access require higher-tier access.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "Versioned REST API covering CRM and contacts, conversations, calendars, opportunities, payments, webhooks, email, social, forms, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Paid HighLevel account and location-level permissions",
      "recommendedNextStep": "Create a scoped Private Integration Token in a test location and validate the required MCP/API operations against the official endpoint.",
      "confidence": "high",
      "uncertainties": "Exact endpoint/tool availability depends on the granted scopes, location permissions, client endpoint, and current HighLevel plan.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "HighLevel officially documents OAuth 2.0 and Private Integration Tokens, with scoped PIT creation under Settings > Private Integrations. Its official LeadConnector MCP server is live at services.leadconnectorhq.com/mcp/, and the API spans hundreds of operations across 40 domains; basic API access is plan-gated.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://marketplace.gohighlevel.com/docs/other/mcp/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://help.gohighlevel.com/support/solutions/articles/48001060529-highlevel-api-documentation",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://marketplace.gohighlevel.com/docs/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://marketplace.gohighlevel.com/docs/other/mcp/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0",
            "Private Integration Token"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0",
            "Private Integration Token"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 35,
      "appName": "Mailchimp",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "mailchimp.com/developer",
      "whatItDoes": "Email and marketing platform with APIs for managing audiences, campaigns, automations, contacts, e-commerce data, and reporting.",
      "authMethods": [
        "API key",
        "OAuth 2.0 access token"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "A Mailchimp account can self-serve an API key; OAuth apps can be registered in the account, while plan and user-role permissions govern available API actions.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Marketing API v3.0 exposes REST endpoints across audiences, contacts, campaigns, automations, templates, reports, webhooks, e-commerce, and account data.",
      "mcpStatus": "mcp_possible_via_api",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Marketplace publication requires Integration Partner review",
      "recommendedNextStep": "Create an API key for a single-account integration or register an OAuth app for multi-user access, then validate required endpoints and plan permissions.",
      "confidence": "high",
      "uncertainties": "The official MCP evidence reviewed covers Transactional Messaging rather than the Marketing API, so no native Marketing MCP is asserted.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Mailchimp officially documents API-key and OAuth 2 authentication for Marketing API v3.0, with self-serve account/API-key creation and OAuth app registration. Its official MCP guide is for Transactional Messaging, not the Marketing API; Marketing API MCP use is therefore possible via the API but not verified as native.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://mailchimp.com/developer/marketing/docs/fundamentals/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://mailchimp.com/developer/marketing/guides/quick-start/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://mailchimp.com/developer/marketing/docs/fundamentals/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://mailchimp.com/developer/transactional/guides/how-to-use-mailchimps-transactional-messaging-mcp/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key",
            "OAuth 2.0 access token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "API key",
            "OAuth 2.0 access token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 36,
      "appName": "Klaviyo",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "developers.klaviyo.com",
      "whatItDoes": "Email and SMS marketing platform with APIs for customer data, campaigns, flows, analytics, and messaging automation.",
      "authMethods": [
        "Private API key",
        "OAuth 2.0",
        "Public API key"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "Owners, admins, or managers can create private API keys and OAuth apps; end users must authorize delegated OAuth access, with scopes configured per integration.",
      "apiProtocols": [
        "REST",
        "Webhooks",
        "CLI"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "broad; Server-side REST APIs cover accounts, profiles, events, campaigns, flows, lists, segments, catalogs, reporting, templates, webhooks, and more; client endpoints support tracking and subscriptions.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Klaviyo account role and customer authorization gate",
      "recommendedNextStep": "Have a Klaviyo owner, admin, or manager create the app or private key, then validate required scopes and the official remote MCP OAuth flow in a test account.",
      "confidence": "high",
      "uncertainties": "Specific endpoint availability, scopes, rate limits, and account-plan restrictions may vary by API version and Klaviyo account.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Klaviyo officially documents private-key, OAuth, and public-key authentication. Private keys and OAuth apps require an Owner, Admin, or Manager role. Its official remote MCP server is https://mcp.klaviyo.com/mcp and uses OAuth with dynamic client registration; the server is available to Klaviyo customers.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.klaviyo.com/en/docs/authenticate_",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.klaviyo.com/en/docs/set_up_oauth",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.klaviyo.com/en/reference/api_overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.klaviyo.com/en/docs/klaviyo_mcp_server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Private API key",
            "OAuth 2.0",
            "Public API key"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Private API key",
            "OAuth 2.0",
            "Public API key"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 37,
      "appName": "systeme.io",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "systeme.io, funnel builder",
      "whatItDoes": "All-in-one marketing platform for funnels, email newsletters, contacts, courses, communities, automation, and online sales.",
      "authMethods": [
        "X-API-Key header",
        "MCP key via X-MCP-Key header or mcpKey query parameter"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "A free systeme.io account includes the dashboard settings needed to create public API keys and MCP keys; no app review or sales gate is documented, but MCP keys expire after 90 days.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "Official REST API covers contacts, tags, custom fields, newsletters, funnels, page editor, price plans, coupons, courses, communities, automation rules, subscriptions, and webhooks.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "MCP key maximum 90-day lifetime",
      "recommendedNextStep": "Build against the official REST API or MCP server, securely store credentials, and add MCP-key rotation before the 90-day expiry.",
      "confidence": "high",
      "uncertainties": "The pricing page confirms a free plan and all-feature access but does not explicitly state API/MCP availability by plan; dashboard documentation indicates self-serve key creation, so plan-specific restrictions remain unconfirmed.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Systeme.io officially documents API-key creation in dashboard settings and X-API-Key authentication for its REST API. It also documents a first-party MCP server using MCP keys via X-MCP-Key or mcpKey, with self-serve key creation; MCP keys are limited to 90 days.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.systeme.io/reference/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://systeme.io/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.systeme.io/reference/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.systeme.io/docs/mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "X-API-Key header",
            "MCP key via X-MCP-Key header or mcpKey query parameter"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "X-API-Key header",
            "MCP key via X-MCP-Key header or mcpKey query parameter"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 38,
      "appName": "Pinterest",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "developers.pinterest.com",
      "whatItDoes": "Pinterest’s API supports content, ads, targeting, shopping catalogs, conversion tracking, and analytics integrations.",
      "authMethods": [
        "OAuth 2.0 Authorization Code",
        "OAuth 2.0 Client Credentials",
        "Bearer access token",
        "HTTP Basic token-endpoint authentication"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Create a business account, verify email, accept Developer Terms, submit the app for Trial access, and wait for Pinterest review before receiving the app ID and secret.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "REST API v5.31.0 covers Pins and Boards, ads, targeting, catalogs, conversions, analytics, billing, business access, trends, and related endpoints.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Pinterest approval for Trial access and Standard-access upgrade",
      "recommendedNextStep": "Register the app in Pinterest My apps, submit a complete Trial-access request, and implement the documented OAuth flow with exact redirect-URI matching.",
      "confidence": "high",
      "uncertainties": "Pinterest’s official documentation reviewed here does not identify an official Pinterest MCP server or MCP integration.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Pinterest requires authenticated, authorized users and documents Authorization Code and Client Credentials grants, with Basic authentication at the token endpoint. App registration requires a business account, verified email, Developer Terms acceptance, and reviewed Trial-access submission; Standard access requires a video demo and separate review.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.pinterest.com/docs/getting-started/set-up-authentication-and-authorization/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.pinterest.com/docs/getting-started/connect-app/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.pinterest.com/docs/api/v5/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 Authorization Code",
            "OAuth 2.0 Client Credentials",
            "Bearer access token",
            "HTTP Basic token-endpoint authentication"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 Authorization Code",
            "OAuth 2.0 Client Credentials",
            "Bearer access token",
            "HTTP Basic token-endpoint authentication"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 39,
      "appName": "Threads (Meta)",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "developers.facebook.com/docs/threads",
      "whatItDoes": "Lets apps create and publish Threads posts, retrieve profiles and media, moderate replies, and access insights.",
      "authMethods": [
        "OAuth 2.0 Threads user access tokens"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a Meta app with the Threads use case and obtain user tokens through the Authorization Window; non-role users require approved permissions and a published app.",
      "apiProtocols": [
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Official API covers publishing, media and profile retrieval, replies, mentions, insights, keyword search, location tagging, webhooks, and oEmbed.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "App Review and publication for non-role users",
      "recommendedNextStep": "Create the Threads use case, configure OAuth redirect and deletion URLs, test with Threads Testers, then submit required permissions for App Review before production rollout.",
      "confidence": "high",
      "uncertainties": "Meta has official MCP documentation for some Meta products, but no official Threads-specific MCP endpoint or exact-app Composio MCP evidence was identified.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Meta documents OAuth 2.0 Threads user access tokens, short- and long-lived token exchange, and an Authorization Window. Testers can grant permissions directly; users without app roles require permission approval through App Review and a published app. The official Threads index lists publishing, media, replies, insights, webhooks, and related capabilities.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.facebook.com/documentation/threads/get-started",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.facebook.com/documentation/development/create-an-app/threads-use-case",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.facebook.com/documentation/threads",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 Threads user access tokens"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 Threads user access tokens"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 40,
      "appName": "SendGrid",
      "category": "Marketing, Ads, Email and Social",
      "startingHint": "sendgrid.com",
      "whatItDoes": "Email API and marketing platform for sending transactional email, managing campaigns and contacts, and monitoring delivery statistics.",
      "authMethods": [
        "Bearer API key",
        "Basic API key"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "A user can sign up for a 60-day free Email API trial and create scoped API keys in the SendGrid console; sender verification and account security controls may still be required.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST v3 API covers transactional mail, marketing campaigns, contacts, templates, suppressions, sender authentication, statistics, settings, and account administration.",
      "mcpStatus": "mcp_possible_via_api",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Sender verification and account-level sending restrictions",
      "recommendedNextStep": "Create a least-privilege SendGrid API key, verify the sending identity, and implement against the v3 API with trial-volume limits tested first.",
      "confidence": "high",
      "uncertainties": "The official Twilio MCP documentation does not clearly establish dedicated SendGrid operational tools, so MCP exposure should be treated as API-mediated rather than native SendGrid MCP.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Twilio documents Bearer API-key authentication and Basic authentication using username apikey plus the API key as password for some services. Its API-key guide documents console creation and scoped permissions, while the API reference covers mail, campaigns, contacts, and statistics. Twilio documents an MCP server for Twilio APIs, not a dedicated SendGrid MCP server.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://www.twilio.com/docs/sendgrid/for-developers/sending-email/authentication",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.twilio.com/en-us/products/email-api/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://www.twilio.com/docs/sendgrid/api-reference",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.twilio.com/docs/ai/mcp",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer API key",
            "Basic API key"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer API key",
            "Basic API key"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 41,
      "appName": "Shopify",
      "category": "Ecommerce",
      "startingHint": "shopify.dev",
      "whatItDoes": "Ecommerce platform providing online stores, product catalogs, checkout, orders, payments, and merchant APIs.",
      "authMethods": [
        "OAuth 2.0",
        "bearer/PAT"
      ],
      "selfServeStatus": "app_review",
      "selfServeSummary": "Create a Shopify app and use OAuth/token exchange or an admin-generated token; public multi-store distribution requires Shopify approval, while custom distribution does not.",
      "apiProtocols": [
        "GraphQL",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "GraphQL Admin API and Storefront APIs cover products, inventory, orders, customers, checkout, carts, fulfillment, webhooks, extensions, and billing.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Shopify App Store review for public multi-store distribution",
      "recommendedNextStep": "Build against the GraphQL Admin API, implement OAuth/token exchange and required scopes, then submit the public app for Shopify review.",
      "confidence": "high",
      "uncertainties": "Public App Store review is required for public distribution; a narrowly scoped custom-distribution integration can avoid that gate.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Shopify documents session tokens, token exchange, authorization-code grant, and admin-created access tokens. Its distribution table says public apps require approval, whereas custom distribution does not. The Admin API is GraphQL and broad; Shopify also publishes Storefront MCP endpoints for catalog, cart, and policy tools.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://shopify.dev/docs/apps/build/authentication-authorization",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://shopify.dev/docs/apps/launch/distribution",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://shopify.dev/docs/api/admin-graphql/latest",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://shopify.dev/docs/apps/build/storefront-mcp/servers/storefront",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT",
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "verified": {
          "authMethods": "OAuth 2.0, bearer access token, client credentials, custom app access token",
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Shopify officially documents OAuth 2.0/token exchange, bearer tokens and custom-app tokens. Its APIs span Admin, Storefront, extensions, webhooks, payments and partner surfaces. First-party MCP servers exist; public distribution still requires review.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://shopify.dev/docs/api/usage/authentication",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://shopify.dev/docs/apps/launch/app-store-review/review-process",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://shopify.dev/docs/api",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://shopify.dev/docs/apps/build/storefront-mcp",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 42,
      "appName": "WooCommerce",
      "category": "Ecommerce",
      "startingHint": "woocommerce.com/document/woocommerce-rest-api",
      "whatItDoes": "Open-source WordPress ecommerce platform for managing products, orders, customers, payments, shipping, and store operations.",
      "authMethods": [
        "API key",
        "Basic",
        "other"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Install the free core plugin on a WordPress site, then a store administrator generates scoped Consumer Key and Consumer Secret credentials in WooCommerce settings.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Versioned WordPress REST API v3 supports CRUD and batch operations across products, orders, customers, coupons, taxes, shipping, payments, settings, webhooks, reports, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Native MCP remains in developer preview and requires a merchant-owned WordPress/WooCommerce site with admin-generated credentials.",
      "recommendedNextStep": "Build against REST API v3 first, then add the official MCP path behind a preview feature flag and validate version and permission behavior.",
      "confidence": "high",
      "uncertainties": "MCP feature availability and endpoint details may change because the official implementation is still in developer preview.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Official docs state that WooCommerce uses generated Consumer Key and Consumer Secret credentials, supports HTTP Basic Auth over HTTPS and OAuth 1.0a over HTTP; REST API v3 spans major store resources. WooCommerce pricing identifies core as free, while MCP docs mark native support as developer preview and describe API-key authentication and permissions.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.woocommerce.com/docs/apis/rest-api/authentication/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://woocommerce.com/document/woocommerce-rest-api/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.woocommerce.com/docs/apis/rest-api/v3/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.woocommerce.com/docs/features/mcp/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "API key, Basic, other",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "verified": {
          "authMethods": "API key,HTTP Basic,OAuth 1.0a,query-string credentials,WordPress REST authentication plugins",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "All prior fields are defensible. Official docs confirm self-generated REST keys, Basic/OAuth options, broad store APIs, and native MCP; MCP remains developer preview/beta, supporting build_with_review.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://developer.woocommerce.com/docs/apis/rest-api/authentication/",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://woocommerce.com/document/woocommerce-rest-api/",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developer.woocommerce.com/docs/apis/rest-api/",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://developer.woocommerce.com/docs/features/mcp/",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 43,
      "appName": "BigCommerce",
      "category": "Ecommerce",
      "startingHint": "developer.bigcommerce.com",
      "whatItDoes": "Ecommerce platform APIs for managing store data, storefront experiences, customers, carts, checkouts, payments, and commerce apps.",
      "authMethods": [
        "OAuth 2.0 authorization code grant",
        "store-level API access token",
        "account-level API access token"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Developers can create store-level or app-level credentials through BigCommerce controls, but a merchant store owner or authorized user must authorize app access; MCP requires store-owner enablement.",
      "apiProtocols": [
        "REST",
        "GraphQL"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST Store Management, Storefront, Payments, B2B, and GraphQL Admin, Storefront, Account, Customer Login, and Current Customer APIs are documented.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Store-owner enablement and beta MCP access",
      "recommendedNextStep": "Create a least-privilege API account, obtain merchant authorization, and have the store owner enable and test BigCommerce MCP before production use.",
      "confidence": "high",
      "uncertainties": "MCP availability and behavior may change because the official server is currently documented as beta; marketplace distribution also has a separate approval path.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "BigCommerce documents OAuth-based store-, app-, and account-level API accounts. App credentials require store installation and authorization, while unapproved apps are restricted to stores owned by the developer-account email. Its official MCP is beta and must be enabled by the store owner under Early access.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.bigcommerce.com/developer/docs/overview/api-fundamentals/api-accounts",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.bigcommerce.com/developer/docs/integrations/apps/guide/auth",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.bigcommerce.com/developer/api-reference/about-our-apis",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.bigcommerce.com/developer/api-reference/mcp/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 access tokens",
            "store-level API credentials",
            "app-level OAuth grant code flow",
            "account-level API credentials"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 access tokens",
            "store-level API credentials",
            "app-level OAuth grant code flow",
            "account-level API credentials"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": false,
          "apiBreadth": false,
          "mcp": true,
          "verdict": true
        },
        "verifierNote": "API credentials are self-serve for a store or draft app, but public multi-store app distribution requires approval; the official storefront MCP is beta and must be enabled by the store owner via Early Access.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 44,
      "appName": "Salesforce Commerce Cloud",
      "category": "Ecommerce",
      "startingHint": "developer.salesforce.com/docs/commerce",
      "whatItDoes": "Cloud commerce platform providing B2C storefront, catalog, basket, order, shopper, and merchant administration capabilities through commerce APIs.",
      "authMethods": [
        "OAuth 2.1 client credentials",
        "SLAS JWT bearer tokens"
      ],
      "selfServeStatus": "contact_sales",
      "selfServeSummary": "API clients require a Salesforce Commerce Cloud organization or instance plus Account Manager or SLAS configuration; the official MCP shopper pilot requires onboarding to SLAS/SCAPI and contacting a Salesforce account executive.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; SCAPI exposes shopper and admin resources including catalogs, products, customers, inventory, orders, assignments, and custom APIs, with OCAPI also supported.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Salesforce account-executive onboarding and pilot availability for MCP",
      "recommendedNextStep": "Confirm Commerce Cloud entitlement and instance access with Salesforce, then request MCP pilot onboarding and provision scoped SLAS credentials.",
      "confidence": "high",
      "uncertainties": "The MCP shopper service is documented as a pilot, so availability, scope, and production terms may change.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Salesforce documents OAuth-based client permissions and JWT Bearer access for SCAPI, with separate Account Manager admin clients and SLAS shopper clients. Its official B2C Commerce MCP Shopper Service is a pilot requiring SLAS/SCAPI onboarding and contact with a Salesforce account executive.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.salesforce.com/docs/commerce/commerce-api/guide/authorization.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/agentic-mcp-shopper-tools-quick-start.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.salesforce.com/docs/commerce/commerce-api/guide/authorization-for-admin-apis.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.salesforce.com/docs/commerce/b2c-commerce/guide/agentic-mcp-shopper-tools-quick-start.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.1 client credentials",
            "SLAS JWT bearer tokens"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.1 client credentials",
            "SLAS JWT bearer tokens"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 45,
      "appName": "Magento / Adobe Commerce",
      "category": "Ecommerce",
      "startingHint": "developer.adobe.com/commerce",
      "whatItDoes": "API-first commerce platform for catalog, customer, cart, checkout, orders, inventory, and headless storefront integrations.",
      "authMethods": [
        "OAuth 1.0a integration credentials",
        "Bearer access tokens",
        "session cookies"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "A merchant or store administrator must create and activate an Admin integration, select API resources, approve access, and securely provide the generated OAuth credentials or tokens.",
      "apiProtocols": [
        "REST",
        "GraphQL"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Official REST and GraphQL APIs cover commerce administration, catalog, customers, carts, checkout, orders, inventory, and storefront use cases, with deployment-specific differences.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Merchant-admin approval and deployment-specific Commerce credentials",
      "recommendedNextStep": "Obtain a test Commerce instance and merchant-admin authorization, then validate the required REST or GraphQL scopes against the target deployment.",
      "confidence": "high",
      "uncertainties": "The official MCP documentation establishes Commerce development tooling, not a generic MCP interface for arbitrary Magento or Adobe Commerce store operations.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Adobe documents OAuth 1.0a for third-party applications, token authentication for mobile applications, and session-based authentication. Its Admin workflow requires creating an integration, selecting resources, activating it, and clicking Allow. Adobe also publishes official Commerce development MCP servers, but these target App Builder and storefront development rather than a general merchant-data MCP.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.adobe.com/commerce/webapi/get-started/authentication/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://experienceleague.adobe.com/en/docs/commerce-admin/systems/integrations",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.adobe.com/commerce/webapi/rest/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.adobe.com/commerce/extensibility/developer-agent/coding-tools",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 1.0a integration credentials",
            "Bearer access tokens",
            "session cookies"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 1.0a integration credentials",
            "Bearer access tokens",
            "session cookies"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 46,
      "appName": "Squarespace",
      "category": "Ecommerce",
      "startingHint": "developers.squarespace.com",
      "whatItDoes": "Website and commerce platform with APIs for managing products, orders, inventory, contacts, discounts, transactions, and related data.",
      "authMethods": [
        "OAuth 2.0",
        "Bearer access token"
      ],
      "selfServeStatus": "app_review",
      "selfServeSummary": "A developer can submit an OAuth client registration with app metadata, redirect URI, policies, and scopes, but Squarespace reviews the registration before issuing client credentials.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST Commerce APIs cover analytics, contacts, discounts, inventory, orders, products, transactions, webhooks, and legacy profiles.",
      "mcpStatus": "mcp_possible_via_api",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Squarespace review and issuance of OAuth client credentials",
      "recommendedNextStep": "Submit the OAuth client registration, then implement the authorization-code flow with only the required Commerce API scopes.",
      "confidence": "high",
      "uncertainties": "No official Squarespace MCP source was identified; third-party MCP listings were not treated as native or official Squarespace MCP support.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Squarespace documents OAuth 2.0 for third-party applications. Clients must be registered, and Squarespace reviews the registration before returning client_id and client_secret. The Commerce API overview lists broad REST resources and webhooks; no official Squarespace MCP is documented.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.squarespace.com/commerce-apis/oauth",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://account.squarespace.com/developer-apps",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.squarespace.com/commerce-apis/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0",
            "Bearer access token"
          ],
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0",
            "Bearer access token"
          ],
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 47,
      "appName": "Ecwid",
      "category": "Ecommerce",
      "startingHint": "api-docs.ecwid.com",
      "whatItDoes": "Ecommerce platform and API for managing store data, products, orders, customers, settings, payments, shipping, and storefront features.",
      "authMethods": [
        "OAuth 2.0",
        "Bearer token"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a private custom app in Ecwid admin, install it in the store, and copy its non-expiring public or secret access token; public-app review is only needed for marketplace distribution.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST API covers store settings, catalog, orders, customers, discounts, promotions, reviews, subscriptions, staff, webhooks, and payment/shipping features.",
      "mcpStatus": "mcp_possible_via_api",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Store owner must create/install a custom app and provide its store-specific token",
      "recommendedNextStep": "Create a private Ecwid custom app, request only the required scopes, install it in the target store, and use the resulting secret Bearer token for server-side calls.",
      "confidence": "high",
      "uncertainties": "No official Ecwid or exact-app Composio MCP server was identified, so MCP is classified only as possible through the documented API.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Ecwid documents OAuth 2.0 for public apps and Bearer access tokens for REST calls. Private custom apps are self-serve in the admin and receive store-specific non-expiring tokens; official sources reviewed provide no Ecwid-native or Composio-specific MCP evidence.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.ecwid.com/get-started/make-your-first-api-request",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.ecwid.com/develop-apps/private-and-public-ecwid-apps.md",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.ecwid.com/develop-apps/app-settings",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0",
            "Bearer token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0",
            "Bearer token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 48,
      "appName": "Gumroad",
      "category": "Ecommerce",
      "startingHint": "gumroad.com/api",
      "whatItDoes": "Gumroad lets creators sell digital products, memberships, and subscriptions, with APIs for managing products, sales, customers, and related data.",
      "authMethods": [
        "access token",
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create an application from Gumroad Advanced Settings and generate an access token for your own account; multi-user apps use OAuth with a redirect URI, client ID, and secret, with no documented review gate.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "REST OAuth API covering products, variants, offer codes, custom fields, sales, subscribers, profile, payouts, tax data, and license verification.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Create a Gumroad application, generate a test access token, and validate the required scopes and endpoints against a sandbox or low-risk creator account.",
      "confidence": "high",
      "uncertainties": "Gumroad does not clearly document a dedicated sandbox environment, so production-account testing may be required.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Gumroad’s official help documents manually generating an access token for the creator’s own account and OAuth authorization for any Gumroad account. Its API reference documents OAuth 2.0 scopes and REST endpoints; no official Gumroad MCP server was found.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://app.gumroad.com/api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://gumroad.com/help/article/280-create-application-api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://app.gumroad.com/api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "access token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "access token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 49,
      "appName": "Amazon Selling Partner API",
      "category": "Ecommerce",
      "startingHint": "developer-docs.amazon.com/sp-api",
      "whatItDoes": "REST APIs for Amazon sellers and vendors covering catalog, listings, orders, inventory, fulfillment, reports, finance, and related operations.",
      "authMethods": [
        "OAuth 2.0 via Login with Amazon (LWA)",
        "LWA access token",
        "LWA refresh token",
        "Restricted Data Token (RDT)",
        "client credentials grantless flow"
      ],
      "selfServeStatus": "app_review",
      "selfServeSummary": "You can register through Amazon's developer portals, but public developers undergo Amazon review; restricted roles require architecture and data-security review, while seller/vendor authorization is also required.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST API documentation spans catalog, listings, orders, inventory, fulfillment, reports, finance, notifications, seller/vendor workflows, and many additional APIs.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Amazon developer and role approval review",
      "recommendedNextStep": "Register in the Solution Provider Portal or Seller Central, submit the developer profile and required roles, then complete app registration and seller/vendor authorization.",
      "confidence": "high",
      "uncertainties": "Amazon offers private self-authorization, but the exact approval path depends on whether the implementation is private or public and which roles it requests.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Amazon documents LWA OAuth 2.0, refresh-token authorization, client-credentials grantless operations, and RDTs for restricted data. Public developers must register, select roles, pass Amazon review, and obtain selling-partner authorization; no official Amazon MCP source was verified.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer-docs.amazon.com/sp-api/docs/connecting-to-the-selling-partner-api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developer-docs.amazon.com/sp-api/docs/register-as-a-public-developer",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer-docs.amazon.com/sp-api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 via Login with Amazon (LWA)",
            "LWA access token",
            "LWA refresh token",
            "Restricted Data Token (RDT)",
            "client credentials grantless flow"
          ],
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 via Login with Amazon (LWA)",
            "LWA access token",
            "LWA refresh token",
            "Restricted Data Token (RDT)",
            "client credentials grantless flow"
          ],
          "selfServeStatus": "app_review",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 50,
      "appName": "FanBasis",
      "category": "Ecommerce",
      "startingHint": "fanbasis.com",
      "whatItDoes": "Creator-commerce platform for selling checkouts, courses, communities, webinars, affiliates, and embedded payments.",
      "authMethods": [
        "unknown"
      ],
      "selfServeStatus": "contact_sales",
      "selfServeSummary": "Official site places APIs and SDKs under Enterprise and the developer docs require a password; public self-serve API credential issuance is not documented.",
      "apiProtocols": [
        "SDK"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; official site advertises embedded checkouts, multi-rail payouts, APIs, and SDKs, but detailed endpoint documentation is access-controlled.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "blocked_by_access",
      "buildabilityVerdict": "outreach_required",
      "primaryBlocker": "API documentation and credentials require gated access",
      "recommendedNextStep": "Contact Commas/FanBasis Enterprise to request API documentation, authentication details, credentials, and MCP beta enrollment.",
      "confidence": "high",
      "uncertainties": "The official site does not disclose the API authentication method, Enterprise approval workflow, or MCP connection endpoint publicly.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "FanBasis has rebranded to Commas. The official homepage advertises Enterprise APIs and SDKs plus an MCP beta, while the official FanBasis API documentation is password-protected. No public authentication scheme or self-serve API-key process is exposed.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://dev-docs.fanbasis.com/login.html",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://commas.com/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://commas.com/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://commas.com/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "unknown"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "outreach_required"
        },
        "replaced": {
          "authMethods": [
            "unknown"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "outreach_required"
        }
      }
    },
    {
      "id": 51,
      "appName": "DataForSEO",
      "category": "Data, SEO and Scraping",
      "startingHint": "docs.dataforseo.com",
      "whatItDoes": "Provides REST APIs and MCP access to SERP, keyword, backlink, on-page, business, domain, and other SEO and marketing data.",
      "authMethods": [
        "Basic"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Register directly for API credentials and $1 trial credits; usage is pay-as-you-go with a stated $50 minimum payment.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST/JSON APIs cover SERP, AI optimization, keyword data, backlinks, on-page, labs, business data, domain analytics, and related SEO datasets.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Implement the official MCP/API integration using API login/password Basic Auth, with OAuth 2.0 for HTTP MCP where supported.",
      "confidence": "high",
      "uncertainties": "The exact trial eligibility and credit terms may vary by account type or change over time.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Official docs state Basic authentication is used for the API; the official MCP repository documents OAuth 2.0 as the default for HTTP MCP and API login/password via HTTP Basic as fallback. Registration provides $1 trial credits, while pricing is pay-as-you-go with a $50 minimum payment. The API catalog spans multiple SEO and marketing domains.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.dataforseo.com/v3/auth/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://dataforseo.com/help-center/how-does-your-free-unlimited-trial-work",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://dataforseo.com/apis",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://dataforseo.com/model-context-protocol",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "Basic, OAuth 2.0",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "Basic",
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": false,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Official docs state Basic authentication is the only API method; OAuth 2.0 is not documented. Account signup provides API credentials and $1 trial credit, while broad APIs and an official MCP server are available.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://docs.dataforseo.com/v3/auth/",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://dataforseo.com/help-center/how-does-your-free-unlimited-trial-work",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://dataforseo.com/apis",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://dataforseo.com/model-context-protocol",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 52,
      "appName": "SE Ranking",
      "category": "Data, SEO and Scraping",
      "startingHint": "seranking.com/api",
      "whatItDoes": "SEO and GEO platform providing keyword, backlink, domain, site-audit, rank-tracking, and AI-search visibility data through APIs and MCP.",
      "authMethods": [
        "Authorization: Token API key",
        "apikey query parameter",
        "OAuth 2.1 for remote MCP"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Start a 14-day trial with 100,000 free API credits, create an API key in the account API Dashboard, and authorize MCP through OAuth; paid plans or credits are needed for sustained usage.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Data API covers keywords, backlinks, domain research, site audits, SERP and AI Search, while Project API manages projects, rankings, audits, and related account workflows.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Trial credit limits and paid credits for sustained or high-volume production use",
      "recommendedNextStep": "Create a trial account, generate an API key in the API Dashboard, and validate the required endpoints or remote MCP OAuth flow within the available credits.",
      "confidence": "high",
      "uncertainties": "Exact endpoint availability and limits can vary by plan, account type, and remaining API credits.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs specify API-key authentication via Authorization: Token or the apikey query parameter, with keys created in the API Dashboard. SE Ranking documents a 14-day trial with 100,000 free API credits and a centrally hosted remote MCP server using OAuth 2.1, with 160+ tools.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://seranking.com/api/data/getting-started/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://seranking.com/api/how-to-get-api/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://seranking.com/api/data/reference/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://seranking.com/api/integrations/mcp/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Authorization: Token API key",
            "apikey query parameter",
            "OAuth 2.1 for remote MCP"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Authorization: Token API key",
            "apikey query parameter",
            "OAuth 2.1 for remote MCP"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 53,
      "appName": "Ahrefs",
      "category": "Data, SEO and Scraping",
      "startingHint": "ahrefs.com/api",
      "whatItDoes": "Provides SEO, search, backlink, rank-tracking, site-audit, brand, and social-media data through APIs and developer tools.",
      "authMethods": [
        "API key (Bearer token)"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "API access is available on eligible paid plans; workspace owners or admins create API keys, while other plans have limited free test queries.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; API v3 covers Site Explorer, Keywords Explorer, SERP Overview, Rank Tracker, Site Audit, Brand Radar, Social Media Management, management, subscription, and public endpoints.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Eligible paid plan and workspace owner/admin API-key access",
      "recommendedNextStep": "Confirm an eligible paid Ahrefs plan and obtain a workspace-owner/admin-created API key before implementation.",
      "confidence": "high",
      "uncertainties": "Exact eligible plan entitlements and unit allowances can change; verify the current pricing page before procurement.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Ahrefs documents Bearer API-key authentication and says only workspace owners and admins can create keys. API v3 is available on eligible paid plans, with limited free test queries on other plans. Ahrefs also documents a hosted MCP server for Lite and higher paid plans.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.ahrefs.com/en/api/docs/api-keys-creation-and-management",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.ahrefs.com/en/api/docs/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.ahrefs.com/en/api/docs/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.ahrefs.com/en/mcp/docs/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer API key"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Bearer API key"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": false
        },
        "verifierNote": "Production API access requires an eligible paid plan; free plans only receive limited test queries, while Ahrefs officially provides a hosted MCP server for Lite and higher.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 54,
      "appName": "MrScraper",
      "category": "Data, SEO and Scraping",
      "startingHint": "docs.mrscraper.com",
      "whatItDoes": "AI-powered web scraping platform that extracts structured data, fetches HTML, runs scrapers, and supports marketplace and travel data APIs.",
      "authMethods": [
        "API token via x-api-token header",
        "Bearer API token for official MCP",
        "query-parameter token for analytics"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create API tokens from the dashboard after opening an account; official docs describe a no-card Free plan, while usage is limited by monthly tokens.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "REST API covers platform scraper/result/analytics functions plus web unblocker, AI parser, SEO, marketplace, travel, and domain-specific endpoints.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Usage limits and scraper setup/token consumption",
      "recommendedNextStep": "Create a Free account, generate an API token, then validate one REST scraper call and the hosted MCP endpoint before scaling.",
      "confidence": "high",
      "uncertainties": "The billing page contains an inconsistent API-token allocation table versus its Free-plan limitation text; exact current quota should be confirmed in the dashboard.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs require an API token for API endpoints, support x-api-token authentication, and provide dashboard token creation. Billing documents a no-card Free plan with monthly tokens. MrScraper publishes its own hosted MCP server at mcp.mrscraper.com/mcp using Bearer API-token authentication.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.mrscraper.com/docs/api/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.mrscraper.com/docs/getting-started/api-token",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.mrscraper.com/docs/api/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.mrscraper.com/docs/getting-started/mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API token via x-api-token header",
            "Bearer API token for official MCP",
            "query-parameter token for analytics"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "API token via x-api-token header",
            "Bearer API token for official MCP",
            "query-parameter token for analytics"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 55,
      "appName": "Apify",
      "category": "Data, SEO and Scraping",
      "startingHint": "docs.apify.com",
      "whatItDoes": "A web data platform for running Actors, scraping and automation jobs, and storing and retrieving structured results.",
      "authMethods": [
        "Bearer API token",
        "token query parameter",
        "OAuth",
        "x402 payment credential",
        "Skyfire payment credential"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create an Apify account and API token from the Console; the official Free plan is $0, requires no credit card, and includes limited platform usage.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST API v2 covers Actors, runs, builds, tasks, datasets, key-value stores, request queues, webhooks, schedules, users, usage, logs, and Store.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Usage limits and Actor-specific pricing or permissions",
      "recommendedNextStep": "Create a scoped Apify API token, test the required Actor and storage endpoints, then connect the official hosted MCP server if agent tooling is needed.",
      "confidence": "high",
      "uncertainties": "Exact capabilities and costs vary by Actor, account permissions, plan limits, and whether usage exceeds Free-plan credits.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Apify officially documents Bearer-header and URL-token API authentication, token creation in Console, and a REST API v2 with broad platform coverage. Its pricing page lists a $0 Free plan with no credit card required. Apify also documents its hosted MCP server at mcp.apify.com with OAuth or Apify-token authentication.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.apify.com/integrations/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://apify.com/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.apify.com/api/v2",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.apify.com/integrations/mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer API token",
            "token query parameter",
            "OAuth",
            "x402 payment credential",
            "Skyfire payment credential"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer API token",
            "token query parameter",
            "OAuth",
            "x402 payment credential",
            "Skyfire payment credential"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 56,
      "appName": "Firecrawl",
      "category": "Data, SEO and Scraping",
      "startingHint": "firecrawl.dev",
      "whatItDoes": "Provides APIs and MCP tools to search, scrape, crawl, map, parse, monitor, interact with, and extract data from the web.",
      "authMethods": [
        "Bearer API key",
        "keyless no-auth access"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Firecrawl offers a free 1,000-credit monthly tier with no card; current official keyless access also permits limited API use without an API key, while keys are self-served in the dashboard.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST API covers search, scrape, crawl, map, extract, interact, parse, monitor, and agent capabilities with documented v1/v2 references.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Free-tier rate and credit limits",
      "recommendedNextStep": "Build against the documented REST API or official hosted MCP endpoint, starting keyless and adding a dashboard API key when higher limits or unattended access are required.",
      "confidence": "high",
      "uncertainties": "The keyless announcement is newer than portions of the API reference, so exact endpoint coverage and limits for unauthenticated REST calls should be verified during implementation.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs document Bearer API-key authentication and dashboard key creation, while Firecrawl’s June 2026 keyless announcement states that REST API calls can run without an Authorization header on a 1,000-credit monthly free tier. Firecrawl also publishes and hosts its own MCP server.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.firecrawl.dev/api-reference/v2-introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.firecrawl.dev/blog/firecrawl-keyless-launch",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.firecrawl.dev/api-reference/v2-introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.firecrawl.dev/mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer API key",
            "keyless no-auth access"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer API key",
            "keyless no-auth access"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 57,
      "appName": "Bright Data",
      "category": "Data, SEO and Scraping",
      "startingHint": "brightdata.com",
      "whatItDoes": "Provides proxy networks, web scraping APIs, browser automation, SERP data, datasets, and an official MCP server for real-time public web data.",
      "authMethods": [
        "API key (Bearer token)",
        "proxy username/password"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "A Bright Data account provides a default API key; new accounts receive 5,000 free MCP requests monthly, while product usage follows the selected plan and account permissions.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "Official APIs cover Web Unlocker, SERP, Scrapers, Browsers, Functions, Marketplace, proxy access, datasets, and MCP connectivity.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Usage limits and paid-plan charges beyond the free tier",
      "recommendedNextStep": "Create a Bright Data account, retrieve the API key from account settings, and validate the target API or MCP endpoint with a minimal request.",
      "confidence": "high",
      "uncertainties": "Exact free-tier eligibility and product-level pricing can vary by account, product, geography, and current commercial terms.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Bright Data officially documents API-key Bearer authentication and native proxy username/password access. Its MCP documentation identifies a first-party hosted and self-hosted server, requires a Bright Data account and API key, and states that new accounts include 5,000 free requests monthly.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.brightdata.com/api-reference/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.brightdata.com/ai/mcp-server/remote/quickstart",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.brightdata.com/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.brightdata.com/ai/mcp-server/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key (Bearer token)",
            "proxy username/password"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "API key (Bearer token)",
            "proxy username/password"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 58,
      "appName": "Sherlock",
      "category": "Data, SEO and Scraping",
      "startingHint": "github.com/sherlock-project/sherlock",
      "whatItDoes": "Open-source CLI that checks usernames across 400+ social networks and exports discovered profile results.",
      "authMethods": [
        "CLI/local"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Install the official package or Docker image locally and run searches without an account, API key, OAuth flow, or approval.",
      "apiProtocols": [
        "REST",
        "CLI"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Local CLI and an official organization REST API repository support username searches, with results export and site/proxy/timeout controls.",
      "mcpStatus": "native_third_party_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "No maintained hosted API or official MCP is documented",
      "recommendedNextStep": "Validate the official CLI/API repository’s maintenance and scraping-policy risks before packaging a managed integration.",
      "confidence": "medium",
      "uncertainties": "The official API repository is substantially less active than the main project, so current deployability and endpoint coverage are unclear.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "The official docs provide pipx, pip, Docker, and source installation with direct `sherlock USERNAME` execution; the CLI exposes username search, exports, proxy, timeout, and site-selection options. The project’s separate official API repository describes a Django REST Framework API, but no auth or hosted service is documented. Official MCP documentation was not found.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://sherlockproject.xyz/installation",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://github.com/sherlock-project/sherlock/blob/master/LICENSE",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://sherlockproject.xyz/sites",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://github.com/Burnsedia/sherlock-mcp",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "CLI/local",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "moderate",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        },
        "verified": {
          "authMethods": "CLI/local",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_third_party_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": false,
          "mcp": false,
          "verdict": true
        },
        "correctionSummary": "Official Sherlock is a free, locally installed CLI covering 400+ sites, not a conventional hosted API. A community third-party MCP server exists; no official MCP or official API was found.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://sherlockproject.xyz/installation",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://github.com/sherlock-project/sherlock/blob/master/LICENSE",
            "sourceType": "official_github_or_repository",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://sherlockproject.xyz/sites",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://github.com/Burnsedia/sherlock-mcp",
            "sourceType": "official_github_or_repository",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 59,
      "appName": "Waterfall.io",
      "category": "Data, SEO and Scraping",
      "startingHint": "waterfall.io, contact/company intelligence",
      "whatItDoes": "B2B enrichment API that searches and enriches contacts and companies, verifies emails, finds phone numbers, and detects job changes.",
      "authMethods": [
        "API key (x-api-key header)"
      ],
      "selfServeStatus": "contact_sales",
      "selfServeSummary": "API credentials are provided under a customer contract; official onboarding starts with a sales call, testing, signing, and integration, with prepaid or invoiced usage.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST API covering prospecting, contact/company/phone enrichment, contact/company search, email verification, job-change detection, webhooks, reporting, and API-key management",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "blocked_by_access",
      "buildabilityVerdict": "outreach_required",
      "primaryBlocker": "Contract-based API key issuance",
      "recommendedNextStep": "Contact Waterfall.io to obtain a contract and master API key, then validate the required endpoints and usage limits.",
      "confidence": "high",
      "uncertainties": "No official Waterfall.io MCP server or exact-app Composio MCP exposure was found.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs require an API key in the x-api-key header and state the key is provided in a contract; the API reference covers prospecting, enrichment, search, verification, job changes, webhooks, reporting, and key management. Waterfall's onboarding page begins with a sales call and contract.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.waterfall.io/v1/api-keys-create",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.waterfall.io/book-a-call",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.waterfall.io/v1/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key (x-api-key header)"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "outreach_required"
        },
        "replaced": {
          "authMethods": [
            "API key (x-api-key header)"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "outreach_required"
        }
      }
    },
    {
      "id": 60,
      "appName": "Clay",
      "category": "Data, SEO and Scraping",
      "startingHint": "clay.com",
      "whatItDoes": "Clay is a GTM data and workflow platform for prospecting, enrichment, research, and outbound execution.",
      "authMethods": [
        "API key",
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "A Clay account can expose a personal API key, but Clay API access is a paid-plan feature; MCP also requires workspace invitation and admin-controlled limits.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "moderate",
      "apiSurfaceSummary": "moderate; Official API-key documentation covers Clay-native integrations and single or multiple row lookups, while broader workflow capabilities are exposed through integrations, Functions, and MCP.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Paid-plan and workspace-admin controls",
      "recommendedNextStep": "Use a paid Clay workspace to create an API key, validate the documented row-lookup calls, and obtain admin approval for the required MCP users, Functions, and credit limits.",
      "confidence": "high",
      "uncertainties": "The public API-key page does not publish complete endpoint, request, response, rate-limit, or OAuth details; OAuth is documented by Clay's official MCP connection flow rather than the public API-key page.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Clay documents a personal API key in Settings for Clay-native integrations and says it supports single- and multi-row lookups. Its pricing page lists Clay API access as a plan feature. Official MCP docs describe Clay's connection to Claude, ChatGPT, Copilot, and Glean, with paid-plan and workspace-admin controls.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://university.clay.com/docs/guide-find-clay-api-key",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.clay.com/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://university.clay.com/docs/guide-find-clay-api-key",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://university.clay.com/docs/mcp-settings",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "API key",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "moderate",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 61,
      "appName": "GitHub",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "docs.github.com/rest",
      "whatItDoes": "A collaborative software-development platform with repositories, code review, issues, CI/CD, security, and extensive automation APIs.",
      "authMethods": [
        "OAuth 2.0",
        "bearer/PAT",
        "Basic",
        "CLI/local"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a GitHub account and self-serve a PAT, OAuth App, or GitHub App; organization policies, SSO, and paid feature entitlements can restrict access.",
      "apiProtocols": [
        "REST",
        "GraphQL"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST and GraphQL APIs cover repositories, code, issues, pull requests, actions, releases, organizations, users, security, projects, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Endpoint-specific permissions and organization policy restrictions",
      "recommendedNextStep": "Implement the official GitHub MCP Server/API integration with least-privilege OAuth or PAT credentials and validate organization-policy edge cases.",
      "confidence": "high",
      "uncertainties": "Specific MCP tool availability and paid requirements vary by GitHub feature, plan, organization policy, and host application.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "GitHub documents PATs, GitHub App tokens, OAuth tokens, Bearer/token authorization, and limited Basic auth for app endpoints. Its official MCP server is GitHub-maintained, available to GitHub users, and exposes repository, issue, pull-request, workflow, security, and related actions subject to feature permissions and policies.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.github.com/rest/authentication/authenticating-to-the-rest-api",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.github.com/en/copilot/how-tos/provide-context/use-mcp-in-your-ide/set-up-the-github-mcp-server",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.github.com/rest/overview/api-versions",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://github.com/github/github-mcp-server",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT, Basic, CLI/local",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0, bearer/token PAT, GitHub App JWT/installation token, Basic for app endpoints, GitHub Actions token, GitHub CLI",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "All prior fields are defensible. Official docs confirm OAuth/PAT/App/CLI auth, free API availability, broad REST/GraphQL coverage, and a GitHub-maintained MCP server available to all users; paid features remain tool-specific.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://docs.github.com/rest/authentication/authenticating-to-the-rest-api",
            "sourceType": "official_github_or_repository",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://docs.github.com/en/copilot/how-tos/provide-context/use-mcp-in-your-ide/set-up-the-github-mcp-server",
            "sourceType": "official_github_or_repository",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api",
            "sourceType": "official_github_or_repository",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://github.com/github/github-mcp-server",
            "sourceType": "official_github_or_repository",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 62,
      "appName": "Vercel",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "vercel.com/docs/rest-api",
      "whatItDoes": "Cloud platform for deploying, scaling, and operating frontend and full-stack applications.",
      "authMethods": [
        "bearer/PAT"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create an account and generate a full-account, team, or project-scoped access token from the dashboard, REST API, or CLI; Hobby is free with usage limits.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST API covers deployments, projects, domains, DNS, environment variables, teams, billing, analytics, storage, networking, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Build the integration against Vercel’s REST API using scoped Bearer tokens, and separately validate MCP client-review requirements if MCP exposure is needed.",
      "confidence": "high",
      "uncertainties": "Some individual REST endpoints and MCP tools may have plan-, team-, or permission-specific restrictions not enumerated in the overview pages.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Vercel documents access tokens as authenticating REST API and CLI requests, with full-account, team, and project scopes. Its REST reference spans deployments, domains, DNS, projects, billing, analytics, storage, and networking. Vercel also documents an official OAuth remote MCP server at https://mcp.vercel.com, but says supported AI clients must be reviewed and approved.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://vercel.com/docs/accounts/access-tokens",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://vercel.com/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://vercel.com/docs/rest-api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://vercel.com/docs/agent-resources/vercel-mcp",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "bearer/PAT",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "bearer token, personal access token",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Official docs confirm bearer access tokens/PATs, a $0 Hobby plan, a broad REST API spanning deployments, domains, projects, billing, analytics and more, and Vercel's first-party OAuth MCP server. No correction needed.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://vercel.com/kb/guide/how-do-i-use-a-vercel-api-access-token",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://vercel.com/pricing",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://vercel.com/docs/rest-api",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://vercel.com/docs/agent-resources/vercel-mcp",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 63,
      "appName": "Netlify",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "docs.netlify.com/api",
      "whatItDoes": "Cloud platform for deploying, hosting, and managing web applications, sites, serverless functions, forms, DNS, and related infrastructure.",
      "authMethods": [
        "OAuth 2.0",
        "personal access token (Bearer)"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "An authenticated Netlify user can create a personal access token in Applications > Personal access tokens; public integrations require registering an OAuth application and user authorization.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST API at api.netlify.com/api/v1 with documented management for sites, deploys, forms, snippets, DNS, teams, and more, plus an official OpenAPI reference.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Create a Netlify PAT for the integration and validate required site/team scopes, or implement OAuth 2.0 for a multi-user public integration.",
      "confidence": "high",
      "uncertainties": "Exact permissions available to PATs and any plan-specific limits for particular API operations may vary; validate the target team's SSO and plan constraints during integration testing.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Netlify documents OAuth2 authentication, Bearer PATs created from Applications > Personal access tokens, and an API rooted at https://api.netlify.com/api/v1. Its official docs also publish remote and local Netlify MCP servers, including the remote endpoint netlify-mcp.netlify.app/mcp.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.netlify.com/api-and-cli-guides/api-guides/get-started-with-api/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.netlify.com/api-and-cli-guides/api-guides/get-started-with-api/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://open-api.netlify.com/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.netlify.com/build/build-with-ai/agent-setup-guides/agent-setup-overview/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0",
            "personal access token (Bearer)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0",
            "personal access token (Bearer)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 64,
      "appName": "Cloudflare",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "developers.cloudflare.com/api",
      "whatItDoes": "Cloudflare provides infrastructure, security, performance, developer, storage, analytics, and networking services managed through APIs.",
      "authMethods": [
        "API token",
        "Account API token",
        "Global API key (legacy)"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create user or account API tokens in the Cloudflare dashboard; Global API keys require a verified account email, with no general vendor approval gate documented.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "Official REST API reference spans 2,500+ endpoints across DNS, Workers, R2, Zero Trust, and other Cloudflare products.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Create a least-privilege Cloudflare user or account API token and connect to the official Cloudflare API MCP server.",
      "confidence": "high",
      "uncertainties": "Some individual Cloudflare products and API endpoints may require a paid subscription or specific account entitlements.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Cloudflare officially documents user and account API tokens using bearer authentication, plus a legacy Global API key. Its API reference covers 2,500+ endpoints, and Cloudflare documents a managed Cloudflare API MCP server at mcp.cloudflare.com with OAuth or API-token authorization.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.cloudflare.com/fundamentals/api/get-started/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.cloudflare.com/fundamentals/api/get-started/create-token/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.cloudflare.com/api/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.cloudflare.com/agents/model-context-protocol/cloudflare/servers-for-cloudflare/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API token (Bearer)",
            "Global API key (legacy)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "API token (Bearer)",
            "Global API key (legacy)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": false,
          "mcp": true,
          "verdict": true
        },
        "verifierNote": "Cloudflare documents self-serve user and account tokens; account-token creation requires Super Administrator permission, while its official API MCP server covers the entire API via OAuth or bearer tokens.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 65,
      "appName": "Supabase",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "supabase.com/docs",
      "whatItDoes": "Backend platform providing managed Postgres databases, auto-generated REST APIs, authentication, storage, and edge functions.",
      "authMethods": [
        "Bearer personal access token",
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a Supabase account and project on the self-serve platform, then generate a personal access token or authorize an OAuth integration; no vendor review is documented.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "Management API for organizations/projects plus auto-generated PostgREST data APIs, authentication, storage, and Edge Functions.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Implement against the Management API using a least-privilege PAT or OAuth scopes, and optionally add the official hosted MCP server with project and read-only scoping.",
      "confidence": "high",
      "uncertainties": "The exact free-plan quotas and any account-specific organization permissions can change; confirm them during implementation.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Supabase documents Bearer authentication using personal access tokens or OAuth2 for its Management API. Its Data REST API is auto-generated from each database schema, and its official hosted MCP server is available at mcp.supabase.com/mcp with OAuth login and project/read-only scoping.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://supabase.com/docs/reference/api/introduction",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://supabase.com/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://supabase.com/docs/guides/api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://supabase.com/docs/guides/ai-tools/mcp",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer personal access token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer personal access token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 66,
      "appName": "Neo4j",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "neo4j.com/docs/api",
      "whatItDoes": "Graph database platform for storing, querying, analyzing, and managing connected data.",
      "authMethods": [
        "Basic authentication",
        "Bearer authentication",
        "OAuth 2.0 client credentials"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "Self-hosted access requires a running database and valid user credentials; Aura API credentials are created in the console, but Free and Professional users need billing information or marketplace membership.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "HTTP Query/REST APIs support graph queries and transactions, while the Aura API provisions and manages instances, projects, snapshots, keys, and GDS sessions.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Deployment-specific credentials and Aura API credential eligibility",
      "recommendedNextStep": "Build against the documented HTTP/Query API and official Neo4j MCP, then validate credentials and APOC availability for the target deployment.",
      "confidence": "high",
      "uncertainties": "Credential availability and supported capabilities vary by Neo4j deployment, edition, and Aura tier.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Neo4j documents Basic and Bearer authorization for its HTTP API. Aura API authentication uses OAuth 2.0 with console-created client ID/secret credentials, while Free and Professional users need billing information or marketplace membership. Neo4j publishes an official MCP server and hosted MCP for Aura.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://neo4j.com/docs/http-api/current/authentication-authorization/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://neo4j.com/docs/aura/platform/api/authentication/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://neo4j.com/docs/aura/platform/api/specification/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://neo4j.com/docs/mcp/current/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Basic authentication",
            "Bearer authentication",
            "OAuth 2.0 client credentials"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Basic authentication",
            "Bearer authentication",
            "OAuth 2.0 client credentials"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 67,
      "appName": "Snowflake",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "docs.snowflake.com",
      "whatItDoes": "Cloud data platform for storing, querying, managing, and building applications on structured and unstructured data.",
      "authMethods": [
        "OAuth",
        "key-pair JWT",
        "programmatic access token",
        "workload identity federation"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "A 30-day trial with $400 in credits is available through Snowflake signup; API use still requires a Snowflake account, user/role privileges, and configured authentication.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "SQL API, REST APIs, Python API, drivers/connectors, and APIs for Snowflake resource management and data operations are officially documented.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Snowflake account configuration and role/privilege grants",
      "recommendedNextStep": "Provision or obtain a Snowflake trial/account, create a least-privilege service user, and validate SQL or REST API calls before implementing the connector.",
      "confidence": "high",
      "uncertainties": "Trial eligibility, feature availability, and MCP access can vary by account edition, region, and preview status.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Snowflake officially documents OAuth, key-pair JWT, programmatic access tokens, and workload identity federation for REST APIs. Its SQL API supports OAuth or key-pair authentication. Snowflake offers a self-serve 30-day trial, while managed MCP requires an account, authentication, and appropriate object privileges.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.snowflake.com/en/developer-guide/snowflake-rest-api/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://signup.snowflake.com/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.snowflake.com/en/api-reference",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents-mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth",
            "key-pair JWT",
            "programmatic access token",
            "workload identity federation"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth",
            "key-pair JWT",
            "programmatic access token",
            "workload identity federation"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 68,
      "appName": "MongoDB Atlas",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "mongodb.com/docs/atlas/api",
      "whatItDoes": "Cloud database platform with administration APIs for managing Atlas organizations, projects, clusters, users, networking, and related resources.",
      "authMethods": [
        "OAuth 2.0 service account access tokens",
        "HTTP Digest Authentication API keys"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "An Atlas account and organization are required; an Organization Owner creates service accounts or API keys, and a Project Owner grants API-key project access.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "Versioned REST Administration API with JSON resources and broad organization, project, cluster, database-user, networking, backup, and operational management endpoints.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Organization-owner or project-owner access and possible API IP allowlisting",
      "recommendedNextStep": "Create a least-privilege Atlas service account, grant project access, configure the required API access list, and validate representative endpoints and the managed MCP flow.",
      "confidence": "high",
      "uncertainties": "The exact permissions and IP allowlisting requirements depend on the target organization, project, and selected Atlas roles.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "MongoDB documents OAuth 2.0 service-account tokens and legacy HTTP Digest API keys for the Atlas Administration API. Setup requires an Atlas account and organization; owners create credentials and assign project roles. MongoDB also documents its official Atlas Managed MCP Server with OAuth or CLI-based setup.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://www.mongodb.com/docs/atlas/api/api-authentication/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.mongodb.com/docs/atlas/configure-api-access/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://www.mongodb.com/docs/atlas/api/atlas-admin-api-ref/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.mongodb.com/docs/mcp-server/get-started/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 service account access tokens",
            "HTTP Digest Authentication API keys"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 service account access tokens",
            "HTTP Digest Authentication API keys"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 69,
      "appName": "Datadog",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "docs.datadoghq.com/api",
      "whatItDoes": "Provides cloud observability for metrics, logs, traces, monitors, incidents, dashboards, and related operational data.",
      "authMethods": [
        "API key",
        "Application key"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "An organization user can create API and application keys in Datadog, but application-key creation and scopes require the relevant user or organization permissions.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Official HTTP REST API with broad v1/v2 coverage across metrics, logs, monitors, dashboards, incidents, APM, security, infrastructure, and account management.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Organization permissions to create and scope application keys",
      "recommendedNextStep": "Obtain an approved Datadog organization account and least-privilege API/application keys, then validate regional site and MCP tool permissions.",
      "confidence": "high",
      "uncertainties": "Datadog site, plan entitlements, and exact resource permissions may affect which API endpoints and MCP toolsets are usable.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Datadog documents API keys for authenticated requests and application keys for read access, with both supplied in DD-API-KEY and DD-APPLICATION-KEY headers. Its official MCP Server supports observability tools through remote MCP and OAuth, but site support and resource permissions vary.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.datadoghq.com/api/latest/authentication/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.datadoghq.com/account_management/api-app-keys/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.datadoghq.com/api/latest/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.datadoghq.com/mcp_server/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key",
            "Application key"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "API key",
            "Application key"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 70,
      "appName": "Sentry",
      "category": "Developer, Infra and Data Platforms",
      "startingHint": "docs.sentry.io/api",
      "whatItDoes": "Error monitoring and observability platform for tracking issues, performance, traces, releases, and related project data.",
      "authMethods": [
        "Bearer auth tokens",
        "OAuth 2.0 authorization code",
        "OAuth 2.0 device authorization"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "A Sentry user can create personal or organization tokens in Sentry; OAuth apps use registered client credentials and user authorization, with no documented app-review gate.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Public v0 web API covers account and organization resources, projects, teams, issue/event data, performance data, and data export/management.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "User or organization membership and required API scopes",
      "recommendedNextStep": "Use Sentry's official MCP endpoint with OAuth, or implement the documented Bearer-token/OAuth flow and validate required scopes against each endpoint.",
      "confidence": "high",
      "uncertainties": "The exact permissions available depend on the connected user's organization membership and token scopes; endpoint availability can vary by Sentry region and deployment.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Sentry documents Bearer auth tokens, personal and organization tokens, OAuth authorization-code and device flows. Its token tutorial requires a Sentry account and organization Manager/Admin role for internal-integration tokens, while personal tokens are user-created. Sentry publishes mcp.sentry.dev and its getsentry/sentry-mcp repository.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.sentry.io/api/auth/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.sentry.io/api/guides/create-auth-token/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.sentry.io/api/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://mcp.sentry.dev/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer auth tokens",
            "OAuth 2.0 authorization code",
            "OAuth 2.0 device authorization"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer auth tokens",
            "OAuth 2.0 authorization code",
            "OAuth 2.0 device authorization"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 71,
      "appName": "Notion",
      "category": "Productivity and Project Management",
      "startingHint": "developers.notion.com",
      "whatItDoes": "Workspace platform for creating, organizing, searching, and collaborating on documents, databases, projects, and knowledge.",
      "authMethods": [
        "OAuth 2.0",
        "bearer token",
        "personal access token (PAT)",
        "static API token"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "Create a PAT from the Developer portal with a Notion account, or create an internal connection; public OAuth connections are usable before optional Marketplace listing review.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST/JSON API covers pages, databases/data sources, blocks, views, comments, users, files, search, webhooks, and related workspace content.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Interactive OAuth is required for official MCP; workspace permissions and plan limits still apply.",
      "recommendedNextStep": "Build against Notion’s hosted MCP endpoint with OAuth, and retain REST/PAT support for non-interactive automation.",
      "confidence": "high",
      "uncertainties": "Marketplace security review is required for public connections listed in the Marketplace, but not for creating and using a public connection without listing it.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Notion documents internal connections and PATs as static bearer-token paths and public connections as OAuth 2.0. Its API covers pages, databases, users, comments, files, search, views, and webhooks. Notion also operates the hosted MCP server at https://mcp.notion.com/mcp, which uses OAuth and supports reading and updating accessible workspace content.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.notion.com/guides/get-started/authorization",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.notion.com/guides/mcp/get-started-with-mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.notion.com/guides/get-started/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.notion.com/guides/mcp/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0,bearer token,personal access token (PAT),static API token",
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": false,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Notion's API supports OAuth, bearer tokens, PATs, and internal static tokens. Official hosted MCP is available, but the documented Claude Desktop access requires Pro/Max/Team/Enterprise, so the strict classification is self_serve_paid, not free.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://developers.notion.com/guides/get-started/authorization",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://developers.notion.com/guides/mcp/get-started-with-mcp",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://developers.notion.com/guides/get-started/overview",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://developers.notion.com/guides/mcp/overview",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 72,
      "appName": "Airtable",
      "category": "Productivity and Project Management",
      "startingHint": "airtable.com/developers",
      "whatItDoes": "A low-code platform for building collaborative databases, workflows, and custom business applications.",
      "authMethods": [
        "OAuth 2.0",
        "bearer/PAT"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Developers can create PATs or register OAuth integrations in Airtable’s Developer Hub; the API and MCP server are available on all plans, subject to user and organization permissions.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "REST/JSON Web API supports record CRUD, filtering, pagination, base and table schema, base creation, webhooks, and standard HTTP authentication.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Implement OAuth 2.0 for multi-user access, retain PAT support for developer-managed connections, and validate Airtable’s documented rate limits.",
      "confidence": "high",
      "uncertainties": "OAuth client registration and enterprise organization allowlisting may require owner, creator, or administrator permissions in some workspaces.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Airtable documents bearer-token authentication with Personal Access Tokens and OAuth access tokens, recommends OAuth for third-party integrations, and states PATs are available on all plan types. Its official MCP server is available on all plans, supports OAuth and PATs, and exposes base, schema, record, interface, and automation tools. API limits remain material: 5 requests/second per base; Free and Team plans also have monthly caps.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://airtable.com/developers/web/api/authentication",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://support.airtable.com/articles/9934989703-creating-personal-access-tokens",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://airtable.com/developers/web/api/introduction",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://airtable.com/developers/agents/mcp/getting-started",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0, bearer/PAT",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "OAuth 2.0,PAT (Bearer)",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Confirmed: Airtable supports OAuth for third-party integrations and PAT bearer tokens for users; Web API and official MCP are available on all plans, including Free. MCP may still require enterprise allowlisting.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://support.airtable.com/articles/9934989703-creating-personal-access-tokens",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://support.airtable.com/articles/2277136852-airtable-plans-overview",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://airtable.com/developers/web/api/introduction",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://support.airtable.com/articles/9897799762-using-the-airtable-mcp-server",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 73,
      "appName": "Linear",
      "category": "Productivity and Project Management",
      "startingHint": "developers.linear.app",
      "whatItDoes": "Project management platform for planning, tracking, and collaborating on software and product development.",
      "authMethods": [
        "OAuth 2.0",
        "personal API keys",
        "OAuth 2.0 client credentials"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Free workspaces include API and MCP access; admins and permitted members can create personal API keys, while OAuth apps are created in Linear settings.",
      "apiProtocols": [
        "GraphQL",
        "Webhooks",
        "SDK"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Public GraphQL API with introspectable schema, read/write queries and mutations across Linear entities, plus webhooks and a TypeScript SDK.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Workspace admin permission may restrict member API-key creation",
      "recommendedNextStep": "Implement against Linear’s GraphQL API or official remote MCP endpoint, using OAuth for multi-user apps and API keys for permitted personal scripts.",
      "confidence": "high",
      "uncertainties": "Personal API-key creation can be restricted for workspace members by an administrator; OAuth application ownership and workspace-specific permissions should be confirmed during implementation.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Linear officially documents OAuth 2.0 and personal API keys for its GraphQL API, including client-credentials tokens for server-to-server apps. Its pricing page lists API and MCP access under the Free plan, and Linear documents its centrally hosted remote MCP server at mcp.linear.app.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://linear.app/developers/oauth-2-0-authentication",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://linear.app/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://linear.app/developers/graphql",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://linear.app/docs/mcp",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0",
            "personal API keys",
            "OAuth 2.0 client credentials"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0",
            "personal API keys",
            "OAuth 2.0 client credentials"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 74,
      "appName": "Jira",
      "category": "Productivity and Project Management",
      "startingHint": "developer.atlassian.com",
      "whatItDoes": "Project and issue management platform for planning, tracking, and delivering software and business work.",
      "authMethods": [
        "API token via HTTP Basic Auth",
        "OAuth 2.0 authorization code grant (3LO)",
        "OAuth 2.1 via Atlassian Rovo MCP",
        "JWT for Connect apps",
        "Forge app authentication"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Users can create Atlassian API tokens or authorize OAuth 2.1/3LO themselves, but Jira site access, project permissions, and MCP client allowlisting may require an administrator.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "Jira Cloud REST API v3 covers issues, projects, users, workflows, transitions, comments, attachments, JQL, and extensive metadata.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Jira permissions and organization-level MCP client controls",
      "recommendedNextStep": "Prototype against a Jira Cloud site using OAuth 2.1 Rovo MCP or a scoped API token, then validate required project permissions and admin allowlisting.",
      "confidence": "high",
      "uncertainties": "Exact Jira plan requirements and whether a given organization permits Rovo MCP or API-token use depend on the tenant's administrator policies.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Atlassian documents Jira Cloud REST API v3 and identifies OAuth 2.0 3LO, Connect JWT, Forge scopes, and Basic auth with API tokens. Its official Rovo MCP Server supports Jira read/create/update actions and uses OAuth 2.1 while respecting existing permissions.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.atlassian.com/cloud/jira/platform/rest/v3/intro/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://support.atlassian.com/atlassian-account/docs/manage-api-tokens-for-your-atlassian-account/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.atlassian.com/cloud/jira/platform/rest/v3/intro/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.atlassian.com/cloud/rovo-mcp/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API token with Basic auth",
            "OAuth 2.0 authorization code (3LO)",
            "Connect JWT",
            "Forge app scopes"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "API token with Basic auth",
            "OAuth 2.0 authorization code (3LO)",
            "Connect JWT",
            "Forge app scopes"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": false,
          "apiBreadth": false,
          "mcp": true,
          "verdict": false
        },
        "verifierNote": "Jira Cloud credentials are self-serve through an Atlassian account with Jira access; organization permissions and product entitlement still govern usable API scope.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 75,
      "appName": "Asana",
      "category": "Productivity and Project Management",
      "startingHint": "developers.asana.com",
      "whatItDoes": "Work management platform for organizing projects, tasks, teams, and workflows.",
      "authMethods": [
        "Personal access token (PAT)",
        "OAuth 2.0",
        "service account"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Users can generate PATs and create OAuth or MCP apps in Asana’s developer console, but workspace distribution and admin app-management policies can gate authorization.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "REST API with documented CRUD access to workspaces, users, teams, projects, tasks, portfolios, custom fields, attachments, webhooks, and related Work Graph resources.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Workspace distribution and possible admin app blocking",
      "recommendedNextStep": "Create the appropriate standard API or MCP app, configure distribution for the target workspace(s), and validate authorization under the customer’s admin app-management policy.",
      "confidence": "high",
      "uncertainties": "Exact API endpoint availability can vary with the authorizing user’s Asana permissions, workspace plan, and administrative controls.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Asana officially documents PAT, OAuth, and Enterprise service-account authentication. Its API is a broad REST interface, while its official MCP server is https://mcp.asana.com/v2/mcp and requires an Asana MCP app with OAuth; workspace distribution and admin app-management settings can prevent authorization.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.asana.com/docs/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.asana.com/docs/integrating-with-asanas-mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.asana.com/docs/quick-start",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.asana.com/docs/mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Personal access token (PAT)",
            "OAuth 2.0",
            "service account"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Personal access token (PAT)",
            "OAuth 2.0",
            "service account"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 76,
      "appName": "Monday.com",
      "category": "Productivity and Project Management",
      "startingHint": "developer.monday.com",
      "whatItDoes": "Work management platform for organizing projects, tasks, workflows, documents, and team collaboration.",
      "authMethods": [
        "Personal V2 API token",
        "OAuth 2.0/2.1 access token",
        "seamless SDK authentication",
        "short-lived token"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "A free, no-expiration developer account is available; users with API access can self-serve a personal token, while OAuth requires creating/configuring an app and user authorization.",
      "apiProtocols": [
        "GraphQL",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Versioned GraphQL platform API covers boards, items, columns, users, workspaces, docs, updates, webhooks, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Admin installation of the monday MCP marketplace app and account-scoped permissions",
      "recommendedNextStep": "Have a monday account admin install the official MCP app, complete OAuth 2.1 authorization, and validate required board/workspace scopes in a test account.",
      "confidence": "high",
      "uncertainties": "Exact availability of some API features and MCP tools can vary by API version, account permissions, and preview-schema status.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs describe personal V2 API tokens, OAuth, seamless SDK/short-lived-token flows, and a free no-expiration developer account. monday documents a hosted Platform MCP at https://mcp.monday.com/mcp using OAuth 2.1, with an admin required to install the marketplace app; MCP operations follow user permissions.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.monday.com/api-reference/docs/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developer.monday.com/api-reference/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.monday.com/api-reference/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.monday.com/api-reference/docs/build-on-monday-with-ai",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Personal V2 API token",
            "OAuth 2.0/2.1 access token",
            "seamless SDK authentication",
            "short-lived token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Personal V2 API token",
            "OAuth 2.0/2.1 access token",
            "seamless SDK authentication",
            "short-lived token"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 77,
      "appName": "ClickUp",
      "category": "Productivity and Project Management",
      "startingHint": "clickup.com/api",
      "whatItDoes": "Project management and productivity platform for managing tasks, documents, collaboration, time tracking, and workspaces.",
      "authMethods": [
        "Personal API token",
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Personal tokens are available from ClickUp Settings > Apps for eligible members; OAuth app creation requires Workspace owner or admin access, while limited view-only members cannot use the API.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "Public API v2 covers workspaces, spaces, folders, lists, tasks, comments, custom fields, time tracking, docs, chat, and related project-management resources.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Build against the Public API with OAuth for multi-user apps, or use a personal token for testing; use ClickUp’s official MCP endpoint when an MCP client is appropriate.",
      "confidence": "high",
      "uncertainties": "OAuth app creation is Workspace-admin gated, and MCP is documented as public beta with plan-dependent rate limits.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "ClickUp officially documents personal API tokens and OAuth 2.0 authorization-code flow. Personal tokens are generated in Settings > Apps, while OAuth apps require a Workspace owner/admin. ClickUp also publishes its own MCP server at https://mcp.clickup.com/mcp, available on all plans and authenticated only via OAuth.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.clickup.com/docs/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://help.clickup.com/hc/en-us/articles/6303422883095-Create-your-own-app-with-the-ClickUp-API",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.clickup.com/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.clickup.com/docs/connect-an-ai-assistant-to-clickups-mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Personal API token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Personal API token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 78,
      "appName": "Coda",
      "category": "Productivity and Project Management",
      "startingHint": "coda.io/developers",
      "whatItDoes": "A collaborative document and database workspace with APIs for reading, writing, and managing docs, pages, tables, rows, and related resources.",
      "authMethods": [
        "API token (Bearer)",
        "OAuth 2 with PKCE (MCP)"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Coda's official API is available to free and paid workspaces; users generate credentials from account settings, subject to workspace role, document permissions, and possible enterprise MCP controls.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST API covers folders, docs, permissions, publishing, pages, automations, tables, columns, rows, formulas, controls, account, and analytics.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Workspace/document permissions or enterprise admin restrictions",
      "recommendedNextStep": "Implement against the official REST API and official MCP endpoint, then validate the target workspace's permissions and MCP policy before production rollout.",
      "confidence": "high",
      "uncertainties": "The REST API documentation clearly supports API-token authentication, but the current source set does not establish OAuth2 as a general REST API authentication method outside MCP.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs describe a broad REST API and state API availability for free and paid workspaces. Current vendor guidance identifies OAuth2 with PKCE and personal access tokens for the official MCP, hosted at https://coda.io/apis/mcp and https://docs.superhuman.com/apis/mcp; enterprise admins can restrict either method.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://coda.io/developers",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://coda.io/developers",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://coda.io/developers",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://help.superhuman.com/hc/en-us/articles/46210118248205-Security-recommendations-for-the-Docs-MCP",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API token (Bearer)",
            "OAuth 2 with PKCE (MCP)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "API token (Bearer)",
            "OAuth 2 with PKCE (MCP)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 79,
      "appName": "Smartsheet",
      "category": "Productivity and Project Management",
      "startingHint": "smartsheet.com/developers",
      "whatItDoes": "Work management platform for organizing projects, sheets, reports, dashboards, resources, and collaborative workflows.",
      "authMethods": [
        "Bearer access token",
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "API use requires a Business, Enterprise, or Advanced Work Management plan; paid users can generate API tokens in Smartsheet, while OAuth requires Developer Tools registration and app setup.",
      "apiProtocols": [
        "REST",
        "Webhooks",
        "SDK"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "REST API and SDKs cover sheets, rows, cells, folders, workspaces, reports, dashboards, users, contacts, webhooks, attachments, and related resources.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Paid Smartsheet plan required",
      "recommendedNextStep": "Provision a qualifying Smartsheet account, generate a regional API token or register an OAuth app, and validate required scopes against the target workflow.",
      "confidence": "high",
      "uncertainties": "OAuth Developer Tools activation is described as subject to Smartsheet acceptance, and exact feature availability may vary by plan and region.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Smartsheet officially documents Bearer access tokens and OAuth 2.0, with tokens generated in the UI. Its API requires Business, Enterprise, or Advanced Work Management. Smartsheet also documents a native MCP server at regional mcp.smartsheet.com endpoints, supporting API-token or supported-client OAuth access.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.smartsheet.com/api/smartsheet/guides/basics/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.smartsheet.com/api/smartsheet/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.smartsheet.com/api/smartsheet/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.smartsheet.com/ai-mcp/smartsheet/install-the-smartsheet-mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer access token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer access token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 80,
      "appName": "Harvest",
      "category": "Productivity and Project Management",
      "startingHint": "harvestapp.com, help.getharvest.com/api-v2",
      "whatItDoes": "Time tracking, project management, invoicing, expenses, estimates, reports, and team administration for businesses.",
      "authMethods": [
        "Personal Access Token",
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "All Harvest accounts, including free and trial accounts, include API access; users create personal access tokens or OAuth apps from Harvest ID Developers.",
      "apiProtocols": [
        "REST",
        "CLI"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "REST API v2 covers clients, invoices, estimates, expenses, tasks, time entries, projects, roles, users, and reports.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Use Harvest OAuth 2.0 for multi-user integrations or a personal access token for single-account scripts, and connect the official MCP endpoint when agent access is needed.",
      "confidence": "high",
      "uncertainties": "The exact feature permissions available depend on the connected Harvest user's account role and permissions.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Harvest documents Personal Access Tokens and OAuth 2.0 for API authentication. Its Help Center states API access is included for all accounts, including free and trial accounts. Harvest separately documents its official MCP connection at https://api.harvestapp.com/mcp.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://help.getharvest.com/api-v2/authentication-api/authentication/authentication/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://support.getharvest.com/hc/en-us/articles/360048180732-The-Harvest-API",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://help.getharvest.com/api-v2/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://support.getharvest.com/hc/en-us/articles/46293697226381-Harvest-MCP",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Personal Access Token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Personal Access Token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 81,
      "appName": "Stripe",
      "category": "Finance and Fintech",
      "startingHint": "stripe.com/docs/api",
      "whatItDoes": "Stripe provides payment processing and financial infrastructure APIs for payments, billing, payouts, marketplaces, fraud, and related commerce workflows.",
      "authMethods": [
        "API key",
        "Basic",
        "bearer",
        "OAuth 2.0"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "Create a Stripe account and obtain sandbox/test API keys from the Dashboard without sales contact; live payment processing uses transaction-based pricing and account verification.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST/JSON API covering payments, Checkout, billing, subscriptions, invoicing, customers, Connect, payouts, fraud, issuing, Treasury, reporting, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Build against Stripe’s REST API using restricted API keys and support OAuth 2.0 where users connect their own Stripe accounts.",
      "confidence": "high",
      "uncertainties": "Live-mode availability and some product capabilities depend on country, verification, account permissions, and enabled Stripe products.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Stripe documents API-key authentication over HTTP Basic Auth, with bearer-token support and OAuth 2.0 for apps. Its API is REST-based with JSON responses and sandbox support. Standard pricing has no setup or monthly fees, while Stripe publishes an official remote MCP server at https://mcp.stripe.com using OAuth or restricted API keys.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.stripe.com/api/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://stripe.com/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.stripe.com/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.stripe.com/mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "API key, Basic, bearer/PAT, OAuth 2.0",
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "verified": {
          "authMethods": "API key,Basic,bearer,OAuth 2.0",
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": true,
          "selfServe": false,
          "apiBreadth": true,
          "mcp": true,
          "verdict": false
        },
        "correctionSummary": "Stripe officially supports API keys via HTTP Basic or bearer auth, plus OAuth 2.0. Standard signup is self-serve, but MCP access must be enabled by an administrator; therefore strict access is admin_approval and build_now is too permissive.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://docs.stripe.com/api/authentication",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://stripe.com/pricing",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://docs.stripe.com/api",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://docs.stripe.com/mcp",
            "sourceType": "official_docs",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 82,
      "appName": "Plaid",
      "category": "Finance and Fintech",
      "startingHint": "plaid.com/docs",
      "whatItDoes": "Financial data connectivity and fintech APIs for bank accounts, transactions, identity, payments, fraud, and related financial services.",
      "authMethods": [
        "client_id and secret",
        "OAuth 2.0 client credentials for Dashboard MCP"
      ],
      "selfServeStatus": "self_serve_trial",
      "selfServeSummary": "Create a Dashboard account to obtain Sandbox client_id and secret; US/Canada teams meeting current eligibility can use an auto-approved Trial plan for up to 10 Production Items, while full Production access requires review.",
      "apiProtocols": [
        "Webhooks",
        "CLI"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; JSON-over-HTTPS API with extensive product endpoints, webhooks, client libraries, Sandbox, and OpenAPI definitions across connectivity, payments, identity, fraud, credit, and financial insights.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Full Production approval and product access review",
      "recommendedNextStep": "Create a Plaid Dashboard account, build against Sandbox, then request the required Production products and verify MCP access after Production approval.",
      "confidence": "high",
      "uncertainties": "Trial eligibility is region- and signup-date-dependent, and individual product or institution availability can require additional approval.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Plaid documents client_id and secret authentication, Dashboard-issued credentials, Sandbox access, and a broad JSON API. Full Production approval requires company and use-case information; the official Dashboard MCP server requires Production approval with at least one Plaid product and uses OAuth client credentials with the mcp:dashboard scope.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://plaid.com/docs/api/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://support.plaid.com/hc/en-us/articles/16110110883479-How-are-Sandbox-Production-Trial-plan-and-Limited-Production-different",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://plaid.com/docs/api/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://plaid.com/docs/resources/mcp/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "client_id and secret",
            "OAuth 2.0 client credentials for Dashboard MCP"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "client_id and secret",
            "OAuth 2.0 client credentials for Dashboard MCP"
          ],
          "selfServeStatus": "self_serve_trial",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 83,
      "appName": "Binance",
      "category": "Finance and Fintech",
      "startingHint": "binance-docs.github.io",
      "whatItDoes": "Cryptocurrency exchange APIs for market data, account operations, trading, streaming, and related Binance product services.",
      "authMethods": [
        "HMAC request signing",
        "RSA",
        "Ed25519",
        "session-based authentication"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Users can create API keys themselves after enabling 2FA, completing identity verification, and depositing any amount into the Spot Wallet; IP restrictions govern sensitive permissions.",
      "apiProtocols": [
        "REST",
        "SDK"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Official REST, WebSocket APIs and streams, FIX, SBE, SDKs, and product APIs spanning spot, futures, margin, wallet, options, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "KYC, Spot Wallet deposit, and permission/IP security gates",
      "recommendedNextStep": "Create a least-privilege Binance API key in an eligible account, validate required endpoints on testnet or demo where supported, and review regional and financial-risk controls before production.",
      "confidence": "high",
      "uncertainties": "Exact endpoint availability, permissions, and testnet/demo support vary by Binance product and user region.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Binance documents HMAC, RSA, and Ed25519 authentication and lists REST, WebSocket, FIX, and SBE interfaces. Its key-creation FAQ requires 2FA, identity verification, and a Spot Wallet deposit; its official Skills Hub states that skills follow MCP and are installable from Binance's GitHub repository.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.binance.com/en/docs/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.binance.com/en/support/faq/detail/360002502072",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.binance.com/en/docs/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.binance.com/en/docs/sdks-tools/integrations/skills-hub",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "HMAC request signing",
            "RSA",
            "Ed25519",
            "session-based authentication"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "HMAC request signing",
            "RSA",
            "Ed25519",
            "session-based authentication"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 84,
      "appName": "Paygent Connect",
      "category": "Finance and Fintech",
      "startingHint": "Paygent, NMI-powered",
      "whatItDoes": "Paygent provides Japanese merchants with integrated online payment processing, settlement management, and multiple payment methods through API and hosted connections.",
      "authMethods": [
        "unknown"
      ],
      "selfServeStatus": "contact_sales",
      "selfServeSummary": "Public API specifications are gated behind a request form, and module integrations require a Paygent contract plus financial-institution screening.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "moderate",
      "apiSurfaceSummary": "Payment APIs and modules cover cards, convenience stores, bank and carrier payments, wallets, tokenization, settlement operations, and merchant management.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "blocked_by_access",
      "buildabilityVerdict": "outreach_required",
      "primaryBlocker": "API credentials and specifications are not publicly self-serve",
      "recommendedNextStep": "Contact Paygent to obtain the API specification, authentication details, sandbox access, and integration agreement.",
      "confidence": "medium",
      "uncertainties": "The assignment labels Paygent as NMI-powered, but official Paygent materials identify Paygent as an NTT DATA and MUFG NICOS-backed Japanese provider; the relationship to NMI is not publicly established.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Paygent’s official site describes a module/API connection and lists broad payment coverage and settlement operations. Its contact page says the merchant-portal and API specifications are downloaded via request forms; the module page states that financial institutions conduct screening and that a Paygent contract is required. No official MCP source was found.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://lp.paygent.co.jp/payout/contact",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.paygent.co.jp/payment_service/connect/module_type/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://www.paygent.co.jp/payment_service/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "sampled_pass",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "medium",
        "pass0": {
          "authMethods": "unknown",
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "moderate",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "outreach_required"
        },
        "verified": {
          "authMethods": "unknown",
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "moderate",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "outreach_required"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": true
        },
        "correctionSummary": "Official Paygent pages describe contract-based module integration, multiple payment methods, and broad transaction/admin operations, but expose no public auth specification or MCP evidence. Prior classifications remain defensible.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://www.paygent.co.jp/payment_service/connect/module_type/",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://www.paygent.co.jp/contact/",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://www.paygent.co.jp/payment_service/connect/module_type/",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "unknown",
            "sourceType": "unverified",
            "status": "unknown"
          }
        ]
      }
    },
    {
      "id": 85,
      "appName": "iPayX",
      "category": "Finance and Fintech",
      "startingHint": "ipayx.ai/docs",
      "whatItDoes": "Provides forensic FX audits that compare bank or card-network exchange rates with live mid-market benchmarks.",
      "authMethods": [
        "Bearer token"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "Public MCP tools are available without signup but rate-limited; production REST API credentials are generated from the dashboard under paid API plans starting at $99/month.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "REST API v1 supports single and batch FX audits, live rates, signed HMAC-SHA256 webhooks, and OpenAPI documentation.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Paid API plan required for production REST credentials",
      "recommendedNextStep": "Create an iPayX account, obtain a paid API key, and validate the documented audit endpoint and official MCP server in a test integration.",
      "confidence": "high",
      "uncertainties": "The documentation presents multiple backend endpoint URLs and inconsistent free-tier limits, so endpoint behavior and exact quotas should be validated during integration.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs specify Bearer authentication with ipx_live_ keys, dashboard key generation, three REST API operations plus signed webhooks, and an official MCP endpoint at mcp.ipayx.ai/mcp with public rate-limited tools and paid full-report access.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://www.ipayx.ai/docs/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://www.ipayx.ai/developers",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://www.ipayx.ai/docs/api",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://www.ipayx.ai/docs/mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer token"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer token"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": false,
          "mcp": true,
          "verdict": true
        },
        "verifierNote": "Official docs expose Bearer-key REST and MCP access; API pricing is paid, while a limited free MCP tier exists, so production API use is classified as self-serve paid.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 86,
      "appName": "QuickBooks",
      "category": "Finance and Fintech",
      "startingHint": "developer.intuit.com",
      "whatItDoes": "Cloud accounting software with APIs for financial records, invoicing, payments, customers, vendors, and reporting.",
      "authMethods": [
        "OAuth 2.0"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "Developers can create an Intuit app and obtain sandbox credentials self-serve, but production access requires completing Intuit's app details and App Assessment Questionnaire.",
      "apiProtocols": [
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; QuickBooks Online Accounting API covers core accounting entities, reports, payments, batch operations, webhooks, and queryable company data.",
      "mcpStatus": "mcp_possible_via_api",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Intuit production app assessment and approval",
      "recommendedNextStep": "Create an Intuit developer app, validate the integration in a sandbox with OAuth 2.0, then submit the production App Assessment Questionnaire.",
      "confidence": "medium",
      "uncertainties": "The official developer site was intermittently unreachable during verification, and no official Intuit MCP publication was found.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Intuit documents OAuth 2.0 for QuickBooks Online integrations. Its developer support states that first-time production keys require app details and the App Assessment Questionnaire; official API documentation covers the Accounting API entities and related operations. No official Intuit QuickBooks MCP source was identified.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.intuit.com/app/developer/qbo/docs/develop/authentication-and-authorization/oauth-2.0",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://help.developer.intuit.com/s/question/0D54R00009du2OESAY/how-do-i-get-my-production-keys-for-the-first-time",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.intuit.com/app/developer/qbo/docs/api/accounting/all-entities",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "mcp_possible_via_api",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 87,
      "appName": "Xero",
      "category": "Finance and Fintech",
      "startingHint": "developer.xero.com",
      "whatItDoes": "Cloud accounting platform providing APIs for financial data, transactions, payroll, files, projects, and related workflows.",
      "authMethods": [
        "OAuth 2.0 authorization code",
        "OAuth 2.0 PKCE",
        "OAuth 2.0 client credentials (Custom Connections)"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create an OAuth 2.0 app after signing in, using a free developer/demo company; standard apps start self-serve, while Custom Connections incur a per-organisation fee and higher scale requires paid/certified tiers.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Accounting, Assets, Bank Feeds, Files, Finance, Payroll, Practice Manager, Projects, App Store, and eInvoicing APIs are documented.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Starter tier limited to 5 connections; higher scale and some premium endpoints require paid tiers, certification, or security/use-case approval",
      "recommendedNextStep": "Create a Starter OAuth app and validate the required scopes and MCP workflows against the Xero demo company, then plan certification and tier migration if scaling beyond five connections.",
      "confidence": "high",
      "uncertainties": "The exact MCP tool coverage and any endpoint-specific entitlement can change; confirm against the linked Xero MCP repository and current developer-tier terms before production launch.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Xero documents authorization-code, PKCE, and client-credentials Custom Connections; its getting-started guide supports a free developer account and demo company. Current pricing sets Starter at no charge with five connections, while Xero’s AI toolkit links its open-source MCP server.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.xero.com/documentation/guides/oauth2/overview/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developer.xero.com/documentation/getting-started-guide/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.xero.com/documentation/api/accounting/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.xero.com/ai",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 authorization code",
            "OAuth 2.0 PKCE",
            "OAuth 2.0 client credentials (Custom Connections)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 authorization code",
            "OAuth 2.0 PKCE",
            "OAuth 2.0 client credentials (Custom Connections)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 88,
      "appName": "Brex",
      "category": "Finance and Fintech",
      "startingHint": "developer.brex.com",
      "whatItDoes": "Unified spend platform for corporate cards, expenses, reimbursements, travel, bill pay, banking, and finance workflows.",
      "authMethods": [
        "Bearer token",
        "OAuth 2.0"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "An account or card admin must accept the Developer API agreement; customer admins create scoped user tokens, while partner OAuth client credentials require Brex developer support.",
      "apiProtocols": [
        "REST",
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "REST/OpenAPI APIs cover accounting, budgets, expenses, fields, onboarding, payments, team, transactions, travel, and webhooks.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Admin agreement acceptance and MCP beta enablement",
      "recommendedNextStep": "Have a Brex account or card admin accept the agreement, enable the MCP beta, and provision least-privilege scoped credentials before testing.",
      "confidence": "high",
      "uncertainties": "MCP beta availability and exact tool permissions may vary by Brex account capabilities.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Brex officially documents dashboard-generated scoped user tokens sent as Bearer tokens, partner OAuth 2.0 flows, and a hosted MCP server at https://api.brex.com/mcp. API use requires the Developer API agreement; MCP is beta and requires admin enablement.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developer.brex.com/guides/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developer.brex.com/guides/quickstart",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developer.brex.com/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developer.brex.com/docs/mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Bearer token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 89,
      "appName": "Ramp",
      "category": "Finance and Fintech",
      "startingHint": "docs.ramp.com",
      "whatItDoes": "Corporate spend management platform with cards, bill pay, reimbursements, procurement, accounting, and financial operations APIs.",
      "authMethods": [
        "OAuth 2.0 client credentials",
        "OAuth 2.0 authorization code",
        "HTTP Basic Auth for token endpoint",
        "Bearer access token"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "A Ramp customer admin can create a Developer app, configure grant types and scopes, and copy credentials; sandbox access requires account-manager approval and third-party production access follows an application process.",
      "apiProtocols": [
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; OAuth-scoped APIs cover transactions, cards, users, bills, reimbursements, accounting, procurement, vendors, virtual cards, webhooks, and more.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Ramp customer/admin access and production or sandbox approval",
      "recommendedNextStep": "Secure a Ramp customer admin sponsor, create a scoped Developer app, and request sandbox or production access before implementation.",
      "confidence": "high",
      "uncertainties": "Exact production approval criteria and availability may vary by Ramp account, region, product scope, and partner status.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Ramp documents OAuth 2.0 client-credentials and authorization-code grants, with Basic Auth used for token requests and Bearer tokens for API calls. Admin access is required to create an app; sandbox access is not self-serve. Ramp publishes its own MCP servers at mcp.ramp.com, with OAuth and admin/business-owner permission controls for company-wide data.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.ramp.com/developer-api/v1/authorization",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://support.ramp.com/accessing-the-developer-api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.ramp.com/developer-api/v1/introduction",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.ramp.com/developer-api/v1/guides/ramp-mcp-remote",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "OAuth 2.0 client credentials",
            "OAuth 2.0 authorization code",
            "HTTP Basic Auth for token endpoint",
            "Bearer access token"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "OAuth 2.0 client credentials",
            "OAuth 2.0 authorization code",
            "HTTP Basic Auth for token endpoint",
            "Bearer access token"
          ],
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 90,
      "appName": "PitchBook",
      "category": "Finance and Fintech",
      "startingHint": "pitchbook.com, research API",
      "whatItDoes": "Provides private-market intelligence on companies, investors, funds, deals, people, and related market activity.",
      "authMethods": [
        "API key",
        "authentication token"
      ],
      "selfServeStatus": "contact_sales",
      "selfServeSummary": "API access requires a standalone contract; prospects must request access through PitchBook’s Direct Data team, while clients can request it in the platform.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "REST API with relational endpoints covering company, financing, deal, fund, and other private-market data.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Standalone commercial contract and subscriber-gated access",
      "recommendedNextStep": "Contact PitchBook Direct Data to confirm API or MCP entitlement, credentials, scopes, rate limits, and permitted integration use.",
      "confidence": "high",
      "uncertainties": "The official API help page does not publish endpoint-level schemas, rate limits, pricing, or credential issuance workflow details.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "PitchBook states that its API is a separate offering requiring a standalone contract, with access initiated through the Direct Data team or the client platform. It says the connection is established using an API key or authentication token. PitchBook also officially announced MCP integrations for subscribers.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://pitchbook.com/help/PitchBook-api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://pitchbook.com/help/PitchBook-api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://pitchbook.com/help/PitchBook-api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://pitchbook.com/media/press-releases/pitchbook-launches-new-generative-ai-experiences-with-the-introduction-of-pitchbook-navigator-and-upcoming-integration-with-openai",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "API key",
            "authentication token"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "API key",
            "authentication token"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 91,
      "appName": "NotebookLM",
      "category": "AI, Research and Media-native",
      "startingHint": "cloud.google.com/gemini, enterprise API hint",
      "whatItDoes": "Google’s source-grounded research notebook summarizes and answers questions over uploaded documents, web pages, videos, and other sources.",
      "authMethods": [
        "OAuth 2.0",
        "Google Cloud IAM"
      ],
      "selfServeStatus": "admin_approval",
      "selfServeSummary": "A Google Cloud project, billing, enabled Discovery Engine API, IAM roles, identity setup, and a NotebookLM Enterprise subscription/license are required.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "moderate",
      "apiSurfaceSummary": "Preview REST APIs create, retrieve, list, share, and delete notebooks; add, upload, retrieve, and delete sources; and generate audio overviews.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Google Cloud licensing, IAM, and Preview API constraints",
      "recommendedNextStep": "Proceed with the Composio connector using OAuth 2.0, but validate Preview endpoints, IAM roles, regional project handling, and licensed test tenants.",
      "confidence": "high",
      "uncertainties": "Google’s public docs do not show a native official NotebookLM MCP server; Composio’s page describes its own hosted MCP exposure, not Google-native MCP.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Google’s API examples use OAuth bearer access tokens from gcloud; Google Drive sources require gcloud authorization with Drive access. Official docs label notebook and source APIs Preview, while licensing requires a subscription, with a documented 14-day free-trial tier. Composio’s exact NotebookLM page exposes an MCP toolkit with 11 tools and OAuth2.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.cloud.google.com/gemini/enterprise/notebooklm-enterprise/docs/api-notebooks",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.cloud.google.com/gemini/enterprise/notebooklm-enterprise/docs/set-up-notebooklm",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.cloud.google.com/gemini/enterprise/notebooklm-enterprise/docs/api-notebooks",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://composio.dev/toolkits/notebook_lm",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "OAuth 2.0",
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "moderate",
          "mcpStatus": "unknown",
          "buildabilityVerdict": "build_with_review"
        },
        "verified": {
          "authMethods": "OAuth 2.0, Google Cloud IAM",
          "selfServeStatus": "admin_approval",
          "apiSurfaceBreadth": "moderate",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_with_review"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": false,
          "verdict": true
        },
        "correctionSummary": "Google documents a Gemini Notebook Enterprise REST API using Google auth tokens and IAM roles, but it is Preview, requires a billed Cloud project, API enablement, licenses, and admin setup. No official NotebookLM MCP was verified.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://docs.cloud.google.com/gemini/enterprise/notebooklm-enterprise/docs/api-notebooks",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://docs.cloud.google.com/gemini/enterprise/notebooklm-enterprise/docs/set-up-notebooklm",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://docs.cloud.google.com/gemini/enterprise/notebooklm-enterprise/docs/api-notebooks",
            "sourceType": "official_docs",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "unknown",
            "sourceType": "unverified",
            "status": "unknown"
          }
        ]
      }
    },
    {
      "id": 92,
      "appName": "Otter AI",
      "category": "AI, Research and Media-native",
      "startingHint": "help.otter.ai, MCP server hint",
      "whatItDoes": "AI meeting assistant that records, transcribes, summarizes, and provides searchable insights and action items from conversations.",
      "authMethods": [
        "Bearer token",
        "OAuth 2.0"
      ],
      "selfServeStatus": "contact_sales",
      "selfServeSummary": "Public API access is limited to Enterprise workspaces; contact an Otter account manager to enable it, then an authorized user can create API keys in Integrations > Developer.",
      "apiProtocols": [
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; Enterprise Public API covers channels, conversations, transcripts, audio, action items, insights, outlines, workspace details, pagination, and webhooks.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Enterprise/API enablement and MCP support scope",
      "recommendedNextStep": "Confirm Enterprise eligibility and have the account manager or Support enable API/MCP access, then validate Bearer-key and OAuth flows in a test workspace.",
      "confidence": "high",
      "uncertainties": "Exact Enterprise commercial terms and whether the requested client or workspace is currently enabled for MCP remain unverified.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Otter documents Bearer-token API authentication and API-key creation for Enterprise workspaces. Its official MCP server uses OAuth and exposes a server URL, but the documentation says MCP availability across AI applications is still being expanded and advises contacting Support.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://help.otter.ai/hc/en-us/articles/36130822688279-Otter-ai-Public-API",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://help.otter.ai/hc/en-us/articles/4412365535895-Does-Otter-offer-an-open-API",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://help.otter.ai/hc/en-us/articles/36130822688279-Otter-ai-Public-API",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://help.otter.ai/hc/en-us/articles/35287607569687-Otter-MCP-Server",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Bearer token",
            "OAuth 2.0"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 93,
      "appName": "Fathom",
      "category": "AI, Research and Media-native",
      "startingHint": "fathom.video",
      "whatItDoes": "Fathom records and analyzes meetings, providing searchable transcripts, summaries, action items, and related meeting intelligence.",
      "authMethods": [
        "X-Api-Key API key",
        "OAuth 2.0"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Users can generate an API key from Fathom User Settings; public OAuth apps can be registered through Fathom, with review applying to public integrations and marketplace promotion.",
      "apiProtocols": [
        "REST",
        "Webhooks",
        "SDK"
      ],
      "apiSurfaceBreadth": "moderate",
      "apiSurfaceSummary": "REST API and official TypeScript/Python SDKs cover meetings, transcripts, summaries, recordings, teams, users, webhooks, and OAuth.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Generate a Fathom API key, validate required meeting permissions, and test the documented REST endpoints or official MCP server.",
      "confidence": "high",
      "uncertainties": "The official sources do not clearly state which Fathom subscription plans include API-key generation, so the self-serve-free classification assumes the documented user-settings flow is available without a separate paid approval gate.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Fathom officially documents API keys generated in User Settings using the X-Api-Key header, OAuth for public integrations, a multi-resource REST/SDK surface, and an official MCP server at https://api.fathom.ai/mcp. Access is limited to meetings the user can view.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.fathom.ai/api-overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://developers.fathom.ai/quickstart",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.fathom.ai/llms.txt",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.fathom.ai/mcp-docs/index.md",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "X-Api-Key API key",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "moderate",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "X-Api-Key API key",
            "OAuth 2.0"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "moderate",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 94,
      "appName": "Consensus",
      "category": "AI, Research and Media-native",
      "startingHint": "consensus.app, OAuth requested hint",
      "whatItDoes": "AI research platform that searches and synthesizes evidence from more than 200 million peer-reviewed papers.",
      "authMethods": [
        "X-API-Key header",
        "OAuth"
      ],
      "selfServeStatus": "contact_sales",
      "selfServeSummary": "The API is available by application with custom pricing; request access is required, while the official MCP supports OAuth for connected clients.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "narrow",
      "apiSurfaceSummary": "narrow; documented v1 search endpoint with extensive academic filters, metadata, relevance scoring, pagination, and enterprise full-text chunks",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "API application approval and custom commercial terms",
      "recommendedNextStep": "Use the official MCP with OAuth for an immediate prototype, and submit the API access request if production API integration or higher limits are required.",
      "confidence": "high",
      "uncertainties": "The public API reference does not expose the exact X-API-Key header spelling in its rendered example, and MCP plan limits may differ from API entitlements.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Consensus officially documents an XApiKeyHeader-secured /v1/search endpoint and describes the API as application-only with pricing starting at $0.10 per call plus a platform fee. Its official MCP server is https://mcp.consensus.app/mcp and supports OAuth across major clients.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.consensus.app/reference/v1_search.md",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://consensus.app/home/api/",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.consensus.app/reference/v1_search",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.consensus.app/docs/mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "X-API-Key header",
            "OAuth"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "X-API-Key header",
            "OAuth"
          ],
          "selfServeStatus": "contact_sales",
          "apiSurfaceBreadth": "narrow",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    },
    {
      "id": 95,
      "appName": "Reducto",
      "category": "AI, Research and Media-native",
      "startingHint": "reducto.ai, document parsing",
      "whatItDoes": "Document AI platform for parsing, extracting, classifying, splitting, editing, and orchestrating workflows across 30+ file types.",
      "authMethods": [
        "API key (Bearer token)"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a free Reducto Studio account, generate an API key in the API Keys sidebar, and use the included 15K credits; no approval gate is documented.",
      "apiProtocols": [
        "REST",
        "Webhooks",
        "SDK"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "REST API and Python, Node.js, and Go SDKs cover upload, parse, extract, split, classify, edit, async jobs/webhooks, and job retrieval.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "None identified",
      "recommendedNextStep": "Create a Reducto Studio account, generate an API key, and validate the target workflow against the documented REST or SDK endpoints and native MCP server.",
      "confidence": "high",
      "uncertainties": "The exact eligibility details for free credits are not expanded in the pricing FAQ, but self-serve account creation and API-key generation are explicitly documented.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs specify REDUCTO_API_KEY and Authorization: Bearer authentication, with API keys created in Studio. Pricing lists a Standard plan with the first 15K credits free. Reducto documents its own hosted and local MCP server at mcp.reducto.ai and via mcp-server-reducto.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.reducto.ai/agent-guide",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.reducto.ai/quickstart",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.reducto.ai/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.reducto.ai/mcp-server",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer token (API key)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer token (API key)"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      },
      "postRepairHoldout": {
        "blindComparison": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": false,
          "mcp": true,
          "verdict": true
        },
        "verifierNote": "Official docs show free account signup, Studio API-key creation, Bearer authentication, broad document APIs, and a Reducto-published MCP server; production billing may still apply.",
        "verifierConfidence": "high",
        "correctedAt": "2026-08-17",
        "note": "This record was independently checked after full-set second-pass repair; its blind comparison remains in data/post_repair_holdout.json."
      }
    },
    {
      "id": 96,
      "appName": "Devin",
      "category": "AI, Research and Media-native",
      "startingHint": "docs.devin.ai, MCP hint",
      "whatItDoes": "AI software engineer that autonomously writes, runs, tests, and manages software work through cloud sessions and developer workflows.",
      "authMethods": [
        "Bearer token (cog_ service user API key)",
        "Bearer token (cog_ personal access token)"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "Create a Devin organization under a paid Teams or Enterprise account, then create a service user and generate a one-time cog_ API key; enterprise PATs may require admin approval.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "v3 REST APIs cover organization sessions, knowledge, playbooks, secrets and scheduling, plus enterprise administration, analytics, audit logs, billing and users.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Paid organization and service-user/API-key provisioning",
      "recommendedNextStep": "Provision a Teams organization, create a least-privilege service user, generate a cog_ key, and validate the required v3 endpoints and official MCP server.",
      "confidence": "high",
      "uncertainties": "The public pricing page does not clearly expose plan-level API eligibility in its rendered comparison, so confirm API entitlement for the selected Teams plan during provisioning.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs document Bearer authentication with cog_-prefixed service-user keys or PATs, service-user creation in organization settings, and v3 organization/enterprise APIs. The official Devin MCP server is at mcp.devin.ai/mcp and requires a Devin API key; legacy apk_ keys are unsupported.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://docs.devin.ai/api-reference/authentication",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://docs.devin.ai/api-reference/getting-started/teams-quickstart",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://docs.devin.ai/api-reference/overview",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://docs.devin.ai/work-with-devin/devin-mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer token (cog_ service user API key)",
            "Bearer token (cog_ personal access token)"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer token (cog_ service user API key)",
            "Bearer token (cog_ personal access token)"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 97,
      "appName": "Higgsfield",
      "category": "AI, Research and Media-native",
      "startingHint": "higgsfield.ai/cli, content suite",
      "whatItDoes": "Higgsfield is an AI-native creative suite for generating and editing images, videos, audio, and marketing content.",
      "authMethods": [
        "API key",
        "API secret",
        "account authentication"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "Create a Higgsfield account, connect the official MCP server, and authenticate in the browser; usage consumes credits from a Higgsfield plan.",
      "apiProtocols": [
        "Unknown"
      ],
      "apiSurfaceBreadth": "platform_wide",
      "apiSurfaceSummary": "Official MCP exposes image and video generation, character training, creation-history browsing, marketing, website-building, and 30+ models.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "No public REST/API reference found; account-based MCP authentication and credit billing require validation.",
      "recommendedNextStep": "Validate the MCP handshake and credit-consuming generation flows, then implement the connector through the official server.",
      "confidence": "medium",
      "uncertainties": "The public site does not expose a complete API schema or clarify whether Cloud API keys are available to all self-serve accounts.",
      "researchedAt": "2026-08-17",
      "researchPass": 2,
      "evidenceExcerpt": "Official MCP documentation states that no API key is needed: users add https://mcp.higgsfield.ai/mcp and authenticate through a Higgsfield account. It describes asynchronous image/video generation, 30+ models, character training, history browsing, and credit-based usage; the Cloud API key portal redirects unauthenticated visitors to sign-in.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://github.com/higgsfield-ai/higgsfield-client",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://higgsfield.ai/pricing",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://github.com/higgsfield-ai/cli",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://higgsfield.ai/mcp",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "sampled_corrected",
      "researchError": "",
      "qualityFlags": [],
      "verification": {
        "sampled": true,
        "checkedAt": "2026-08-17",
        "reviewMethod": "independent_parallel_research_plus_official_source_review",
        "reviewConfidence": "high",
        "pass0": {
          "authMethods": "CLI/local, other",
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "verified": {
          "authMethods": "API key, API secret, account authentication",
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "platform_wide",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "matches": {
          "auth": true,
          "selfServe": true,
          "apiBreadth": true,
          "mcp": true,
          "verdict": false
        },
        "correctionSummary": "Official SDKs document API key plus secret; official MCP uses account sign-in without an API key, with self-serve credit plans and 30+/40+ multimodal tools. Buildability is build_now, not build_with_review.",
        "evidence": [
          {
            "field": "auth",
            "url": "https://github.com/higgsfield-ai/higgsfield-client",
            "sourceType": "official_github_or_repository",
            "status": "linked"
          },
          {
            "field": "access",
            "url": "https://higgsfield.ai/pricing",
            "sourceType": "official_product_or_help",
            "status": "linked"
          },
          {
            "field": "api",
            "url": "https://github.com/higgsfield-ai/cli",
            "sourceType": "official_github_or_repository",
            "status": "linked"
          },
          {
            "field": "mcp",
            "url": "https://higgsfield.ai/mcp",
            "sourceType": "official_product_or_help",
            "status": "linked"
          }
        ]
      }
    },
    {
      "id": 98,
      "appName": "Mermaid CLI",
      "category": "AI, Research and Media-native",
      "startingHint": "github.com/mermaid-js/mermaid-cli",
      "whatItDoes": "A command-line tool that renders Mermaid diagram definitions into SVG, PNG, PDF, or transformed Markdown output.",
      "authMethods": [
        "none required for local CLI use"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Install the public npm package or container and run mmdc locally; the official CLI workflow documents no account, API key, token, or approval gate.",
      "apiProtocols": [
        "CLI"
      ],
      "apiSurfaceBreadth": "unknown",
      "apiSurfaceSummary": "CLI commands plus a Node.js run() API expose diagram rendering, file/stdin input, output formats, themes, backgrounds, CSS, and configuration options.",
      "mcpStatus": "mcp_not_verified",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Runtime dependency on Node.js and Chromium/Puppeteer",
      "recommendedNextStep": "Build a local or containerized integration around mmdc, pin the package and browser versions, and validate the required diagram and output formats.",
      "confidence": "high",
      "uncertainties": "The repository does not publish a formal authentication or pricing statement, but its documented local npm, npx, Docker, and Node.js workflows require no credentials.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "The official repository describes Mermaid CLI as a local command-line tool: install via npm, pass Mermaid input to mmdc, and generate SVG/PNG/PDF; it also documents a Node.js run() API. No credential flow is documented. The separate Mermaid Chart MCP Server is not evidence of MCP for this CLI.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://github.com/mermaid-js/mermaid-cli#usage",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://github.com/mermaid-js/mermaid-cli#installation",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://github.com/mermaid-js/mermaid-cli#use-nodejs-api",
          "sourceType": "official_github_or_repository",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "unknown",
          "sourceType": "unverified",
          "retrievedAt": "2026-08-17",
          "status": "unknown"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [
        "api_breadth_unknown"
      ],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "none required for local CLI use"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "none required for local CLI use"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "mcp_not_verified",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 99,
      "appName": "YouTube Transcript",
      "category": "AI, Research and Media-native",
      "startingHint": "transcriptapi.com",
      "whatItDoes": "Extracts YouTube transcripts and supports video search, channel browsing, playlist listing, and latest-upload monitoring.",
      "authMethods": [
        "Bearer API key",
        "OAuth 2.1"
      ],
      "selfServeStatus": "self_serve_free",
      "selfServeSummary": "Create a TranscriptAPI account, obtain an API key from the dashboard, and use the free starting credits; paid approval is not documented.",
      "apiProtocols": [
        "REST"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; REST API covers transcripts, video info, search, channel resolution/search/videos/latest, and playlist videos.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "direct_now",
      "buildabilityVerdict": "build_now",
      "primaryBlocker": "Usage credits and plan limits",
      "recommendedNextStep": "Create a free TranscriptAPI account, generate an API key, and validate the transcript and MCP endpoints in a small integration test.",
      "confidence": "high",
      "uncertainties": "The public pricing page URL is unavailable, so exact recurring paid-plan limits and current post-credit pricing are not independently confirmed.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs specify Bearer API-key authentication for REST and OAuth 2.1 or API-key authentication for MCP. The vendor advertises free signup, dashboard-issued keys, and 100 starting credits, while documenting transcript, search, channel, and playlist endpoints plus its MCP server at https://transcriptapi.com/mcp.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://transcriptapi.com/docs/api/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://transcriptapi.com/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://transcriptapi.com/docs/api/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://transcriptapi.com/docs/mcp/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Bearer API key",
            "OAuth 2.1"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        },
        "replaced": {
          "authMethods": [
            "Bearer API key",
            "OAuth 2.1"
          ],
          "selfServeStatus": "self_serve_free",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_now"
        }
      }
    },
    {
      "id": 100,
      "appName": "Grain",
      "category": "AI, Research and Media-native",
      "startingHint": "grain.com, meeting notes",
      "whatItDoes": "AI meeting recorder and intelligence platform that captures, transcribes, analyzes, and operationalizes meeting data.",
      "authMethods": [
        "Personal Access Token",
        "Workspace Access Token",
        "OAuth2"
      ],
      "selfServeStatus": "self_serve_paid",
      "selfServeSummary": "Personal tokens are self-serve on Starter+; workspace tokens require a Business/Enterprise workspace admin, while OAuth client credentials must be requested manually.",
      "apiProtocols": [
        "Webhooks"
      ],
      "apiSurfaceBreadth": "broad",
      "apiSurfaceSummary": "broad; v2 API supports recordings, transcripts, uploads, metadata, sharing, users, teams, meeting types, webhooks, and OAuth token flows.",
      "mcpStatus": "native_official_mcp",
      "agentCallability": "feasible_with_build",
      "buildabilityVerdict": "build_with_review",
      "primaryBlocker": "Paid-plan requirement plus admin gate for workspace-wide access and manual OAuth client registration",
      "recommendedNextStep": "Use a Starter+ Grain account for a PAT pilot, or obtain Business/Enterprise admin approval and request OAuth credentials for a distributable integration.",
      "confidence": "high",
      "uncertainties": "The exact process, eligibility criteria, and turnaround for requesting OAuth client ID and secret are not documented publicly.",
      "researchedAt": "2026-08-17",
      "researchPass": 1,
      "evidenceExcerpt": "Official docs list PAT, workspace access tokens, and OAuth2 with Bearer authentication. Grain states API access excludes Free, PATs require Starter+, workspace tokens require Business/Enterprise admin access, and OAuth client credentials are obtained manually. Grain publishes its own MCP endpoint at https://api.grain.com/_/mcp.",
      "evidence": [
        {
          "field": "auth",
          "url": "https://developers.grain.com/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "access",
          "url": "https://support.grain.com/en/articles/15507288-grain-api",
          "sourceType": "official_product_or_help",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "api",
          "url": "https://developers.grain.com/",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        },
        {
          "field": "mcp",
          "url": "https://developers.grain.com/mcp",
          "sourceType": "official_docs",
          "retrievedAt": "2026-08-17",
          "status": "linked"
        }
      ],
      "humanReviewStatus": "not_reviewed",
      "researchError": "",
      "qualityFlags": [],
      "secondPass": {
        "completedAt": "2026-08-17",
        "previous": {
          "authMethods": [
            "Personal Access Token",
            "Workspace Access Token",
            "OAuth2"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "unknown",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        },
        "replaced": {
          "authMethods": [
            "Personal Access Token",
            "Workspace Access Token",
            "OAuth2"
          ],
          "selfServeStatus": "self_serve_paid",
          "apiSurfaceBreadth": "broad",
          "mcpStatus": "native_official_mcp",
          "buildabilityVerdict": "build_with_review"
        }
      }
    }
  ],
  "summary": {
    "generatedAt": "2026-08-17T11:30:54.542Z",
    "researchAsOf": "2026-08-17",
    "records": 100,
    "categories": 10,
    "verdictCounts": {
      "build_now": 50,
      "build_with_review": 47,
      "outreach_required": 3
    },
    "selfServeCounts": {
      "self_serve_free": 41,
      "admin_approval": 17,
      "self_serve_trial": 16,
      "self_serve_paid": 10,
      "app_review": 7,
      "contact_sales": 7,
      "unknown": 2
    },
    "mcpCounts": {
      "native_official_mcp": 78,
      "mcp_not_verified": 12,
      "mcp_possible_via_api": 7,
      "native_third_party_mcp": 2,
      "composio_mcp_exposure": 1
    },
    "confidenceCounts": {
      "high": 95,
      "medium": 5
    },
    "apiBreadthCounts": {
      "broad": 46,
      "platform_wide": 31,
      "unknown": 18,
      "moderate": 4,
      "narrow": 1
    },
    "evidenceCoverage": {
      "linkedSlots": 386,
      "totalSlots": 400,
      "percentage": 96.5
    },
    "qualityFlags": {},
    "missingIds": [],
    "duplicateIds": [],
    "verificationMetrics": {
      "sampleSize": 25,
      "fieldsChecked": 125,
      "recordLevelExactMatch": {
        "matches": 13,
        "checked": 25,
        "percentage": 52
      },
      "fieldAccuracy": {
        "auth": {
          "matches": 19,
          "checked": 25,
          "percentage": 76
        },
        "selfServe": {
          "matches": 22,
          "checked": 25,
          "percentage": 88
        },
        "apiBreadth": {
          "matches": 24,
          "checked": 25,
          "percentage": 96
        },
        "mcp": {
          "matches": 21,
          "checked": 25,
          "percentage": 84
        },
        "verdict": {
          "matches": 22,
          "checked": 25,
          "percentage": 88
        }
      },
      "correctionCount": 12,
      "correctionRate": 48,
      "remainingUnknownsInSample": 0
    },
    "secondPass": {
      "repairedRecords": 75,
      "recordsWithClassificationChanges": 43
    },
    "postRepairHoldout": {
      "rawBlindComparison": {
        "sampleSize": 10,
        "fieldsChecked": 50,
        "recordLevelExactMatch": {
          "matches": 0,
          "checked": 10,
          "percentage": 0
        },
        "fieldAccuracy": {
          "auth": {
            "matches": 10,
            "checked": 10,
            "percentage": 100
          },
          "selfServe": {
            "matches": 7,
            "checked": 10,
            "percentage": 70
          },
          "apiBreadth": {
            "matches": 2,
            "checked": 10,
            "percentage": 20
          },
          "mcp": {
            "matches": 9,
            "checked": 10,
            "percentage": 90
          },
          "verdict": {
            "matches": 8,
            "checked": 10,
            "percentage": 80
          }
        },
        "mismatchCount": 10,
        "design": "One app per category; independently researched after the second-pass repair; classifications were not disclosed to the verifier before research."
      },
      "correctionsApplied": 10,
      "limitation": "The 10-record holdout did not return the requested API breadth field, so it is retained as an error-discovery correction loop, not a generalisable post-repair accuracy estimate."
    }
  },
  "report": {
    "generatedAt": "2026-08-17T10:08:10.077Z",
    "controls": {
      "expectedRecords": 100,
      "actualRecords": 100,
      "missingIds": [],
      "duplicateIds": [],
      "identityComplete": 100,
      "linkedEvidenceCoverage": {
        "linkedSlots": 391,
        "totalSlots": 400,
        "percentage": 97.8
      },
      "recordsWithFlags": []
    },
    "verification": {
      "metrics": {
        "sampleSize": 25,
        "fieldsChecked": 125,
        "recordLevelExactMatch": {
          "matches": 13,
          "checked": 25,
          "percentage": 52
        },
        "fieldAccuracy": {
          "auth": {
            "matches": 19,
            "checked": 25,
            "percentage": 76
          },
          "selfServe": {
            "matches": 22,
            "checked": 25,
            "percentage": 88
          },
          "apiBreadth": {
            "matches": 24,
            "checked": 25,
            "percentage": 96
          },
          "mcp": {
            "matches": 21,
            "checked": 25,
            "percentage": 84
          },
          "verdict": {
            "matches": 22,
            "checked": 25,
            "percentage": 88
          }
        },
        "correctionCount": 12,
        "correctionRate": 48,
        "remainingUnknownsInSample": 0
      },
      "corrections": [
        {
          "appId": 6,
          "appName": "Podio",
          "correctionSummary": "Podio officially supports OAuth2 bearer tokens and app authentication, but not a documented PAT. API access is free and self-serve for free accounts. Podio now documents an official MCP server, so prior MCP and access labels need correction.",
          "correctedFields": [
            "auth",
            "selfServe",
            "mcp"
          ]
        },
        {
          "appId": 1,
          "appName": "Salesforce",
          "correctionSummary": "Salesforce officially documents OAuth 2.0 and bearer access tokens, but not PAT as a standard API auth method. Admin enablement and governance are required for hosted MCP servers; official MCP and platform-wide capabilities are confirmed.",
          "correctedFields": [
            "auth"
          ]
        },
        {
          "appId": 11,
          "appName": "Zendesk",
          "correctionSummary": "Zendesk officially supports OAuth and deprecated API tokens via Basic auth. Its API spans ticketing, Help Center, messaging, voice, CRM, custom data, omnichannel, apps, and integrations. MCP is third-party via the Zendesk Marketplace, not Composio exposure.",
          "correctedFields": [
            "mcp"
          ]
        },
        {
          "appId": 21,
          "appName": "Slack",
          "correctionSummary": "Slack officially documents OAuth 2.0 and token-based API access; no official Basic/PAT method was verified. App creation, single-workspace install, and unlisted distribution are self-serve; Marketplace listing requires review.",
          "correctedFields": [
            "auth"
          ]
        },
        {
          "appId": 22,
          "appName": "Twilio",
          "correctionSummary": "Twilio officially supports OAuth 2.0 and API-key/Account SID Basic Auth; bearer/PAT is not evidenced for core APIs. Official MCP is public beta and read-only, so build with review rather than build_now.",
          "correctedFields": [
            "auth",
            "verdict"
          ]
        },
        {
          "appId": 32,
          "appName": "Meta Ads",
          "correctionSummary": "Meta officially documents OAuth and user/system access tokens sent as bearer tokens; it does not document PAT as a distinct auth method. Production cross-business access and higher tier require App Review.",
          "correctedFields": [
            "auth"
          ]
        },
        {
          "appId": 58,
          "appName": "Sherlock",
          "correctionSummary": "Official Sherlock is a free, locally installed CLI covering 400+ sites, not a conventional hosted API. A community third-party MCP server exists; no official MCP or official API was found.",
          "correctedFields": [
            "apiBreadth",
            "mcp"
          ]
        },
        {
          "appId": 51,
          "appName": "DataForSEO",
          "correctionSummary": "Official docs state Basic authentication is the only API method; OAuth 2.0 is not documented. Account signup provides API credentials and $1 trial credit, while broad APIs and an official MCP server are available.",
          "correctedFields": [
            "auth"
          ]
        },
        {
          "appId": 71,
          "appName": "Notion",
          "correctionSummary": "Notion's API supports OAuth, bearer tokens, PATs, and internal static tokens. Official hosted MCP is available, but the documented Claude Desktop access requires Pro/Max/Team/Enterprise, so the strict classification is self_serve_paid, not free.",
          "correctedFields": [
            "selfServe"
          ]
        },
        {
          "appId": 81,
          "appName": "Stripe",
          "correctionSummary": "Stripe officially supports API keys via HTTP Basic or bearer auth, plus OAuth 2.0. Standard signup is self-serve, but MCP access must be enabled by an administrator; therefore strict access is admin_approval and build_now is too permissive.",
          "correctedFields": [
            "selfServe",
            "verdict"
          ]
        },
        {
          "appId": 97,
          "appName": "Higgsfield",
          "correctionSummary": "Official SDKs document API key plus secret; official MCP uses account sign-in without an API key, with self-serve credit plans and 30+/40+ multimodal tools. Buildability is build_now, not build_with_review.",
          "correctedFields": [
            "verdict"
          ]
        },
        {
          "appId": 91,
          "appName": "NotebookLM",
          "correctionSummary": "Google documents a Gemini Notebook Enterprise REST API using Google auth tokens and IAM roles, but it is Preview, requires a billed Cloud project, API enablement, licenses, and admin setup. No official NotebookLM MCP was verified.",
          "correctedFields": [
            "mcp"
          ]
        }
      ]
    }
  }
} as const;
