// Evidence Ledger: deterministic insights generated from reconciled research data.
export const insights = {
  "generatedAt": "2026-08-17T11:30:54.616Z",
  "researchAsOf": "2026-08-17",
  "headline": "The build queue is substantial, but credential and approval friction still decides priority.",
  "narrative": "Of 100 apps, 67 (67%) have a self-serve credential path while 31 (31%) require an approval, review, partner, or sales gate. 50 apps (50%) fall into the largest buildability bucket: build now. OAuth 2.0 is the most common observed auth pattern at 42 app records.",
  "kpis": {
    "researchCoverage": {
      "value": "100/100",
      "label": "apps researched",
      "detail": "10 categories; exact manifest coverage"
    },
    "buildNow": {
      "value": "50",
      "label": "build-now candidates",
      "detail": "50% of research set"
    },
    "gated": {
      "value": "31",
      "label": "gated access paths",
      "detail": "31% require review, admin, partner, or sales action"
    },
    "evidence": {
      "value": "96.5%",
      "label": "linked evidence coverage",
      "detail": "386/400 planned evidence slots"
    },
    "verification": {
      "value": "52%",
      "label": "first-pass exact match",
      "detail": "13/25 sampled records; corrected final alignment is 100% on the same sample"
    }
  },
  "authMix": [
    {
      "label": "OAuth 2.0",
      "count": 42,
      "percentage": 42
    },
    {
      "label": "API key",
      "count": 16,
      "percentage": 16
    },
    {
      "label": "bearer/PAT",
      "count": 8,
      "percentage": 8
    },
    {
      "label": "Bearer token",
      "count": 7,
      "percentage": 7
    },
    {
      "label": "Basic",
      "count": 6,
      "percentage": 6
    },
    {
      "label": "Bearer access token",
      "count": 5,
      "percentage": 5
    },
    {
      "label": "Bearer API key",
      "count": 4,
      "percentage": 4
    },
    {
      "label": "OAuth 2.0 authorization code",
      "count": 4,
      "percentage": 4
    },
    {
      "label": "bearer access token",
      "count": 3,
      "percentage": 3
    },
    {
      "label": "CLI/local",
      "count": 3,
      "percentage": 3
    },
    {
      "label": "API key (Bearer token)",
      "count": 3,
      "percentage": 3
    },
    {
      "label": "OAuth",
      "count": 3,
      "percentage": 3
    },
    {
      "label": "OAuth 2.0 client credentials",
      "count": 3,
      "percentage": 3
    },
    {
      "label": "OAuth 2.0 Authorization Code",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "OAuth 2.0 Client Credentials",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "API token",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "bearer token",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "Basic Auth",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "bot token",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "Basic authentication",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "service account",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "other",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "X-API-Key header",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "unknown",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "Personal Access Token",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "app authentication token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "API keys",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "API key via HTTP Basic Auth",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bearer API tokens",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.1 + PKCE for MCP",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 (MCP)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.1 Authorization Code + PKCE",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 bearer tokens",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Docs API key via HTTP Basic Authentication",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "HTTP Basic Authentication (email and API key)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "HTTP Basic Authentication (agent email + API token)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Auth token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 refresh token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "App ID/App Secret",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 user authorization",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "user token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "app key",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bot token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth2 bearer token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "api_id/api_hash plus user authorization",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "API key and secret",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "JWT",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "user access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "system user access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Private Integration Token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Private API key",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Public API key",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "MCP key via X-MCP-Key header or mcpKey query parameter",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "HTTP Basic token-endpoint authentication",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 Threads user access tokens",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Basic API key",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 authorization code grant",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "store-level API access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "account-level API access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.1 client credentials",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "SLAS JWT bearer tokens",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 1.0a integration credentials",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bearer access tokens",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "session cookies",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 via Login with Amazon (LWA)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "LWA access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "LWA refresh token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Restricted Data Token (RDT)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "client credentials grantless flow",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Authorization: Token API key",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "apikey query parameter",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.1 for remote MCP",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "API token via x-api-token header",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bearer API token for official MCP",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "query-parameter token for analytics",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bearer API token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "token query parameter",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "x402 payment credential",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Skyfire payment credential",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "keyless no-auth access",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "proxy username/password",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "API key (x-api-key header)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "personal access token (Bearer)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Account API token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Global API key (legacy)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bearer personal access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bearer authentication",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "key-pair JWT",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "programmatic access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "workload identity federation",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 service account access tokens",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "HTTP Digest Authentication API keys",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Application key",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bearer auth tokens",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 device authorization",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "personal access token (PAT)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "static API token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "personal API keys",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "API token via HTTP Basic Auth",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 authorization code grant (3LO)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.1 via Atlassian Rovo MCP",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "JWT for Connect apps",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Forge app authentication",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Personal access token (PAT)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Personal V2 API token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0/2.1 access token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "seamless SDK authentication",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "short-lived token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Personal API token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "API token (Bearer)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2 with PKCE (MCP)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "bearer",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "client_id and secret",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 client credentials for Dashboard MCP",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "HMAC request signing",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "RSA",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Ed25519",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "session-based authentication",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 PKCE",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.0 client credentials (Custom Connections)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "HTTP Basic Auth for token endpoint",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "authentication token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Google Cloud IAM",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "X-Api-Key API key",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bearer token (cog_ service user API key)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Bearer token (cog_ personal access token)",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "API secret",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "account authentication",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "none required for local CLI use",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth 2.1",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Workspace Access Token",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth2",
      "count": 1,
      "percentage": 1
    }
  ],
  "verdicts": [
    {
      "label": "build_now",
      "count": 50,
      "percentage": 50
    },
    {
      "label": "build_with_review",
      "count": 47,
      "percentage": 47
    },
    {
      "label": "outreach_required",
      "count": 3,
      "percentage": 3
    }
  ],
  "access": [
    {
      "label": "self_serve_free",
      "count": 41,
      "percentage": 41
    },
    {
      "label": "admin_approval",
      "count": 17,
      "percentage": 17
    },
    {
      "label": "self_serve_trial",
      "count": 16,
      "percentage": 16
    },
    {
      "label": "self_serve_paid",
      "count": 10,
      "percentage": 10
    },
    {
      "label": "app_review",
      "count": 7,
      "percentage": 7
    },
    {
      "label": "contact_sales",
      "count": 7,
      "percentage": 7
    },
    {
      "label": "unknown",
      "count": 2,
      "percentage": 2
    }
  ],
  "mcp": [
    {
      "label": "native_official_mcp",
      "count": 78,
      "percentage": 78
    },
    {
      "label": "mcp_not_verified",
      "count": 12,
      "percentage": 12
    },
    {
      "label": "mcp_possible_via_api",
      "count": 7,
      "percentage": 7
    },
    {
      "label": "native_third_party_mcp",
      "count": 2,
      "percentage": 2
    },
    {
      "label": "composio_mcp_exposure",
      "count": 1,
      "percentage": 1
    }
  ],
  "apiBreadth": [
    {
      "label": "broad",
      "count": 46,
      "percentage": 46
    },
    {
      "label": "platform_wide",
      "count": 31,
      "percentage": 31
    },
    {
      "label": "unknown",
      "count": 18,
      "percentage": 18
    },
    {
      "label": "moderate",
      "count": 4,
      "percentage": 4
    },
    {
      "label": "narrow",
      "count": 1,
      "percentage": 1
    }
  ],
  "blockers": [
    {
      "label": "Org-admin authorization and changed Salesforce app-creation model",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Target-account administrator authorization",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Workspace admin required for API-key provisioning",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth data-center and scope configuration",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Close account and organization access required",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "OAuth app registration for multi-tenant integrations",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "DealCloud with Celeste license and MCP/admin permissions required",
      "count": 1,
      "percentage": 1
    },
    {
      "label": "Intercom review required for public customer-data integrations",
      "count": 1,
      "percentage": 1
    }
  ],
  "categoryRows": [
    {
      "category": "CRM and Sales",
      "total": 10,
      "buildNow": 7,
      "gated": 3,
      "selfServe": 7,
      "buildNowPercentage": 70
    },
    {
      "category": "Support and Helpdesk",
      "total": 10,
      "buildNow": 4,
      "gated": 5,
      "selfServe": 4,
      "buildNowPercentage": 40
    },
    {
      "category": "Communications and Messaging",
      "total": 10,
      "buildNow": 4,
      "gated": 1,
      "selfServe": 8,
      "buildNowPercentage": 40
    },
    {
      "category": "Marketing, Ads, Email and Social",
      "total": 10,
      "buildNow": 4,
      "gated": 4,
      "selfServe": 6,
      "buildNowPercentage": 40
    },
    {
      "category": "Ecommerce",
      "total": 10,
      "buildNow": 2,
      "gated": 6,
      "selfServe": 4,
      "buildNowPercentage": 20
    },
    {
      "category": "Data, SEO and Scraping",
      "total": 10,
      "buildNow": 7,
      "gated": 1,
      "selfServe": 9,
      "buildNowPercentage": 70
    },
    {
      "category": "Developer, Infra and Data Platforms",
      "total": 10,
      "buildNow": 7,
      "gated": 2,
      "selfServe": 8,
      "buildNowPercentage": 70
    },
    {
      "category": "Productivity and Project Management",
      "total": 10,
      "buildNow": 8,
      "gated": 0,
      "selfServe": 10,
      "buildNowPercentage": 80
    },
    {
      "category": "Finance and Fintech",
      "total": 10,
      "buildNow": 1,
      "gated": 6,
      "selfServe": 4,
      "buildNowPercentage": 10
    },
    {
      "category": "AI, Research and Media-native",
      "total": 10,
      "buildNow": 6,
      "gated": 3,
      "selfServe": 7,
      "buildNowPercentage": 60
    }
  ],
  "easyWins": [
    {
      "id": 2,
      "appName": "HubSpot",
      "category": "CRM and Sales",
      "why": "admin approval; platform_wide API surface; native official mcp.",
      "nextStep": "Build the OAuth connector against HubSpot’s current date-versioned REST API and optionally expose the official remote MCP server for agent workflows.",
      "confidence": "high"
    },
    {
      "id": 3,
      "appName": "Pipedrive",
      "category": "CRM and Sales",
      "why": "self serve trial; platform_wide API surface; native official mcp.",
      "nextStep": "Build against OAuth 2.0 first, retain API-token support for private integrations, and validate MCP actions against Pipedrive permissions and token limits.",
      "confidence": "high"
    },
    {
      "id": 4,
      "appName": "Attio",
      "category": "CRM and Sales",
      "why": "self serve free; platform_wide API surface; native official mcp.",
      "nextStep": "Implement OAuth 2.0 first, with scoped single-workspace API-key support as a fallback and explicit admin guidance.",
      "confidence": "high"
    },
    {
      "id": 5,
      "appName": "Twenty",
      "category": "CRM and Sales",
      "why": "self serve trial; platform_wide API surface; native official mcp.",
      "nextStep": "Implement the REST or GraphQL connector with OAuth 2.0 and API-key paths, then validate workspace-specific schemas and MCP parity.",
      "confidence": "high"
    },
    {
      "id": 7,
      "appName": "Zoho CRM",
      "category": "CRM and Sales",
      "why": "self serve free; platform_wide API surface; native official mcp.",
      "nextStep": "Build the OAuth connector with regional Zoho Accounts/API domains, configurable scopes, refresh-token handling, and CRM API-credit throttling.",
      "confidence": "high"
    },
    {
      "id": 8,
      "appName": "Close",
      "category": "CRM and Sales",
      "why": "self serve trial; platform_wide API surface; native official mcp.",
      "nextStep": "Create a Close trial or eligible organization, generate an API key or register an OAuth app, and test the official MCP server with read-only scope first.",
      "confidence": "high"
    },
    {
      "id": 11,
      "appName": "Zendesk",
      "category": "Support and Helpdesk",
      "why": "self serve trial; platform_wide API surface; native third party mcp.",
      "nextStep": "Proceed with the Zendesk toolkit using global OAuth for multi-customer distribution, and validate endpoint plan availability and role-based scopes during implementation.",
      "confidence": "high"
    },
    {
      "id": 16,
      "appName": "LiveAgent",
      "category": "Support and Helpdesk",
      "why": "admin approval; broad API surface; native official mcp.",
      "nextStep": "Create a trial account, have an admin generate a scoped API key or MCP token, and validate required ticket operations against the tenant.",
      "confidence": "high"
    },
    {
      "id": 17,
      "appName": "Plain",
      "category": "Support and Helpdesk",
      "why": "self serve trial; platform_wide API surface; native official mcp.",
      "nextStep": "Start a Plain trial, create a machine user and least-privilege API key, or connect the official MCP server via OAuth for agent workflows.",
      "confidence": "high"
    },
    {
      "id": 18,
      "appName": "Help Scout",
      "category": "Support and Helpdesk",
      "why": "self serve paid; broad API surface; native official mcp.",
      "nextStep": "Create a Help Scout OAuth app, authorize an active user, and connect the official MCP endpoint https://mcp.helpscout.net/mcp for read-only operations.",
      "confidence": "high"
    }
  ],
  "outreachQueue": [
    {
      "id": 44,
      "appName": "Salesforce Commerce Cloud",
      "category": "Ecommerce",
      "gate": "contact sales",
      "blocker": "Salesforce account-executive onboarding and pilot availability for MCP",
      "nextStep": "Confirm Commerce Cloud entitlement and instance access with Salesforce, then request MCP pilot onboarding and provision scoped SLAS credentials.",
      "confidence": "high"
    },
    {
      "id": 50,
      "appName": "FanBasis",
      "category": "Ecommerce",
      "gate": "contact sales",
      "blocker": "API documentation and credentials require gated access",
      "nextStep": "Contact Commas/FanBasis Enterprise to request API documentation, authentication details, credentials, and MCP beta enrollment.",
      "confidence": "high"
    },
    {
      "id": 59,
      "appName": "Waterfall.io",
      "category": "Data, SEO and Scraping",
      "gate": "contact sales",
      "blocker": "Contract-based API key issuance",
      "nextStep": "Contact Waterfall.io to obtain a contract and master API key, then validate the required endpoints and usage limits.",
      "confidence": "high"
    },
    {
      "id": 84,
      "appName": "Paygent Connect",
      "category": "Finance and Fintech",
      "gate": "contact sales",
      "blocker": "API credentials and specifications are not publicly self-serve",
      "nextStep": "Contact Paygent to obtain the API specification, authentication details, sandbox access, and integration agreement.",
      "confidence": "medium"
    },
    {
      "id": 90,
      "appName": "PitchBook",
      "category": "Finance and Fintech",
      "gate": "contact sales",
      "blocker": "Standalone commercial contract and subscriber-gated access",
      "nextStep": "Contact PitchBook Direct Data to confirm API or MCP entitlement, credentials, scopes, rate limits, and permitted integration use.",
      "confidence": "high"
    },
    {
      "id": 92,
      "appName": "Otter AI",
      "category": "AI, Research and Media-native",
      "gate": "contact sales",
      "blocker": "Enterprise/API enablement and MCP support scope",
      "nextStep": "Confirm Enterprise eligibility and have the account manager or Support enable API/MCP access, then validate Bearer-key and OAuth flows in a test workspace.",
      "confidence": "high"
    },
    {
      "id": 94,
      "appName": "Consensus",
      "category": "AI, Research and Media-native",
      "gate": "contact sales",
      "blocker": "API application approval and custom commercial terms",
      "nextStep": "Use the official MCP with OAuth for an immediate prototype, and submit the API access request if production API integration or higher limits are required.",
      "confidence": "high"
    }
  ],
  "researchDebt": [
    {
      "id": 13,
      "appName": "Freshdesk",
      "category": "Support and Helpdesk",
      "issue": "api_breadth_unknown",
      "action": "Use the REST API with a verified agent API key for immediate prototyping, and request Freshdesk MCP EAP access from the technical account manager or support team before production MCP deployment.",
      "confidence": "high"
    },
    {
      "id": 14,
      "appName": "Front",
      "category": "Support and Helpdesk",
      "issue": "access_unknown",
      "action": "Create a Front developer app, enable the MCP Server feature with least-privilege scopes, and validate the target client supports confidential OAuth without Dynamic Client Registration.",
      "confidence": "high"
    },
    {
      "id": 15,
      "appName": "Pylon",
      "category": "Support and Helpdesk",
      "issue": "api_breadth_unknown",
      "action": "Have a Pylon Admin enable API tokens or MCP Access, then validate the required endpoints and role-scoped permissions in a test organization.",
      "confidence": "high"
    },
    {
      "id": 24,
      "appName": "Lark",
      "category": "Communications and Messaging",
      "issue": "api_breadth_unknown",
      "action": "Create a custom app in the Lark developer console, configure only required scopes and availability, then submit it for tenant-admin review and test the official OpenAPI MCP.",
      "confidence": "high"
    },
    {
      "id": 25,
      "appName": "Pumble",
      "category": "Communications and Messaging",
      "issue": "api_breadth_unknown",
      "action": "Install the API addon or create a Pumble app, generate the required credentials, grant only the needed scopes, and run endpoint/MCP permission tests.",
      "confidence": "high"
    },
    {
      "id": 27,
      "appName": "Telegram",
      "category": "Communications and Messaging",
      "issue": "api_breadth_unknown",
      "action": "Create a dedicated bot in @BotFather, securely store the token, and validate required chat permissions and webhook or polling behavior against the Bot API.",
      "confidence": "high"
    },
    {
      "id": 29,
      "appName": "Aircall",
      "category": "Communications and Messaging",
      "issue": "access_unknown",
      "action": "Use Basic Auth with customer-generated API ID/token for a single account, or apply to the Technology Partner program for multi-customer OAuth distribution.",
      "confidence": "high"
    },
    {
      "id": 30,
      "appName": "Vonage",
      "category": "Communications and Messaging",
      "issue": "api_breadth_unknown",
      "action": "Create a Vonage developer account, generate dashboard credentials, validate the required API and MCP tools within trial limits, then enable the full account before production use.",
      "confidence": "high"
    },
    {
      "id": 34,
      "appName": "GoHighLevel",
      "category": "Marketing, Ads, Email and Social",
      "issue": "api_breadth_unknown",
      "action": "Create a scoped Private Integration Token in a test location and validate the required MCP/API operations against the official endpoint.",
      "confidence": "high"
    },
    {
      "id": 36,
      "appName": "Klaviyo",
      "category": "Marketing, Ads, Email and Social",
      "issue": "api_breadth_unknown",
      "action": "Have a Klaviyo owner, admin, or manager create the app or private key, then validate required scopes and the official remote MCP OAuth flow in a test account.",
      "confidence": "high"
    }
  ],
  "verification": {
    "sampleSize": 25,
    "fieldsChecked": 125,
    "recordLevelExactMatch": {
      "matches": 13,
      "checked": 25,
      "percentage": 52
    },
    "fieldAccuracy": {
      "auth": {
        "matches": 19,
        "checked": 25,
        "percentage": 76
      },
      "selfServe": {
        "matches": 22,
        "checked": 25,
        "percentage": 88
      },
      "apiBreadth": {
        "matches": 24,
        "checked": 25,
        "percentage": 96
      },
      "mcp": {
        "matches": 21,
        "checked": 25,
        "percentage": 84
      },
      "verdict": {
        "matches": 22,
        "checked": 25,
        "percentage": 88
      }
    },
    "correctionCount": 12,
    "correctionRate": 48,
    "remainingUnknownsInSample": 0
  },
  "workflow": [
    {
      "step": "01",
      "label": "Source plan",
      "detail": "Canonical app manifest plus official docs, auth, pricing, and MCP source hierarchy."
    },
    {
      "step": "02",
      "label": "Agent research",
      "detail": "Parallel evidence extraction with strict access, API breadth, MCP, and buildability taxonomies."
    },
    {
      "step": "03",
      "label": "Quality gates",
      "detail": "Schema, enum, evidence-slot, native-MCP, and buildability-access consistency controls."
    },
    {
      "step": "04",
      "label": "Human escalation",
      "detail": "A stratified 25-app audit prioritising MCP claims, gated access, and ambiguous evidence."
    },
    {
      "step": "05",
      "label": "Decision queues",
      "detail": "Build-now, outreach, and research-debt lanes generated from reconciled records."
    }
  ]
} as const;
