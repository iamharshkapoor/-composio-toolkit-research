/** Evidence Ledger page: editorial data-journalism hierarchy, visible provenance, and decision-first research controls. */
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDownRight,
  ArrowUpRight,
  BadgeCheck,
  BookOpenCheck,
  Boxes,
  ChevronDown,
  CircleAlert,
  ExternalLink,
  FileSearch,
  Filter,
  Github,
  Link2,
  Menu,
  Network,
  Search,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { insights } from "@/data/insights";
import { research } from "@/data/research";

type Evidence = { field: string; url: string; sourceType: string; status: string };
type RecordItem = {
  id: number;
  appName: string;
  category: string;
  whatItDoes: string;
  authMethods: string[];
  selfServeStatus: string;
  selfServeSummary: string;
  apiSurfaceBreadth: string;
  apiSurfaceSummary: string;
  mcpStatus: string;
  buildabilityVerdict: string;
  primaryBlocker: string;
  recommendedNextStep: string;
  confidence: string;
  uncertainties: string;
  researchedAt: string;
  evidence: Evidence[];
  qualityFlags: string[];
  humanReviewStatus: string;
  verification?: {
    sampled: boolean;
    correctionSummary: string;
    matches: Record<string, boolean>;
    reviewConfidence: string;
    evidence: Evidence[];
  };
};

const records = research.records as unknown as RecordItem[];

const visualAssets = {
  hero: "/manus-storage/evidence-ledger-hero_5bb865ef.png",
  provenance: "/manus-storage/evidence-ledger-provenance_0923668d.png",
  agent: "/manus-storage/evidence-ledger-agent_4b561054.png",
  pattern: "/manus-storage/evidence-ledger-pattern_bf7dae88.png",
  logo: "/manus-storage/evidence-ledger-logo_006f3236.png",
};

const githubUrl = "https://github.com/iamharshkapoor/-composio-toolkit-research";
const ledgerSections = [
  ["01", "Executive answer", "top"], ["02", "Decision queues", "queues"], ["03", "Research matrix", "matrix"],
  ["04", "Agent workflow", "workflow"], ["05", "Verification", "verification"], ["06", "Method", "method"],
] as const;

const label = (value: string) => value.replaceAll("_", " ");
const titleCase = (value: string) => label(value).replace(/\b\w/g, (letter) => letter.toUpperCase());
const statusClass = (value: string) => {
  if (value === "build_now" || value === "self_serve_free" || value === "self_serve_trial" || value === "high") return "status-positive";
  if (["outreach_required", "partner_gated", "contact_sales", "low"].includes(value)) return "status-warning";
  if (["build_with_review", "admin_approval", "app_review", "medium"].includes(value)) return "status-review";
  return "status-neutral";
};

const sourceFor = (record: RecordItem, field: string) =>
  [...(record.verification?.evidence ?? []), ...record.evidence].find((item) => item.field === field && item.status === "linked");

function MiniBar({ items, accent = "lime" }: { items: readonly { label: string; count: number; percentage: number }[]; accent?: "lime" | "orange" | "blue" }) {
  const max = Math.max(...items.map((item) => item.count), 1);
  return (
    <div className={`mini-bars mini-bars-${accent}`}>
      {items.map((item) => (
        <div className="mini-bar-row" key={item.label}>
          <div className="mini-bar-meta"><span>{titleCase(item.label)}</span><strong>{item.count}</strong></div>
          <div className="mini-bar-track"><i style={{ width: `${(item.count / max) * 100}%` }} /></div>
        </div>
      ))}
    </div>
  );
}

function SectionTitle({ eyebrow, title, body, number }: { eyebrow: string; title: string; body?: string; number: string }) {
  return (
    <div className="section-title-wrap">
      <div className="section-number"><img src={visualAssets.logo} alt="" /><span>{number}</span><i /><small>ledger</small></div>
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2>{title}</h2>
        {body && <p className="section-body">{body}</p>}
      </div>
    </div>
  );
}

function AppDetail({ record, close }: { record: RecordItem; close: () => void }) {
  const allEvidence = [...(record.verification?.evidence ?? []), ...record.evidence];
  return (
    <aside className="detail-drawer" aria-label={`${record.appName} evidence detail`}>
      <div className="drawer-head">
        <div>
          <p className="eyebrow">Record #{record.id.toString().padStart(3, "0")}</p>
          <h3>{record.appName}</h3>
          <p>{record.category}</p>
        </div>
        <button className="icon-button" onClick={close} aria-label="Close evidence detail"><X size={18} /></button>
      </div>
      <div className="drawer-statuses">
        <span className={`status ${statusClass(record.buildabilityVerdict)}`}>{titleCase(record.buildabilityVerdict)}</span>
        <span className={`status ${statusClass(record.confidence)}`}>{record.confidence} confidence</span>
        {record.verification?.sampled && <span className="status status-verified"><BadgeCheck size={13} /> sample verified</span>}
      </div>
      <div className="drawer-block">
        <h4>Toolkit decision</h4>
        <p>{record.recommendedNextStep}</p>
        <dl>
          <div><dt>Credential path</dt><dd>{titleCase(record.selfServeStatus)}</dd></div>
          <div><dt>API breadth</dt><dd>{titleCase(record.apiSurfaceBreadth)}</dd></div>
          <div><dt>MCP status</dt><dd>{titleCase(record.mcpStatus)}</dd></div>
          <div><dt>Primary blocker</dt><dd>{record.primaryBlocker}</dd></div>
        </dl>
      </div>
      <div className="drawer-block">
        <h4>Evidence ledger</h4>
        <div className="evidence-list">
          {allEvidence.map((item, index) => (
            <a key={`${item.field}-${index}`} href={item.url} target="_blank" rel="noreferrer" className={`evidence-item ${item.status !== "linked" ? "evidence-muted" : ""}`}>
              <span>{item.field}</span>
              <span>{item.status === "linked" ? item.sourceType.replaceAll("_", " ") : "source not verified"}</span>
              {item.status === "linked" ? <ExternalLink size={14} /> : <CircleAlert size={14} />}
            </a>
          ))}
        </div>
      </div>
      {record.verification?.sampled && (
        <div className="drawer-block verified-block">
          <h4><ShieldCheck size={15} /> Audit note</h4>
          <p>{record.verification.correctionSummary}</p>
          <p className="small-note">Review confidence: {record.verification.reviewConfidence}. The correction sample is intentionally high-risk and is not a population estimate.</p>
        </div>
      )}
      <div className="drawer-block">
        <h4>Open questions</h4>
        <p>{record.uncertainties}</p>
        {record.qualityFlags.length > 0 && <p className="small-note">Quality flags: {record.qualityFlags.join(", ")}.</p>}
      </div>
    </aside>
  );
}

export default function Home() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [auth, setAuth] = useState("all");
  const [access, setAccess] = useState("all");
  const [mcp, setMcp] = useState("all");
  const [verdict, setVerdict] = useState("all");
  const [confidence, setConfidence] = useState("all");
  const [sortBy, setSortBy] = useState<"id" | "appName" | "buildabilityVerdict" | "confidence">("id");
  const [selected, setSelected] = useState<RecordItem | null>(null);
  const [mobileNav, setMobileNav] = useState(false);
  const [activeSection, setActiveSection] = useState("top");
  const [readingProgress, setReadingProgress] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const categories = useMemo(() => Array.from(new Set(records.map((record) => record.category))), []);
  const auths = useMemo(() => Array.from(new Set(records.flatMap((record) => record.authMethods))).filter(Boolean).sort(), []);
  const filtered = useMemo(() => records.filter((record) => {
    const evidenceIndex = record.evidence.map((item) => `${item.field} ${item.sourceType} ${item.url}`).join(" ");
    const auditIndex = record.verification ? `${record.verification.correctionSummary} ${record.verification.reviewConfidence}` : "";
    const haystack = [record.appName, record.category, record.whatItDoes, record.authMethods.join(" "), record.selfServeStatus, record.selfServeSummary, record.apiSurfaceBreadth, record.apiSurfaceSummary, record.mcpStatus, record.buildabilityVerdict, record.primaryBlocker, record.recommendedNextStep, evidenceIndex, auditIndex].join(" ").toLowerCase();
    const matchesQuery = !query || haystack.includes(query.toLowerCase());
    return matchesQuery
      && (category === "all" || record.category === category)
      && (auth === "all" || record.authMethods.includes(auth))
      && (access === "all" || record.selfServeStatus === access)
      && (mcp === "all" || record.mcpStatus === mcp)
      && (verdict === "all" || record.buildabilityVerdict === verdict)
      && (confidence === "all" || record.confidence === confidence);
  }).sort((a, b) => {
    if (sortBy === "id") return a.id - b.id;
    return String(a[sortBy]).localeCompare(String(b[sortBy]));
  }), [query, category, auth, access, mcp, verdict, confidence, sortBy]);
  const heroSearchResults = useMemo(() => query.trim().length > 1 ? filtered.slice(0, 5) : [], [query, filtered]);
  const heroSearchHasNoResults = (query.trim().length > 1 || auth !== "all" || mcp !== "all") && filtered.length === 0;

  const reset = () => { setQuery(""); setCategory("all"); setAuth("all"); setAccess("all"); setMcp("all"); setVerdict("all"); setConfidence("all"); setSortBy("id"); };
  const activeFilterCount = [query, category, auth, access, mcp, verdict, confidence].filter((value) => value !== "" && value !== "all").length;
  const goToSection = (id: string) => {
    setActiveSection(id);
    setMobileNav(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const goToMatrix = (nextVerdict?: string) => {
    if (nextVerdict) setVerdict(nextVerdict);
    goToSection("matrix");
  };

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      const active = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (active?.target.id) setActiveSection(active.target.id);
    }, { rootMargin: "-14% 0px -68% 0px", threshold: [0.05, 0.25, 0.5] });
    ledgerSections.forEach(([, , id]) => { const section = document.getElementById(id); if (section) observer.observe(section); });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const updateProgress = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setReadingProgress(max > 0 ? Math.min(100, Math.round((window.scrollY / max) * 100)) : 0);
    };
    updateProgress();
    window.addEventListener("scroll", updateProgress, { passive: true });
    return () => window.removeEventListener("scroll", updateProgress);
  }, []);

  useEffect(() => {
    const focusSearch = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", focusSearch);
    return () => window.removeEventListener("keydown", focusSearch);
  }, []);

  useEffect(() => {
    if (!selected) return;
    const priorOverflow = document.body.style.overflow;
    const closeOnEscape = (event: KeyboardEvent) => event.key === "Escape" && setSelected(null);
    document.body.style.overflow = "hidden";
    document.addEventListener("keydown", closeOnEscape);
    return () => { document.body.style.overflow = priorOverflow; document.removeEventListener("keydown", closeOnEscape); };
  }, [selected]);

  return (
    <div className="ledger-shell">
      <aside className={`evidence-rail ${mobileNav ? "rail-open" : ""}`}>
        <a href="#top" className="brand-lockup" onClick={() => setMobileNav(false)}>
          <img className="brand-mark" src={visualAssets.logo} alt="Evidence Ledger symbol" />
          <span><b>Evidence</b><em>Ledger</em></span>
        </a>
        <div className="rail-metadata">
          <div><span>Research set</span><strong>100 apps</strong></div>
          <div><span>Verified as of</span><strong>17 Aug 2026</strong></div>
          <div><span>Audit sample</span><strong>25 apps</strong></div>
        </div>
        <nav className="rail-nav" aria-label="Case study sections">
          {ledgerSections.map(([num, text, target]) => <a key={target} href={`#${target}`} className={activeSection === target ? "is-active" : ""} onClick={(event) => { event.preventDefault(); goToSection(target); }}><span>{num}</span>{text}</a>)}
        </nav>
        <div className="rail-proof">
          <span className="live-dot" />
          <div><b>Research agent run</b><small>100 / 100 completed</small></div>
        </div>
        <p className="rail-footnote">A case study for Composio’s toolkit research operations assignment.</p>
      </aside>

      <main className="main-canvas">
        <div className="reading-progress" aria-hidden="true"><i style={{ width: `${readingProgress}%` }} /></div>
        <header className="mobile-header">
          <button className="icon-button" onClick={() => setMobileNav(true)} aria-label="Open navigation"><Menu size={19} /></button>
          <a href="#top" className="mobile-brand"><img src={visualAssets.logo} alt="" /> Evidence Ledger</a>
          <a className="header-link" href="#matrix" onClick={(event) => { event.preventDefault(); goToSection("matrix"); }}>Matrix <ArrowDownRight size={14} /></a>
        </header>

        <section id="top" className="hero-section">
          <img src={visualAssets.hero} className="hero-art" alt="Abstract evidence signals flowing into a decision trace" />
          <div className="hero-wash" />
          <div className="hero-grid-lines" />
          <div className="hero-content">
            <div className="hero-topline"><img className="hero-mark" src={visualAssets.logo} alt="" /><span className="status status-verified"><BadgeCheck size={13} /> evidence-backed research</span><span>COMPOSIO / TOOLKIT READINESS</span></div>
            <p className="hero-kicker">From 100 app requests to a buildable toolkit queue</p>
            <h1>{insights.headline}</h1>
            <p className="hero-summary">{insights.narrative}</p>
            <div className="global-search" role="search">
              <Search size={18} aria-hidden="true" />
              <input ref={searchInputRef} value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search any app, API endpoint, auth method, MCP, or evidence detail" aria-label="Search app and API research details" />
              <kbd>⌘ K</kbd>
              <select className="global-filter" value={auth} onChange={(event) => setAuth(event.target.value)} aria-label="Filter global search by authentication type"><option value="all">Auth: all</option>{auths.map((item) => <option key={item} value={item}>{item}</option>)}</select>
              <select className="global-filter" value={mcp} onChange={(event) => setMcp(event.target.value)} aria-label="Filter global search by MCP status"><option value="all">MCP: all</option>{insights.mcp.map((item) => <option key={item.label} value={item.label}>{titleCase(item.label)}</option>)}</select>
              <a className="search-github" href={githubUrl} target="_blank" rel="noreferrer" aria-label="Open the source repository on GitHub"><Github size={14} /><span>GitHub</span></a>
              {heroSearchResults.length > 0 && <div className="search-result-popover" role="listbox" aria-label="Matching research records">{heroSearchResults.map((record) => <button key={record.id} role="option" onClick={() => setSelected(record)}><span className="search-record-id">{String(record.id).padStart(3, "0")}</span><span><strong>{record.appName}</strong><small>{titleCase(record.apiSurfaceBreadth)} API · {titleCase(record.mcpStatus)}</small></span><ArrowUpRight size={15} /></button>)}<button className="search-see-all" onClick={() => goToSection("matrix")}>See all {filtered.length} matching records <ArrowDownRight size={14} /></button></div>}
              {heroSearchHasNoResults && <div className="search-empty-popover" role="status" aria-live="polite"><strong>No results found</strong><span>Try a different app, API, auth type, or MCP status. Your active search and filters can be cleared in one step.</span><button onClick={() => { reset(); searchInputRef.current?.focus(); }}>Clear search & filters</button></div>}
            </div>
            <div className="hero-actions">
              <button className="button-primary" onClick={() => goToMatrix("build_now")}>Inspect build-now lane <ArrowDownRight size={16} /></button>
              <a className="button-ghost" href="#verification" onClick={(event) => { event.preventDefault(); goToSection("verification"); }}>Read the audit <ShieldCheck size={16} /></a>
            </div>
            <div className="provenance-legend" aria-label="Decision status legend"><span className="status status-verified"><BadgeCheck size={12} /> Verified</span><span className="status status-review">Human review</span><span className="status status-warning">Outreach</span><span className="status status-neutral">Unknown preserved</span></div>
          </div>
          <div className="hero-provenance">
            <span>Research protocol</span>
            <strong>Official docs → quality gates → independent sample audit</strong>
          </div>
        </section>

        <section className="kpi-section" aria-label="Key research metrics">
          {Object.values(insights.kpis).map((item) => (
            <div className="kpi-card" key={item.label}>
              <p>{item.label}</p><strong>{item.value}</strong><span>{item.detail}</span>
            </div>
          ))}
        </section>

        <section id="queues" className="section ledger-section decision-section">
          <SectionTitle number="02" eyebrow="Operating decision" title="Split the roadmap into four lanes, not one backlog." body="The research output is valuable only when it changes the next action. These queues are generated from the reconciled dataset, not manually curated." />
          <div className="decision-grid">
            <article className="decision-card decision-build"><div className="card-mark"><ArrowUpRight size={18} /></div><p>Build now</p><strong>{insights.verdicts.find((item) => item.label === "build_now")?.count ?? 0}</strong><span>Clear enough API and credential route to enter integration build planning.</span><button onClick={() => goToMatrix("build_now")}>Open lane <ArrowDownRight size={15} /></button></article>
            <article className="decision-card decision-review"><div className="card-mark"><ShieldCheck size={18} /></div><p>Build with review</p><strong>{insights.verdicts.find((item) => item.label === "build_with_review")?.count ?? 0}</strong><span>Technically viable, but permissions, scopes, risk, or approval need human control.</span><button onClick={() => goToMatrix("build_with_review")}>Open lane <ArrowDownRight size={15} /></button></article>
            <article className="decision-card decision-outreach"><div className="card-mark"><Link2 size={18} /></div><p>Outreach required</p><strong>{insights.verdicts.find((item) => item.label === "outreach_required")?.count ?? 0}</strong><span>Commercial, partner, admin, or app-review friction blocks the self-serve path.</span><button onClick={() => goToMatrix("outreach_required")}>Open lane <ArrowDownRight size={15} /></button></article>
            <article className="decision-card decision-debt"><div className="card-mark"><FileSearch size={18} /></div><p>Research debt</p><strong>{insights.researchDebt.length}</strong><span>Low confidence, missing provenance, or a taxonomy conflict needs another evidence pass.</span><button onClick={() => document.getElementById("method")?.scrollIntoView({ behavior: "smooth" })}>See controls <ArrowDownRight size={15} /></button></article>
          </div>
        </section>

        <section className="section metrics-section">
          <div className="metric-layout">
            <article className="metric-panel metric-panel-dark"><p className="eyebrow">Auth and access</p><h3>Credential path is the operating constraint.</h3><p>Authentication types can be multi-valued. Access status uses the strictest practical gate for an agent toolkit route.</p><MiniBar items={insights.authMix.slice(0, 6)} accent="lime" /></article>
            <article className="metric-panel"><p className="eyebrow">Buildability funnel</p><MiniBar items={insights.verdicts} accent="orange" /><div className="panel-note"><span className="note-line" />API surface and credential friction are assessed separately, then combined into a buildability verdict.</div></article>
            <article className="metric-panel metric-visual"><img src={visualAssets.pattern} alt="Abstract pattern showing open build paths and gated access" /><div className="visual-caption"><span>Access audit trace · conceptual only</span><strong>API-compatible does not mean self-serve.</strong></div></article>
          </div>
        </section>

        <section className="section queue-section">
          <div className="queue-columns">
            <div className="queue-column"><SectionTitle number="02A" eyebrow="Easy wins" title="Start where the evidence is already sufficient." /><div className="queue-list">{insights.easyWins.slice(0, 6).map((item) => <button key={item.id} className="queue-row" onClick={() => setSelected(records.find((record) => record.id === item.id) ?? null)}><span className="queue-id">{String(item.id).padStart(3, "0")}</span><div><strong>{item.appName}</strong><p>{item.why}</p></div><ArrowUpRight size={15} /></button>)}</div></div>
            <div className="queue-column outreach-column"><SectionTitle number="02B" eyebrow="Outreach lane" title="Route gated apps to a relationship owner." /><div className="queue-list">{insights.outreachQueue.length ? insights.outreachQueue.slice(0, 6).map((item) => <button key={item.id} className="queue-row" onClick={() => setSelected(records.find((record) => record.id === item.id) ?? null)}><span className="queue-id">{String(item.id).padStart(3, "0")}</span><div><strong>{item.appName}</strong><p>{item.gate} · {item.blocker}</p></div><ArrowUpRight size={15} /></button>) : <p className="empty-note">No apps were classified into the outreach lane in this first pass.</p>}</div></div>
          </div>
        </section>

        <section id="matrix" className="section matrix-section">
          <SectionTitle number="03" eyebrow="Full research set" title="Inspect every call, evidence trail, and decision." body="Search across all 100 records, including app names, API surfaces, auth methods, MCP status, blockers, next steps, and evidence sources. Select a row to open its evidence ledger and sampled-audit notes." />
          <div className="filter-shell">
            <div className="filter-primary"><Search size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search apps, API, auth, MCP, evidence URLs, or blockers…" aria-label="Search app and API research details" /><span>{filtered.length} / 100</span></div>
            <p className="filter-index-note">Indexed fields: product, category, auth, access path, API breadth and summary, MCP status, decision, blocker, next step, audit note, and evidence URL.</p>
            <div className="filter-quick-actions" aria-label="Quick matrix filters"><span>{activeFilterCount ? `${activeFilterCount} active filter${activeFilterCount > 1 ? "s" : ""}` : "Quick decision lanes"}</span>{["build_now", "build_with_review", "outreach_required"].map((lane) => <button className={verdict === lane ? "is-active" : ""} key={lane} onClick={() => setVerdict(verdict === lane ? "all" : lane)}>{titleCase(lane)}</button>)}{activeFilterCount > 0 && <button className="clear-filter-button" onClick={reset}>Clear all</button>}</div>
            <div className="filter-grid">
              <label><span>Category</span><select value={category} onChange={(event) => setCategory(event.target.value)}><option value="all">All categories</option>{categories.map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
              <label><span>Auth</span><select value={auth} onChange={(event) => setAuth(event.target.value)}><option value="all">All auth</option>{auths.map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
              <label><span>Access</span><select value={access} onChange={(event) => setAccess(event.target.value)}><option value="all">All access paths</option>{insights.access.map((item) => <option key={item.label} value={item.label}>{titleCase(item.label)}</option>)}</select></label>
              <label><span>MCP</span><select value={mcp} onChange={(event) => setMcp(event.target.value)}><option value="all">All MCP status</option>{insights.mcp.map((item) => <option key={item.label} value={item.label}>{titleCase(item.label)}</option>)}</select></label>
              <label><span>Verdict</span><select value={verdict} onChange={(event) => setVerdict(event.target.value)}><option value="all">All decisions</option>{insights.verdicts.map((item) => <option key={item.label} value={item.label}>{titleCase(item.label)}</option>)}</select></label>
              <label><span>Confidence</span><select value={confidence} onChange={(event) => setConfidence(event.target.value)}><option value="all">All confidence</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></label>
              <label><span>Sort</span><select value={sortBy} onChange={(event) => setSortBy(event.target.value as typeof sortBy)}><option value="id">Assignment ID</option><option value="appName">App name</option><option value="buildabilityVerdict">Decision</option><option value="confidence">Confidence</option></select></label>
              <button className="reset-button" disabled={!activeFilterCount && sortBy === "id"} onClick={reset}><Filter size={14} /> Reset controls</button>
            </div>
          </div>
          <div className="matrix-table-wrap" role="region" aria-label="App research matrix" tabIndex={0}>
            <table className="matrix-table">
              <thead><tr><th>#</th><th>App / purpose</th><th>Auth + access</th><th>API + MCP</th><th>Decision</th><th>Evidence</th></tr></thead>
              <tbody>{filtered.length === 0 ? <tr><td colSpan={6} className="matrix-empty"><strong>No results found</strong><span>Nothing matches this search and filter combination. Search an app name, API detail, authentication type, MCP status, or clear the controls to restart.</span><button onClick={() => { reset(); searchInputRef.current?.focus(); }}>Clear search & filters</button></td></tr> : filtered.map((record) => {
                const authEvidence = sourceFor(record, "auth");
                const accessEvidence = sourceFor(record, "access");
                const apiEvidence = sourceFor(record, "api");
                const mcpEvidence = sourceFor(record, "mcp");
                return <tr key={record.id} onClick={() => setSelected(record)} className="matrix-row" tabIndex={0} aria-label={`Open evidence ledger for ${record.appName}`} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); setSelected(record); } }}>
                  <td className="id-cell">{String(record.id).padStart(3, "0")}</td>
                  <td><strong>{record.appName}</strong><p>{record.whatItDoes}</p><small>{record.category}</small></td>
                  <td><div className="tag-row">{record.authMethods.slice(0, 3).map((item) => <span className="tag" key={item}>{item}</span>)}</div><span className={`status ${statusClass(record.selfServeStatus)}`}>{titleCase(record.selfServeStatus)}</span></td>
                  <td><div className="status-line"><span className="label-muted">{titleCase(record.apiSurfaceBreadth)}</span><span className="dot-divider" /><span>{titleCase(record.mcpStatus)}</span></div><p className="small-cell-copy">{record.apiSurfaceSummary}</p></td>
                  <td><span className={`status ${statusClass(record.buildabilityVerdict)}`}>{titleCase(record.buildabilityVerdict)}</span><p className="small-cell-copy">{record.primaryBlocker}</p>{record.verification?.sampled && <small className="verified-mini"><BadgeCheck size={12} /> audited</small>}</td>
                  <td><div className="evidence-icons">
                    {authEvidence && <a href={authEvidence.url} target="_blank" rel="noreferrer" onClick={(event) => event.stopPropagation()} title="auth evidence"><span>A</span></a>}
                    {accessEvidence && <a href={accessEvidence.url} target="_blank" rel="noreferrer" onClick={(event) => event.stopPropagation()} title="access evidence"><span>X</span></a>}
                    {apiEvidence && <a href={apiEvidence.url} target="_blank" rel="noreferrer" onClick={(event) => event.stopPropagation()} title="API evidence"><span>P</span></a>}
                    {mcpEvidence && <a href={mcpEvidence.url} target="_blank" rel="noreferrer" onClick={(event) => event.stopPropagation()} title="MCP evidence"><span>M</span></a>}
                  </div><button className="row-detail" onClick={(event) => { event.stopPropagation(); setSelected(record); }}>Inspect <ChevronDown size={14} /></button></td>
                </tr>;
              })}</tbody>
            </table>
          </div>
        </section>

        <section id="workflow" className="section workflow-section">
          <div className="workflow-visual"><img src={visualAssets.agent} alt="Abstract agent research pipeline" /><div className="workflow-visual-label"><Network size={15} /> Evidence-flow trace · conceptual only</div></div>
          <div className="workflow-content"><SectionTitle number="04" eyebrow="What the agent did" title="A research loop designed for scale, with humans where errors are expensive." /><div className="workflow-list">{insights.workflow.map((item) => <div className="workflow-step" key={item.step}><span>{item.step}</span><div><h4>{item.label}</h4><p>{item.detail}</p></div></div>)}</div><div className="proof-card"><Boxes size={18} /><div><span>Composio hand-off</span><strong>Dry-run artefact created. No unapproved app account or production action was accessed.</strong></div><a href="/data/composio_proof.json" target="_blank" rel="noreferrer">View proof <ExternalLink size={14} /></a></div></div>
        </section>

        <section id="verification" className="section verification-section">
          <SectionTitle number="05" eyebrow="Trust, measured" title="The first pass was useful, not perfect. The controls made the difference." body="The sample deliberately over-indexed on MCP, access gates, lower-confidence records, and high-risk categories. It is an audit designed to expose mistakes, not a population estimate." />
          <div className="verification-grid">
            <article className="accuracy-card"><p>First-pass exact record match</p><strong>{insights.verification.recordLevelExactMatch.percentage}%</strong><span>{insights.verification.recordLevelExactMatch.matches}/{insights.verification.recordLevelExactMatch.checked} sampled apps matched across all five audited fields.</span><div className="accuracy-rail"><i style={{ width: `${insights.verification.recordLevelExactMatch.percentage}%` }} /></div><small>After corrections, the final dataset aligns 100% with this same correction sample. That is not a holdout accuracy claim.</small></article>
            <article className="field-accuracy"><p>Field-level first-pass accuracy</p>{Object.entries(insights.verification.fieldAccuracy).map(([key, metric]) => <div className="field-accuracy-row" key={key}><span>{key === "apiBreadth" ? "API breadth" : key === "selfServe" ? "Self-serve access" : key}</span><div><i style={{ width: `${metric.percentage}%` }} /></div><strong>{metric.matches}/{metric.checked}</strong></div>)}<a href="/data/verification_log.csv" target="_blank" rel="noreferrer">Open verification log <ExternalLink size={14} /></a></article>
            <article className="miss-card"><p>What the agent missed</p><ul><li><b>Credential semantics:</b> several first-pass labels treated tokens or auth variants as more interchangeable than the docs support.</li><li><b>Native MCP burden:</b> claims required vendor-owned documentation, not a generic integration listing.</li><li><b>Strict access:</b> production or managed MCP access can carry admin, plan, or review gates even when a public API exists.</li></ul><span><CircleAlert size={14} /> {insights.verification.correctionCount} sampled records corrected</span></article>
          </div>
          <div className="holdout-disclosure"><img src={visualAssets.logo} alt="" /><div><p>Second control loop · disclosed limitation</p><h3>A 10-app, one-per-category post-repair holdout surfaced taxonomy ambiguity and triggered targeted corrections.</h3><span>The independent verifier did not return the requested API-breadth field for the full holdout. It is therefore retained as an error-discovery loop, not presented as a generalisable post-repair accuracy percentage.</span></div><a href="/data/post_repair_holdout.json" target="_blank" rel="noreferrer">Open raw holdout <ExternalLink size={14} /></a></div>
        </section>

        <section id="method" className="section method-section">
          <div className="method-visual"><img src={visualAssets.provenance} alt="Abstract documentation and citation markers" /></div>
          <div className="method-copy"><SectionTitle number="06" eyebrow="Method and limitations" title="Designed to be auditable, not merely exhaustive." /><div className="method-columns"><div><h4>Evidence standard</h4><p>Official API, auth, pricing, app-review, help, or vendor-owned repository sources were prioritised. Unknown is preserved when a primary source could not support a decision.</p></div><div><h4>Decision logic</h4><p>API breadth, credential path, MCP evidence, and operational gates are assessed separately. Buildability is an operations decision, not an API-existence claim.</p></div><div><h4>Limitations</h4><p>Source pages can change; this is a dated snapshot. The verification sample is high-information rather than random. The Composio SDK proof remains labelled dry-run pending an approved test connection.</p></div></div><div className="method-links"><a href="/data/research_results_final.csv" target="_blank" rel="noreferrer"><BookOpenCheck size={15} /> Final dataset</a><a href="/data/quality_report.json" target="_blank" rel="noreferrer"><ShieldCheck size={15} /> Quality report</a><a href="/data/insights.json" target="_blank" rel="noreferrer"><Sparkles size={15} /> Calculated insights</a><a href="https://composio.dev" target="_blank" rel="noreferrer"><ExternalLink size={15} /> Composio</a></div></div>
        </section>

        <footer className="site-footer"><div><img className="footer-mark" src={visualAssets.logo} alt="" /><p>Evidence Ledger<br /><span>Composio toolkit research case study · 17 Aug 2026</span></p></div><div className="footer-links"><a href="/data/research_results_final.json" target="_blank" rel="noreferrer">Research JSON</a><a href="/data/verification_log.json" target="_blank" rel="noreferrer">Verification log</a><a href={githubUrl} target="_blank" rel="noreferrer"><Github size={14} /> Open GitHub source</a>{readingProgress > 12 && <button className="back-to-top" onClick={() => goToSection("top")}>Back to top <ArrowUpRight size={13} /></button>}</div></footer>
      </main>
      {selected && <div className="drawer-backdrop" onClick={() => setSelected(null)}><div onClick={(event) => event.stopPropagation()}><AppDetail record={selected} close={() => setSelected(null)} /></div></div>}
    </div>
  );
}
